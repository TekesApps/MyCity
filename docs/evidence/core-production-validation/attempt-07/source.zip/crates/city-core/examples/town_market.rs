//! Execute a real 28-day Engine market loop. The route and daily utility limits are
//! fixed test-profile inputs; this example does not claim the traffic adapter is live.
use mycity_core::{
    assembly::assemble,
    timeline::{Command as TimelineCommand, Cycle, DAY, PayrollSpec},
    transaction::{Action, Caller, Engine, Envelope},
    units::{Money, Quantity},
};
use serde_json::Value;

const OPENING: &[u8] = include_bytes!("../../../fixtures/m0-e0-opening.json");
const DAYS: u64 = 28;

fn command(engine: &mut Engine, action: Action) -> Result<(), String> {
    let view = engine.world().view();
    let operation_id = view.revision + 100;
    engine
        .execute(
            Caller::System,
            Envelope {
                world: view.scope.world(),
                branch: view.scope.branch(),
                operation_id,
                expected_revision: view.revision,
                actions: vec![action],
            },
        )
        .map(|_| ())
        .map_err(|error| format!("engine:{error:?}"))
}

fn main() -> Result<(), String> {
    let mut opening: Value = serde_json::from_slice(OPENING).map_err(|e| e.to_string())?;
    opening["sources"].as_array_mut().unwrap().extend([
        serde_json::json!({"id":6,"kind":"inventory_capital","amount":100000}),
        serde_json::json!({"id":7,"kind":"inventory_capital","amount":0}),
    ]);
    opening["stocks"].as_array_mut().unwrap().extend([
        serde_json::json!({"id":2,"owner":3,"commodity":"raw","quantity":100000,"basis":100000,"source":6}),
        serde_json::json!({"id":3,"owner":3,"commodity":"product","quantity":0,"basis":0,"source":7}),
    ]);
    opening["town"] = serde_json::json!({
        "schema_version":1,
        "id":1,
        "households":[{"id":1,"account":2,"households":1,"need_good":1,"need_per_household":10,"reference_price_per_q":1000}],
        "employers":[{"account":3,"worker_limit":1}],
        "shops":[{"shop_id":1,"account":3,"stock_id":3,"good":1,"shelf_price_per_q":100}],
        "recipes":[{
            "recipe_id":1,"employer":3,"assigned_workers":1,"input_stock_id":2,
            "input_per_output":1,"output_good":1,"output_stock_id":3,"output_per_worker_day":100,
            "waste_per_output_q":0,"available_utility_per_day":1000,"utility_per_output_q":1,
            "utility_cost_per_output_q":1,"freight_cost_per_input_q":0,"disposal_cost_per_input_q":0,
            "utility_account":1,"freight_account":1,"disposal_account":1
        }],
        "delivery":[{"quote_id":1,"shop":1,"household_group":1,"good":1,"reachable":true,
            "route_source":77,"freight_account":1,"utility_account":1,"available_capacity":100,
            "freight_per_q":1,"utility_surcharge_per_q":1}]
    });
    let world = assemble(&serde_json::to_vec(&opening).map_err(|e| e.to_string())?)?;
    let mut engine = Engine::new(world, Vec::new()).map_err(|e| format!("engine_init:{e:?}"))?;
    command(
        &mut engine,
        Action::Timeline {
            command: TimelineCommand::Enable,
        },
    )?;
    command(
        &mut engine,
        Action::Timeline {
            command: TimelineCommand::AddPayroll {
                spec: PayrollSpec {
                    id: 1,
                    payer: 3,
                    payee: 2,
                    home_city: 0,
                    hourly_cents: Money::new(100).map_err(|e| format!("money:{e:?}"))?,
                    cycle: Cycle::Daily,
                    ends_at: DAYS * DAY,
                },
            },
        },
    )?;

    for day in 1..=DAYS {
        for _ in 0..8 {
            command(
                &mut engine,
                Action::Timeline {
                    command: TimelineCommand::Advance {
                        target: day * DAY,
                        limit: 8192,
                    },
                },
            )?;
            if engine
                .timeline()
                .is_some_and(|t| t.progress.target.is_none())
            {
                break;
            }
        }
        let receipt = {
            let view = engine.world().view();
            engine
                .execute(
                    Caller::System,
                    Envelope {
                        world: view.scope.world(),
                        branch: view.scope.branch(),
                        operation_id: view.revision + 100,
                        expected_revision: view.revision,
                        actions: vec![Action::TownSettle { profile_id: 1 }],
                    },
                )
                .map_err(|e| format!("town_day_{day}:{e:?}"))?
        };
        if receipt.town.is_none_or(|summary| summary.day != day) {
            return Err(format!("missing_day_summary:{day}"));
        }
    }

    let final_view = engine.world().view();
    let household = final_view.accounts.iter().find(|a| a.id == 2).unwrap();
    let producer = final_view.accounts.iter().find(|a| a.id == 3).unwrap();
    let input = final_view.stocks.iter().find(|s| s.id == 2).unwrap();
    let output = final_view.stocks.iter().find(|s| s.id == 3).unwrap();
    if household.cash <= Money::ZERO || producer.cash <= Money::ZERO {
        return Err("cash_not_conserved".into());
    }
    if input.quantity >= Quantity::new(100000).unwrap() || output.quantity == Quantity::ZERO {
        return Err("production_or_sales_not_applied".into());
    }
    println!(
        "days={DAYS} household_cash={} producer_cash={} raw_remaining={} product_remaining={} town={:?}",
        household.cash.value(),
        producer.cash.value(),
        input.quantity.value(),
        output.quantity.value(),
        final_view.town.map(|town| town.state.last_summary)
    );
    Ok(())
}
