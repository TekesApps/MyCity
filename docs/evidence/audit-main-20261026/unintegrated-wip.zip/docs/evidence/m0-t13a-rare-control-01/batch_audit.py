"""Post-observer numeric crosscheck of claimed rare-batch duration ranges.

This does not independently establish eligibility, process identity, snapshot
overlap or 200 independent trials. Those remain separate acceptance work.
"""
import hashlib
import json
from pathlib import Path

from duration_audit import audit_many

LINE_CAP = 256 * 1024
CLASSES = {2: "L2_claims_batch", 6: "air_source_page", 7: "air_cell_page"}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def integer(value):
    return type(value) is int and value >= 0


def verify_reported_histogram(numeric, histogram):
    """Crosscheck exact ranks against original conservative Rust intervals."""
    count = numeric.get("selected_sample_count")
    require(integer(count) and isinstance(histogram, dict)
            and histogram.get("samples") == count, "histogram population mismatch")
    for label, percent in (("p95", 95), ("p99", 99)):
        bucket = histogram.get(label)
        require(isinstance(bucket, dict), "histogram quantile missing")
        rank = (count * percent + 99) // 100
        require(type(bucket.get("nearest_rank")) is int and bucket["nearest_rank"] == rank,
                "histogram nearest rank mismatch")
        if not count:
            continue
        exact = numeric.get(label + "_ns")
        lower, upper = bucket.get("lower_exclusive_ns"), bucket.get("upper_inclusive_ns")
        require(integer(exact) and integer(lower) and integer(upper)
                and ((exact == 0 and lower == 0 and upper == 0)
                     or lower < exact <= upper), "exact quantile outside conservative interval")
    return {"population_and_quantile_intervals": "matched_raw_numeric_values",
            "eligibility_and_full_gate": "not_proven_by_numeric_crosscheck"}


def audit_batch(model_root, source_sha256, binary_sha256, kind, phase):
    from run import safe_file, reject_duplicate_keys, sha256
    require(kind in ("claims", "source") and phase in ("smoke", "formal"), "unsupported batch")
    model_root = Path(model_root).resolve(strict=True)
    classes = [2] if kind == "claims" else [6, 7]
    expected_trials = 1 if phase == "smoke" else 200
    grouped = {cls: {} for cls in classes}
    expected_counts = {cls: 0 for cls in classes}
    observed_trial_rows = {cls: 0 for cls in classes}
    ledger = safe_file(model_root, "trial-analysis.jsonl")
    ledger_hash = hashlib.sha256()
    completed = 0
    with ledger.open("rb") as stream:
        while True:
            line = stream.readline(LINE_CAP + 1)
            if not line:
                break
            require(len(line) <= LINE_CAP and line.endswith(b"\n"), "analysis line bound or truncation")
            ledger_hash.update(line)
            row = json.loads(line, object_pairs_hook=reject_duplicate_keys)
            completed += 1
            require(completed <= expected_trials and isinstance(row, dict), "unexpected analysis row")
            require(type(row.get("ordinal")) is int and row["ordinal"] == completed, "trial ordinal mismatch")
            trial = f"{kind}-{completed:03d}"
            require(row.get("trial") == trial and row.get("stratum") == kind
                    and row.get("source_sha256") == source_sha256
                    and row.get("binary_sha256") == binary_sha256, "trial source/binary mismatch")
            trial_root = model_root / "trials" / trial
            ranges = row.get("eligible_duration_ranges")
            require(isinstance(ranges, list) and len(ranges) <= 1024, "missing/bounded claimed ranges")
            trial_counts = {cls: 0 for cls in classes}
            for item in ranges:
                require(isinstance(item, dict), "range object required")
                path = safe_file(trial_root, item["path"])
                start, end = item.get("start"), item.get("end")
                require(integer(start) and integer(end) and end > start, "range bounds")
                counts = item.get("expected_samples_by_class")
                require(isinstance(counts, list) and len(counts) == 10
                        and all(v is None or integer(v) for v in counts), "range expected class counts")
                digest = item.get("expected_file_sha256")
                require(isinstance(digest, str) and len(digest) == 64
                        and all(c in "0123456789abcdef" for c in digest), "range SHA shape")
                for cls in classes:
                    count = counts[cls]
                    if count is None:
                        continue
                    entry = grouped[cls].setdefault(path, {"sha256": digest, "ranges": [], "expected": 0})
                    require(entry["sha256"] == digest, "one raw file has conflicting SHA assertions")
                    entry["ranges"].append((start, end))
                    entry["expected"] += count
                    expected_counts[cls] += count
                    trial_counts[cls] += count
            for cls in classes:
                observed_trial_rows[cls] += int(trial_counts[cls] > 0)
    require(completed == expected_trials, "incomplete analysis ledger")
    reports = {}
    for cls in classes:
        inputs = [(path, entry["sha256"], entry["ranges"])
                  for path, entry in sorted(grouped[cls].items(), key=lambda pair: str(pair[0]))]
        numeric = audit_many(inputs, cls)
        require(numeric["selected_sample_count"] == expected_counts[cls], "raw total differs from claimed count")
        for actual, (_, entry) in zip(numeric["files"], sorted(grouped[cls].items(), key=lambda pair: str(pair[0]))):
            require(actual["selected_sample_count"] == entry["expected"], "raw per-file count differs from claim")
        reports[CLASSES[cls]] = {
            "numeric": numeric,
            "claimed_trial_rows_with_samples": observed_trial_rows[cls],
            "actual_independent_trial_identity_gate": "not_proven_by_numeric_audit",
        }
    require(sha256(ledger) == ledger_hash.hexdigest(), "analysis ledger changed during offline QA")
    return {
        "schema": "mycity-rare-batch-offline-numeric-audit-v1",
        "source_sha256": source_sha256, "binary_sha256": binary_sha256,
        "stratum": kind, "mode": phase, "observed_analysis_rows": completed,
        "trial_analysis_sha256": ledger_hash.hexdigest(), "classes": reports,
        "scope": "post-observer numeric QA of claimed ranges; not a new game or measurement process",
        "eligibility_identity_snapshot_overlap_audit": "pending",
        "normal_and_diagnostic_memory_gate": "not_proven_by_offline_QA",
        "memory_16gb_gate": "not_run", "full_M0": "not_accepted",
    }
