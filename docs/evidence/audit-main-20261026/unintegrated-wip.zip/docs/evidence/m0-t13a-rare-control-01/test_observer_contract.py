"""Synthetic observer-contract cases; these are not native or acceptance runs."""

import importlib.util
import unittest
from pathlib import Path


MODULE_PATH = Path(__file__).with_name("observer_contract.py")
SPEC = importlib.util.spec_from_file_location("rare_observer_contract", MODULE_PATH)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError("could not load observer_contract.py")
observer_contract = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(observer_contract)

SOURCE = "a" * 64
BINARY = "b" * 64
COMMAND = ["city-headless", "native-observe", "--bounded"]


def valid_report():
    return {
        "schema": "mycity-bounded-native-group-observer-v1",
        "source_sha256": SOURCE,
        "binary_sha256": BINARY,
        "command": COMMAND.copy(),
        "status": "passed_measurement_wrapper",
        "reason": None,
        "cleanup_error": None,
        "binary_unchanged": True,
        "model_exit_code": 0,
        "actual_wall_seconds": 1.0,
        "samples": 200,
        "final_live_identity_count": 1,
        "missing_footprint_process_samples": 0,
        "missing_rss_process_samples": 0,
        "unpolled_registered_processes": 0,
        "peak_world_logical_bytes": 20 * observer_contract.GIB,
        "maximum_observed_swap_net_growth_bytes": 256 * observer_contract.MIB,
        "sample_log_bytes": 256 * observer_contract.MIB,
        "maximum_sampled_non_normal_pressure_seconds": 60.0,
        "observer_hot_bound_bytes": 2 * observer_contract.MIB,
        "other_diagnostic_owned_bytes": 6 * observer_contract.MIB,
        "combined_diagnostic_hot_bound_bytes": 8 * observer_contract.MIB,
        "maximum_sample_gap_seconds": 1.0,
        "maximum_capture_window_seconds": 0.25,
    }


def classify(report, source=SOURCE, binary=BINARY, command=COMMAND):
    result = observer_contract.classify_observer_report(
        report, source, binary, command
    )
    if result.get("full_M0") != "not_accepted":
        raise AssertionError("observer summary must never accept full M0")
    if result.get("physical_memory_budget") not in (None, "not_verified_by_summary"):
        raise AssertionError("observer summary must not certify physical memory")
    if result.get("memory_16gb_gate") not in (None, "not_run"):
        raise AssertionError("observer summary must not certify the 16 GB gate")
    return result


class ObserverContractTests(unittest.TestCase):
    def test_valid_synthetic_report_never_proves_physical_or_full_m0(self):
        result = classify(valid_report())
        self.assertTrue(result["identity_matches"])
        self.assertTrue(result["wrapper_complete"])
        self.assertTrue(result["summary_has_no_reported_coverage_holes"])
        self.assertEqual(result["recorded_guard_bounds"], "within_frozen_bounds")
        self.assertEqual(result["diagnostic_hot_contract"], "arithmetically_consistent")
        self.assertTrue(result["sampling_cadence_recorded"])
        self.assertEqual(result["physical_memory_budget"], "not_verified_by_summary")
        self.assertEqual(result["memory_16gb_gate"], "not_run")
        self.assertEqual(result["formal_rare_gate"], "pending_independent_raw_identity_overlap_and_observer_audit")
        self.assertEqual(result["full_M0"], "not_accepted")

    def test_failed_status_exit_cleanup_reason_and_binary_change_block_wrapper(self):
        cases = (
            ("status", "failed"),
            ("model_exit_code", 1),
            ("cleanup_error", "cleanup failed"),
            ("reason", "observer process mismatch"),
            ("binary_unchanged", False),
        )
        for field, value in cases:
            with self.subTest(field=field):
                report = valid_report()
                report[field] = value
                self.assertFalse(classify(report)["wrapper_complete"])

    def test_identity_mismatch_for_command_source_or_binary_is_rejected(self):
        cases = (
            ("source_sha256", "c" * 64, SOURCE, BINARY, COMMAND),
            ("binary_sha256", "d" * 64, SOURCE, BINARY, COMMAND),
            ("command", ["different", "command"], SOURCE, BINARY, COMMAND),
        )
        for field, value, source, binary, command in cases:
            with self.subTest(field=field):
                report = valid_report()
                report[field] = value
                result = classify(report, source, binary, command)
                self.assertFalse(result["identity_matches"])
                self.assertFalse(result["wrapper_complete"])
                self.assertEqual(result["full_M0"], "not_accepted")

    def test_more_than_one_final_live_identity_is_rejected(self):
        report = valid_report()
        report["final_live_identity_count"] = 2
        self.assertFalse(classify(report)["wrapper_complete"])

    def test_missing_and_unpolled_samples_are_reported_as_coverage_holes(self):
        report = valid_report()
        report["missing_footprint_process_samples"] = 1
        self.assertFalse(classify(report)["summary_has_no_reported_coverage_holes"])

        report = valid_report()
        report["unpolled_registered_processes"] = 1
        self.assertFalse(classify(report)["summary_has_no_reported_coverage_holes"])

    def test_swap_world_pressure_and_sample_log_bounds_are_enforced(self):
        cases = (
            (
                "maximum_observed_swap_net_growth_bytes",
                256 * observer_contract.MIB + 1,
            ),
            ("peak_world_logical_bytes", 20 * observer_contract.GIB + 1),
            ("maximum_sampled_non_normal_pressure_seconds", 60.000001),
            ("sample_log_bytes", 256 * observer_contract.MIB + 1),
        )
        for field, value in cases:
            with self.subTest(field=field):
                report = valid_report()
                report[field] = value
                self.assertEqual(classify(report)["recorded_guard_bounds"], "not_proven")

    def test_combined_diagnostic_hot_bound_above_8_mib_is_rejected(self):
        report = valid_report()
        report["other_diagnostic_owned_bytes"] = 6 * observer_contract.MIB + 1
        report["combined_diagnostic_hot_bound_bytes"] = 8 * observer_contract.MIB + 1
        self.assertEqual(classify(report)["diagnostic_hot_contract"], "not_proven")

    def test_inconsistent_observer_and_other_diagnostic_sum_is_rejected(self):
        report = valid_report()
        report["combined_diagnostic_hot_bound_bytes"] -= 1
        self.assertEqual(classify(report)["diagnostic_hot_contract"], "not_proven")

    def test_missing_fields_and_nan_are_not_treated_as_zero(self):
        report = valid_report()
        del report["maximum_observed_swap_net_growth_bytes"]
        del report["maximum_sampled_non_normal_pressure_seconds"]
        del report["maximum_sample_gap_seconds"]
        result = classify(report)
        self.assertEqual(result["recorded_guard_bounds"], "not_proven")
        self.assertFalse(result["sampling_cadence_recorded"])

        report = valid_report()
        report["maximum_sampled_non_normal_pressure_seconds"] = float("nan")
        report["maximum_sample_gap_seconds"] = float("nan")
        report["actual_wall_seconds"] = float("nan")
        result = classify(report)
        self.assertEqual(result["recorded_guard_bounds"], "not_proven")
        self.assertFalse(result["sampling_cadence_recorded"])
        self.assertFalse(result["wrapper_complete"])


if __name__ == "__main__":
    unittest.main()
