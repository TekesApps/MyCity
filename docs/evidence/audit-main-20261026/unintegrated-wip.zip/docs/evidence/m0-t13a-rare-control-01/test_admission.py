"""Synthetic admission parser and profile cases; intentionally not executed here."""
import tempfile
import unittest
from pathlib import Path

from admission import (
    HP_VOLUME_UUID,
    MIN_FREE_BYTES,
    EXPECTED_FILESYSTEM,
    blockers_from_process_rows,
    parse_pressure_level,
    parse_process_rows,
    parse_swap_used_bytes,
    validate_storage_profile,
)


class AdmissionParsingTests(unittest.TestCase):
    def test_swap_units_are_binary_and_support_fractional_values(self):
        self.assertEqual(parse_swap_used_bytes("vm.swapusage: total = 1G used = 2.00K free = 3G"), 2 * 1024)
        self.assertEqual(parse_swap_used_bytes("total=1G used=1.5M free=0G"), int(1.5 * 1024**2))
        self.assertEqual(parse_swap_used_bytes("used = 2G"), 2 * 1024**3)
        self.assertEqual(parse_swap_used_bytes("used=3T"), 3 * 1024**4)

    def test_swap_parser_rejects_missing_ambiguous_and_malformed_values(self):
        for value in ("vm.swapusage: total = 1G free = 1G", "used=1M used=2M", "used=NaNM", "used=1MiB"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                parse_swap_used_bytes(value)

    def test_ps_parser_ignores_blank_tail_lines_but_rejects_bad_rows(self):
        parsed = parse_process_rows("101 1 /Volumes/HP P900/mycity-headless\n  \n")
        self.assertEqual(len(parsed), 1)
        for output in ("not-a-process-row\n", "abc 1 /bin/tool\n", "   \n\t\n"):
            with self.subTest(output=output), self.assertRaises(ValueError):
                parse_process_rows(output)

    def test_pressure_parser_accepts_dispatch_flag_and_rejects_other_text(self):
        self.assertEqual(parse_pressure_level("1\n"), 1)
        self.assertEqual(parse_pressure_level("2"), 2)
        with self.assertRaises(ValueError):
            parse_pressure_level("normal")

    def test_ps_parser_preserves_external_volume_spaces_and_refuses_headless(self):
        rows = parse_process_rows(
            "101 1 /Volumes/HP P900/dev/MyCity/target/debug/mycity-headless\n"
        )
        self.assertEqual(rows[0]["comm"], "/Volumes/HP P900/dev/MyCity/target/debug/mycity-headless")
        refused = blockers_from_process_rows(rows, own_pid=999)
        self.assertEqual(refused, [{"pid": 101, "exe": "mycity-headless", "reason": "unclassified_headless_active"}])


class StorageProfileTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.mount = self.root / "HP P900"
        self.mount.mkdir()
        self.external_work = self.mount / "dev/MyCity/work"
        self.external_target = self.mount / "dev/MyCity/target"
        self.external_work.mkdir(parents=True)
        self.external_target.mkdir(parents=True)
        self.work_link = self.root / "work"
        self.target_link = self.root / "target"
        self.work_link.symlink_to(self.external_work)
        self.target_link.symlink_to(self.external_target)
        self.identity = {
            "mount_point": str(self.mount),
            "volume_uuid": HP_VOLUME_UUID,
            "filesystem": EXPECTED_FILESYSTEM,
        }

    def tearDown(self):
        self.temp.cleanup()

    def profile(self, *, identity=None, free=MIN_FREE_BYTES, work_link=None, target_link=None):
        return validate_storage_profile(
            work_link=work_link or self.work_link,
            target_link=target_link or self.target_link,
            expected_work=self.external_work,
            expected_target=self.external_target,
            mount=self.mount,
            identity=identity or self.identity,
            free_bytes=free,
        )

    def test_expected_external_links_volume_and_free_floor_pass(self):
        result = self.profile()
        self.assertTrue(result["work_link_valid"])
        self.assertTrue(result["target_link_valid"])
        self.assertEqual(result["available_bytes"], MIN_FREE_BYTES)

    def test_wrong_work_link_is_rejected(self):
        wrong = self.root / "internal-work"
        wrong.mkdir()
        bad_link = self.root / "bad-work"
        bad_link.symlink_to(wrong)
        with self.assertRaisesRegex(ValueError, "work symlink"):
            self.profile(work_link=bad_link)

    def test_wrong_volume_uuid_and_non_apfs_are_rejected(self):
        wrong_uuid = dict(self.identity, volume_uuid="unrelated-volume")
        with self.assertRaisesRegex(ValueError, "UUID"):
            self.profile(identity=wrong_uuid)
        wrong_fs = dict(self.identity, filesystem="hfs")
        with self.assertRaisesRegex(ValueError, "APFS"):
            self.profile(identity=wrong_fs)

    def test_free_space_below_two_gib_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "2 GiB"):
            self.profile(free=MIN_FREE_BYTES - 1)


if __name__ == "__main__":
    unittest.main()
