"""Fixed native observer summary checks; raw coverage remains a separate audit.

Derived from candidate03 native_watch/summary.rs. A successful measurement
wrapper is neither a physical-memory acceptance nor the complete rare gate.
"""
import math

GIB = 1024 ** 3
MIB = 1024 ** 2


def nonnegative_number(value):
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def bounded_integer(value, cap):
    return type(value) is int and 0 <= value <= cap


def classify_observer_report(report, source, binary_sha256, expected_command):
    """Require the exact command/identity; never promote wrapper exit to M0."""
    identity = (
        isinstance(report, dict)
        and report.get("schema") == "mycity-bounded-native-group-observer-v1"
        and report.get("source_sha256") == source
        and report.get("binary_sha256") == binary_sha256
        and report.get("command") == expected_command
    )
    if not identity:
        return {"identity_matches": False, "wrapper_complete": False,
                "full_M0": "not_accepted", "formal_rare_gate": "not_verified_observer_identity"}
    complete = (
        {"status", "reason", "cleanup_error", "binary_unchanged", "model_exit_code",
         "actual_wall_seconds", "samples", "final_live_identity_count"} <= report.keys()
        and report.get("status") == "passed_measurement_wrapper"
        and report.get("reason") is None
        and report.get("cleanup_error") is None
        and report.get("binary_unchanged") is True
        and type(report.get("model_exit_code")) is int
        and report["model_exit_code"] == 0
        and nonnegative_number(report.get("actual_wall_seconds"))
        and report["actual_wall_seconds"] > 0
        and type(report.get("samples")) is int and report["samples"] > 0
        and type(report.get("final_live_identity_count")) is int
        and report["final_live_identity_count"] == 1
    )
    summary_coverage = all(
        type(report.get(key)) is int and report[key] == 0
        for key in ("missing_footprint_process_samples", "missing_rss_process_samples",
                    "unpolled_registered_processes")
    )
    # These are the unchanged measured guard bounds, not a new performance budget.
    pressure = report.get("maximum_sampled_non_normal_pressure_seconds")
    guards = (
        bounded_integer(report.get("peak_world_logical_bytes"), 20 * GIB)
        and bounded_integer(report.get("maximum_observed_swap_net_growth_bytes"), 256 * MIB)
        and bounded_integer(report.get("sample_log_bytes"), 256 * MIB)
        and nonnegative_number(pressure) and pressure <= 60
    )
    own = report.get("observer_hot_bound_bytes")
    other = report.get("other_diagnostic_owned_bytes")
    total = report.get("combined_diagnostic_hot_bound_bytes")
    diagnostic = (
        type(own) is int and own == 2 * MIB
        and bounded_integer(other, 8 * MIB)
        and bounded_integer(total, 8 * MIB)
        and own + other == total
    )
    cadence_recorded = all(
        nonnegative_number(report.get(key)) for key in
        ("maximum_sample_gap_seconds", "maximum_capture_window_seconds")
    )
    return {
        "identity_matches": True,
        "wrapper_complete": complete,
        "summary_has_no_reported_coverage_holes": summary_coverage,
        "recorded_guard_bounds": "within_frozen_bounds" if guards else "not_proven",
        "diagnostic_hot_contract": "arithmetically_consistent" if diagnostic else "not_proven",
        "sampling_cadence_recorded": cadence_recorded,
        "raw_identity_and_cadence_audit": "pending",
        "physical_memory_budget": "not_verified_by_summary",
        "combined_log_and_raw_file_audit": "pending",
        "memory_16gb_gate": "not_run",
        "formal_rare_gate": "pending_independent_raw_identity_overlap_and_observer_audit",
        "full_M0": "not_accepted",
    }
