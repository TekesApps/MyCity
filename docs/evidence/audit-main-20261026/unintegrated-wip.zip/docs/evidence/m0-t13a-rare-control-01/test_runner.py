"""Pure helper regression cases; intentionally not executed during source preparation."""
import unittest

from run import process_refusal, parse_ps, read_report
from pathlib import Path
from tempfile import TemporaryDirectory


class ControllerHelperTests(unittest.TestCase):
    def test_comm_path_with_spaces_is_not_split_into_fake_arguments(self):
        rows = parse_ps(" 30 1 /Volumes/HP P900/dev/MyCity/work/binary/mycity-headless\n")
        self.assertEqual(rows[0]["comm"], "/Volumes/HP P900/dev/MyCity/work/binary/mycity-headless")
        self.assertEqual(process_refusal(rows, 999)[0]["reason"], "unclassified_headless_active")

    def test_malformed_process_inventory_fails_closed(self):
        with self.assertRaises(RuntimeError):
            parse_ps("not a process row")

    def test_report_duplicate_keys_and_non_finite_constants_refused(self):
        with TemporaryDirectory() as temp:
            path = Path(temp) / "report.json"
            for text in ('{"status":"failed","status":"passed"}', '{"samples":NaN}'):
                path.write_text(text)
                with self.assertRaises(RuntimeError):
                    read_report(path)

    def test_blocks_rust_compiler_and_clippy(self):
        rows = [
            {"pid": 10, "ppid": 1, "comm": "/opt/rust/bin/rustc", "args": "/opt/rust/bin/rustc --crate-name city"},
            {"pid": 11, "ppid": 1, "comm": "clippy-driver", "args": "clippy-driver --crate-name city"},
        ]
        self.assertEqual(len(process_refusal(rows, 999)), 2)

    def test_blocks_measurement_even_when_observer_is_parent(self):
        rows = [
            {"pid": 20, "ppid": 1, "comm": "/work/mycity-headless", "args": "/work/mycity-headless native-observe /tmp/obs -- /work/mycity-headless scale-rare-batch /tmp/a /tmp/model claims smoke"},
        ]
        self.assertEqual(process_refusal(rows, 999)[0]["reason"], "mycity_measurement_active:native-observe")

    def test_blocks_direct_rare_batch_without_observer_parent(self):
        rows = [
            {"pid": 30, "ppid": 1, "comm": "mycity-headless", "args": "mycity-headless scale-rare-batch /tmp/anchors /tmp/model claims formal"},
        ]
        self.assertEqual(process_refusal(rows, 999)[0]["reason"], "mycity_measurement_active:scale-rare-batch")

    def test_ignores_unrelated_headless_command(self):
        rows = [{"pid": 31, "ppid": 1, "comm": "mycity-headless", "args": "mycity-headless help"}]
        self.assertEqual(process_refusal(rows, 999), [])

if __name__ == "__main__":
    unittest.main()
