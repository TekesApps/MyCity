#!/usr/bin/env python3
"""Fail-closed launcher for candidate03's native rare-batch observer. It never builds."""
import hashlib
import fcntl
import json
import os
import re
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path
from contextlib import contextmanager
from observer_contract import classify_observer_report
from report_contract import classify_model_report, PENDING_FORMAL

HERE = Path(__file__).resolve().parent
REPO = Path("/Users/frankqin/dev/MyCity")
TARGET = REPO / "target"
SOURCE_FILE = HERE / "source.json"
KINDS = ("claims", "source")
PHASES = ("smoke", "formal")
SOURCE_KEYS = {"schema", "base_source", "candidate_source", "build", "anchors", "acceptance", "policy", "reports", "storage", "limits"}
HEX64 = set("0123456789abcdef")
BASE_SOURCE_ARCHIVE_SHA256 = "84c450c2c866578b02205030c7587df1dbb719660422fe64865ae62fe2ce908d"
BASE_SOURCE_FINGERPRINT = "32c6e61b9565545177c330f34455611b329fbe1cb38591ec5f6e7879731c4da2"
BASE_LOCK_SHA256 = "7da5c54a8499a07cbc71dcecce0c0095d4af3b8b6e5052783f20d188037b6dd6"
BASE_BUSINESS_FILES = {
    "fixtures/m0-t13a-acceptance.json": "876ea995ea7834bfcea59b2ef8fa56d502aed9006477bcc67bcaa3f5cd944508",
    "fixtures/m0-t13a-full-opening-candidate.json": "04c113c62b0b682f94f9abfbde7618b87bd972f3931504366be9e07c130b4726",
}
SOURCE_SCOPE_ROOTS = ("crates/", "fixtures/")
SOURCE_SCOPE_ROOT_FILES = {".cargo/config.toml", "Cargo.toml", "Cargo.lock", "rust-toolchain.toml"}
REPORTS_FIXED = {
    "status": "source_derived_component_checks_not_executed",
    "class6_fields": ["sample_count_gate", "selected_latency_gate"],
    "source_fields": ["sample_count_gate", "selected_latency_gate", "air_cell_sample_count_gate", "air_cell_latency_gate", "eligible_linked_air_cell_samples", "air_cell_sample_admission_linkage"],
    "smoke_air_cell_status": "not_applicable_smoke_functional_only",
    "formal_air_cell_sample_status": "sample_count_sufficient_only",
    "formal_air_cell_latency_status": "passed_conservative_1us_bounds",
    "formal_rare_gate": PENDING_FORMAL,
}


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def need(condition, message):
    if not condition:
        raise RuntimeError(message)


def safe_file(root, relative):
    need(not Path(root).is_symlink(), "pinned root itself cannot be a symlink")
    relative_path = Path(relative)
    need(not relative_path.is_absolute() and ".." not in relative_path.parts, f"unsafe relative path: {relative}")
    original = Path(root) / relative_path
    cursor = Path(root).resolve(strict=True)
    for part in Path(relative).parts:
        cursor = cursor / part
        need(not cursor.is_symlink(), f"symlink in pinned path: {relative}")
    path = original.resolve(strict=True)
    base = Path(root).resolve(strict=True)
    need(path.is_relative_to(base), f"path escapes pinned root: {relative}")
    need(path.is_file() and not path.is_symlink(), f"not a regular pinned file: {relative}")
    return path


def hash_matches(path, expected, label):
    need(len(expected) == 64 and set(expected) <= HEX64, f"invalid {label} digest")
    actual = sha256(path)
    need(actual == expected, f"{label} digest mismatch: {actual}")
    return actual


def source_fingerprint(zip_path):
    digest = hashlib.sha256()
    with zipfile.ZipFile(zip_path) as frozen:
        names = set(frozen.namelist())
        need(len(names) == len(frozen.infolist()), "source archive has duplicate member names")
        expected = {name for name in names if name in SOURCE_SCOPE_ROOT_FILES or name.startswith(SOURCE_SCOPE_ROOTS)}
        need(names == expected, "source archive contains files outside candidate03 build.rs compile scope")
        need(SOURCE_SCOPE_ROOT_FILES <= names, "source archive missing a candidate03 build.rs root input")
        for info in sorted(frozen.infolist(), key=lambda row: row.filename):
            name = info.filename
            name_bytes = name.encode("utf-8")
            digest.update(len(name_bytes).to_bytes(8, "little"))
            digest.update(name_bytes)
            digest.update(info.file_size.to_bytes(8, "little"))
            with frozen.open(info) as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b""):
                    digest.update(block)
    return digest.hexdigest()


def archive_file_sha256(archive, name):
    digest = hashlib.sha256()
    with zipfile.ZipFile(archive) as frozen, frozen.open(name) as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def contains_bytes(path, needle):
    overlap = b""
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            chunk = overlap + block
            if needle in chunk:
                return True
            overlap = chunk[-max(0, len(needle) - 1):]
    return False


def parse_ps(output):
    """Parse only `ps -axo pid=,ppid=,comm=`; comm can contain spaces.

    Never append an args column to this format: ps does not escape either
    column, so the boundary is ambiguous on the HP P900 volume.
    """
    rows = []
    for line in output.splitlines():
        if not line.strip():
            continue
        fields = line.strip().split(maxsplit=2)
        need(len(fields) == 3, "malformed process inventory row")
        try:
            pid = int(fields[0])
            ppid = int(fields[1])
        except ValueError:
            raise RuntimeError("malformed process inventory identity") from None
        rows.append({"pid": pid, "ppid": ppid, "comm": fields[2], "args": "",
                     "args_available": False})
    need(bool(rows), "empty process inventory cannot establish an idle host")
    return rows


def process_refusal(rows, own_pid):
    refused = []
    compilers = {"cargo", "rustc", "rustc_driver", "cargo-clippy", "clippy-driver", "rustdoc"}
    measured = {"joint-endurance", "layout-session", "scale-endurance", "steady-run", "speed-run", "scale-rare-batch", "native-observe"}
    for row in rows:
        if row["pid"] == own_pid:
            continue
        argv = row.get("args", "").split()
        exe = Path(row["comm"]).name
        base = Path(argv[0]).name if argv else exe
        reason = None
        if exe in compilers or base in compilers:
            reason = "compiler_or_rustdoc_active"
        elif exe == "mycity-headless" or base == "mycity-headless":
            if row.get("args_available") is False or not argv:
                reason = "unclassified_headless_active"
            elif len(argv) > 1 and argv[1] in measured:
                reason = "mycity_measurement_active:" + argv[1]
            elif "--" in argv:
                tail = argv[argv.index("--") + 1:]
                if len(tail) > 1 and Path(tail[0]).name == "mycity-headless" and tail[1] in measured:
                    reason = "mycity_measurement_active:" + tail[1]
        if reason:
            refused.append({"pid": row["pid"], "exe": exe, "reason": reason})
    return refused


def load_source():
    need(SOURCE_FILE.is_file(), "source.json missing: no candidate03 source identity is pinned")
    source = read_report(SOURCE_FILE)
    need(set(source) == SOURCE_KEYS, "source.json fields do not match the required strict schema")
    need(source.get("schema") == "mycity-m0-t13a-rare-control-source-v1", "unsupported source schema")
    need(set(source["base_source"]) == {"archive_path", "archive_sha256", "fingerprint", "cargo_lock_sha256", "business_manifest_path", "business_manifest_sha256"}, "base source receipt fields mismatch")
    need(set(source["candidate_source"]) == {"tree_path", "archive_path", "archive_sha256", "manifest_path", "manifest_sha256", "fingerprint", "cargo_lock_sha256", "lock_sha256", "diff_allowlist_path", "diff_allowlist_sha256"}, "candidate source receipt fields mismatch")
    need(set(source["build"]) == {"binary", "binary_sha256", "receipt", "receipt_sha256", "receipt_schema", "embedded_fingerprint"}, "build receipt fields mismatch")
    need(set(source["anchors"]) == {"path", "manifest", "manifest_sha256"}, "anchor receipt fields mismatch")
    need(set(source["acceptance"]) == {"path", "sha256"} and set(source["policy"]) == {"path", "sha256"}, "acceptance/policy receipt fields mismatch")
    need(set(source["storage"]) == {"mount", "volume_uuid", "filesystem", "work_link", "target_link", "free_floor_bytes"}, "external storage receipt fields mismatch")
    need(set(source["limits"]) == {"world_bytes", "raw_metrics_bytes", "per_trial_raw_bytes", "histogram_minimum_bucket_bytes", "swap_growth_bytes", "combined_logs_bytes", "pressure_normal_value", "admission_seconds"}, "frozen limit fields mismatch")
    need(source["limits"]["admission_seconds"] == 120, "admission duration differs from the frozen 120-second rule")
    for key, frozen in {"world_bytes": 20 * 1024 ** 3,
                        "raw_metrics_bytes": 128 * 1024 ** 2,
                        "per_trial_raw_bytes": 128 * 1024,
                        "histogram_minimum_bucket_bytes": 40_001 * 4,
                        "swap_growth_bytes": 256 * 1024 ** 2,
                        "combined_logs_bytes": 256 * 1024 ** 2,
                        "pressure_normal_value": 1}.items():
        need(type(source["limits"][key]) is int and source["limits"][key] == frozen,
             "frozen limit differs: " + key)
    need(source["storage"]["free_floor_bytes"] == 2 * 1024 ** 3, "free floor differs from frozen 2GiB")
    from admission import HP_VOLUME_UUID
    storage = source["storage"]
    need(storage["mount"] == "/Volumes/HP P900"
         and storage["volume_uuid"] == HP_VOLUME_UUID
         and storage["filesystem"].lower() == "apfs"
         and storage["work_link"] == str(REPO / "work")
         and storage["target_link"] == str(TARGET), "source receipt external storage identity differs")
    need(source["reports"] == REPORTS_FIXED, "candidate report contract must match the source-derived fixed schema; arbitrary field paths are rejected")
    base = source["base_source"]
    need(base["archive_sha256"] == BASE_SOURCE_ARCHIVE_SHA256 and base["fingerprint"] == BASE_SOURCE_FINGERPRINT and base["cargo_lock_sha256"] == BASE_LOCK_SHA256, "pinned 32c baseline identity mismatch")
    base_archive = Path(base["archive_path"]).resolve(strict=True)
    base_business = Path(base["business_manifest_path"]).resolve(strict=True)
    hash_matches(base_archive, base["archive_sha256"], "32c baseline archive")
    hash_matches(base_business, base["business_manifest_sha256"], "32c business manifest")
    need(source_fingerprint(base_archive) == BASE_SOURCE_FINGERPRINT, "32c baseline compile-scope fingerprint mismatch")
    need(archive_file_sha256(base_archive, "Cargo.lock") == BASE_LOCK_SHA256, "32c baseline Cargo.lock mismatch")
    business = json.loads(base_business.read_text())
    business_rows = business.get("files") if isinstance(business, dict) else business
    need(isinstance(business_rows, list), "32c business manifest is invalid")
    business_map = {row["path"]: row["sha256"] for row in business_rows if set(row) == {"path", "sha256"}}
    need(business_map == BASE_BUSINESS_FILES, "32c business files differ from the frozen baseline")
    for name, expected in business_map.items():
        need(archive_file_sha256(base_archive, name) == expected, "32c business archive content mismatch: " + name)

    candidate = source["candidate_source"]
    tree = Path(candidate["tree_path"]).resolve(strict=True)
    need(tree.is_dir() and not (tree / ".git").exists(), "candidate source must be a frozen extracted tree without .git")
    archive = Path(candidate["archive_path"]).resolve(strict=True)
    manifest_path = Path(candidate["manifest_path"]).resolve(strict=True)
    need(not archive.is_relative_to(tree) and not manifest_path.is_relative_to(tree), "candidate archive and manifest must live outside the extracted source tree")
    lock = tree / "Cargo.lock"
    hash_matches(archive, candidate["archive_sha256"], "candidate source archive")
    hash_matches(manifest_path, candidate["manifest_sha256"], "candidate source file manifest")
    hash_matches(lock, candidate["cargo_lock_sha256"], "candidate Cargo.lock")
    need(candidate["cargo_lock_sha256"] == candidate["lock_sha256"], "candidate Cargo.lock identity fields disagree")
    manifest = json.loads(manifest_path.read_text())
    entries = manifest.get("files") if isinstance(manifest, dict) else manifest
    need(isinstance(entries, list) and entries, "candidate source manifest is empty")
    manifest_by_name = {}
    for row in entries:
        need(set(row) == {"path", "sha256"}, "invalid candidate file-manifest row")
        name = row["path"]
        need(name == ".cargo/config.toml" or name in SOURCE_SCOPE_ROOT_FILES or name.startswith(SOURCE_SCOPE_ROOTS), "candidate manifest includes file outside the candidate03 build.rs scope")
        need(name not in manifest_by_name, "duplicate candidate manifest path")
        file_path = safe_file(tree, name)
        hash_matches(file_path, row["sha256"], "candidate source file " + name)
        manifest_by_name[name] = row["sha256"]
    disk_names = {p.relative_to(tree).as_posix() for p in tree.rglob("*") if p.is_file()}
    need(not any(p.is_symlink() for p in tree.rglob("*")), "candidate source tree contains a symlink")
    need(disk_names == set(manifest_by_name), "candidate extracted tree has missing/unmanifested files")
    with zipfile.ZipFile(archive) as frozen:
        need(frozen.testzip() is None and len(frozen.infolist()) == len(manifest_by_name) and set(frozen.namelist()) == set(manifest_by_name), "candidate archive and complete source manifest differ")
        for name, expected in manifest_by_name.items():
            need(archive_file_sha256(archive, name) == expected, "candidate archive content differs from manifest: " + name)
    need(source_fingerprint(archive) == candidate["fingerprint"], "candidate archive does not produce the claimed build.rs fingerprint")

    with zipfile.ZipFile(base_archive) as frozen_base:
        base_names = set(frozen_base.namelist())
    candidate_names = set(manifest_by_name)
    allow_path = Path(candidate["diff_allowlist_path"]).resolve(strict=True)
    hash_matches(allow_path, candidate["diff_allowlist_sha256"], "base32c diff allowlist")
    allowed_rows = json.loads(allow_path.read_text())
    allowed = set(allowed_rows["paths"] if isinstance(allowed_rows, dict) else allowed_rows)
    base_hashes = {name: archive_file_sha256(base_archive, name) for name in base_names}
    candidate_hashes = manifest_by_name
    actual_diff = {name for name in base_names | candidate_names if base_hashes.get(name) != candidate_hashes.get(name)}
    need(actual_diff == allowed, "candidate changes differ from the explicit 32c base diff allowlist")

    b = source["build"]
    need(b["receipt_schema"] == "mycity-build-receipt-v1" and b["embedded_fingerprint"] is True, "build identity contract incomplete")
    binary_original = Path(b["binary"])
    receipt_original = Path(b["receipt"])
    need(not binary_original.is_symlink() and not receipt_original.is_symlink(), "binary/build receipt must be direct regular files")
    binary = binary_original.resolve(strict=True)
    receipt = receipt_original.resolve(strict=True)
    need(binary.is_file() and receipt.is_file(), "candidate binary/build receipt missing")
    need(binary.is_relative_to((REPO / "work").resolve(strict=True))
         and not binary.is_relative_to(TARGET.resolve(strict=True)),
         "measured executable must be preserved in external work, outside the mutable shared target")
    hash_matches(binary, b["binary_sha256"], "candidate binary")
    hash_matches(receipt, b["receipt_sha256"], "build receipt")
    need(contains_bytes(binary, candidate["fingerprint"].encode()), "binary does not embed the pinned source fingerprint")
    build = json.loads(receipt.read_text())
    need(build.get("schema") == "mycity-build-receipt-v1", "unsupported build receipt")
    need(build.get("source_fingerprint") == candidate["fingerprint"] and build.get("source_archive_sha256") == candidate["archive_sha256"], "build receipt source identity mismatch")
    need(build.get("cargo_lock_sha256") == candidate["cargo_lock_sha256"] and build.get("binary_sha256") == b["binary_sha256"], "build receipt binary/dependency identity mismatch")
    need(build.get("base_source_archive_sha256") == base["archive_sha256"] and build.get("diff_allowlist_sha256") == candidate["diff_allowlist_sha256"], "build receipt baseline/diff identity mismatch")
    need(build.get("exit_code") == 0 and isinstance(build.get("command"), list) and build["command"], "build receipt lacks successful command provenance")
    need(isinstance(build.get("environment_allowlist"), dict) and isinstance(build.get("target_path"), str), "build receipt lacks allowlisted environment or target provenance")
    need(Path(build["target_path"]).resolve(strict=True) == TARGET.resolve(strict=True), "build receipt does not reference the shared external target")

    anchors = Path(source["anchors"]["path"]).resolve(strict=True)
    anchor_manifest = safe_file(anchors, source["anchors"]["manifest"])
    hash_matches(anchor_manifest, source["anchors"]["manifest_sha256"], "anchors manifest")
    am = json.loads(anchor_manifest.read_text())
    anchor_rows = am.get("files") if isinstance(am, dict) else am
    need(isinstance(anchor_rows, list) and anchor_rows, "anchors manifest has no files")
    for row in anchor_rows:
        need(set(row) == {"path", "sha256"}, "invalid anchors-manifest row")
        hash_matches(safe_file(anchors, row["path"]), row["sha256"], "anchor " + row["path"])
    for name in ("acceptance", "policy"):
        pin = source[name]
        p = Path(pin["path"]).resolve(strict=True)
        hash_matches(p, pin["sha256"], name)
        member = ("fixtures/m0-t13a-acceptance.json" if name == "acceptance"
                  else "fixtures/m0-t13a-real-policy-candidate.json")
        need(pin["sha256"] == archive_file_sha256(base_archive, member),
             name + " differs from fixed 32c baseline")
        need(manifest_by_name.get(member) == pin["sha256"],
             name + " differs from compiled candidate input")
    return source, binary, archive, manifest_path, lock, receipt, anchor_manifest, base_archive, base_business, allow_path, tree


def reject_duplicate_keys(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, "duplicate JSON key: " + key)
        result[key] = value
    return result


def read_report(path):
    need(path.is_file() and not path.is_symlink(), "missing direct report: " + str(path))
    need(path.stat().st_size <= 4 * 1024 * 1024, "report exceeds fixed inspection bound")
    def reject_constant(value):
        raise RuntimeError("non-finite JSON constant: " + value)
    value = json.loads(path.read_text(), object_pairs_hook=reject_duplicate_keys,
                       parse_constant=reject_constant)
    need(isinstance(value, dict), "report must be an object")
    return value


def run_directory(kind, phase):
    need(kind in KINDS and phase in PHASES, "unsupported batch mode")
    prefix = "rb3-" + ("c" if kind == "claims" else "s") + ("s" if phase == "smoke" else "f")
    return (REPO / "work").resolve(strict=True) / (prefix + "-01")


def collect_inspection(source, binary, kind, phase):
    # Read only; the location and expected command come from the pinned contract,
    # never caller-supplied report paths or "passed" flags.
    observer_root = (run_directory(kind, phase) / "observed").resolve(strict=True)
    model_root = observer_root / "model"
    anchors = Path(source["anchors"]["path"]).resolve(strict=True)
    expected_command = [str(binary), "scale-rare-batch", str(anchors), str(model_root), kind, phase]
    observer_path = observer_root / "observer-report.json"
    model_path = model_root / "report.json"
    observer = classify_observer_report(read_report(observer_path),
        source["candidate_source"]["fingerprint"], source["build"]["binary_sha256"], expected_command)
    model = classify_model_report(read_report(model_path),
        source["candidate_source"]["fingerprint"], kind, phase)
    observer_components = (
        observer.get("identity_matches") and observer.get("wrapper_complete")
        and observer.get("summary_has_no_reported_coverage_holes")
        and observer.get("recorded_guard_bounds") == "within_frozen_bounds"
        and observer.get("diagnostic_hot_contract") == "arithmetically_consistent"
        and observer.get("sampling_cadence_recorded")
    )
    model_components = (
        model.get("identity_matches") and model.get("collection_complete")
        and (model.get("functional_smoke_report") if phase == "smoke" else
             (model.get("layout_restore_report")
              and model.get("count_component") == "sufficient"
              and model.get("latency_component") == "within_original_bounds"
              and model.get("model_keeps_formal_audit_pending")))
    )
    components = bool(observer_components and model_components)
    result = {"schema": "mycity-rare-component-inspection-v1", "stratum": kind,
              "mode": phase, "observer": observer, "model": model,
              "reported_components_sufficient_only": components,
              "report_hashes": {"observer": sha256(observer_path), "model": sha256(model_path)},
              "artifact_location": str(observer_root),
              "storage": "external HP P900 USB/APFS SSD",
              "raw_evidence_audit": "pending", "memory_16gb_gate": "not_run", "full_M0": "not_accepted"}
    return result


def inspect_reports(kind, phase):
    source, binary, *_ = load_source()
    result = collect_inspection(source, binary, kind, phase)
    print(json.dumps(result, indent=2, allow_nan=False))
    # Exit zero means only these reported components suffice. Raw audits and
    # physical memory remain explicitly pending even in this case.
    return 0 if result["reported_components_sufficient_only"] else 1


def offline_audit(kind, phase):
    from batch_audit import audit_batch, verify_reported_histogram
    refuse_active_jobs()
    verify_helper_receipt()
    source, binary, *_ = load_source()
    root = run_directory(kind, phase)
    output = root / "offline-numeric-audit.json"
    need(not output.exists(), "offline numeric audit already exists; preserve it")
    inspection = collect_inspection(source, binary, kind, phase)
    need(inspection["observer"].get("wrapper_complete")
         and inspection["model"].get("identity_matches")
         and inspection["model"].get("collection_complete"),
         "offline audit requires a terminal complete collection with verified identities")
    model_root = root / "observed/model"
    report_path = model_root / "report.json"
    model_report = read_report(report_path)
    source_hash = sha256(SOURCE_FILE)
    helpers = helper_source_hashes()
    numeric = audit_batch(model_root, source["candidate_source"]["fingerprint"],
                          source["build"]["binary_sha256"], kind, phase)
    fields = [("L2_claims_batch" if kind == "claims" else "air_source_page",
               "selected_latency_gate", "sample_count_gate")]
    if kind == "source":
        fields.append(("air_cell_page", "air_cell_latency_gate", "air_cell_sample_count_gate"))
    for name, latency_field, count_field in fields:
        values = numeric["classes"][name]
        values["rust_histogram_crosscheck"] = verify_reported_histogram(
            values["numeric"], model_report[latency_field]["histogram"])
        if phase == "formal":
            need(values["claimed_trial_rows_with_samples"] == model_report[count_field]["qualified_trials"],
                 "raw-range trial rows differ from reported qualified trials")
    need(sha256(report_path) == inspection["report_hashes"]["model"]
         and sha256(SOURCE_FILE) == source_hash and helpers == helper_source_hashes(),
         "source/support/model report changed during offline QA")
    numeric["input_report_hashes"] = inspection["report_hashes"]
    numeric["source_receipt_sha256"] = source_hash
    numeric["storage"] = "external HP P900 USB/APFS SSD"
    write_new_json(output, numeric)
    # Smoke proves byte/range arithmetic only; it cannot satisfy 200 samples.
    return 0 if phase == "smoke" or all(
        value["numeric"]["numeric_latency_gate"] == "passed_numeric_only"
        for value in numeric["classes"].values()) else 1


def write_new_json(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def helper_source_hashes():
    return {p.name: sha256(p) for p in sorted(HERE.iterdir())
            if p.is_file() and (p.suffix == ".py" or p.name in ("source.schema.json", "README.md"))}


def refuse_active_jobs():
    from admission import SAFE_CHILD_ENV
    output = subprocess.check_output(["/bin/ps", "-axo", "pid=,ppid=,comm="],
                                     env=dict(SAFE_CHILD_ENV), timeout=5).decode()
    blockers = process_refusal(parse_ps(output), os.getpid())
    need(not blockers, "active compiler/model prevents a new validation: " + json.dumps(blockers))


def helper_command():
    return [sys.executable, "-m", "unittest", "discover", "-s", str(HERE), "-p", "test_*.py"]


@contextmanager
def validation_lock():
    # One controller action at a time even if two CLI callers pass the live
    # process check before either native child has been spawned.
    lock = REPO / ".git/mycity-rare-validation.lock"
    need(not lock.is_symlink(), "validation lock cannot be a symlink")
    with lock.open("a+") as stream:
        try:
            fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError("another rare validation controller holds the launch lock") from None
        try:
            yield
        finally:
            fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


def test_helpers():
    # Explicit action only; no invocation during a formal measurement.
    refuse_active_jobs()
    root = HERE / "helper-validation-01"
    need(not root.exists(), "helper-validation-01 exists; preserve it, do not overwrite")
    root.mkdir()
    before = helper_source_hashes()
    from admission import SAFE_CHILD_ENV
    started = time.monotonic()
    with (root / "stdout").open("xb") as out, (root / "stderr").open("xb") as err:
        status = subprocess.run(helper_command(), cwd=REPO, env=dict(SAFE_CHILD_ENV),
                                stdout=out, stderr=err, check=False).returncode
    unchanged = before == helper_source_hashes()
    write_new_json(root / "receipt.json", {
        "schema": "mycity-rare-helper-validation-v1", "command": helper_command(),
        "exit_code": status, "source_files": before, "source_unchanged": unchanged,
        "stdout_sha256": sha256(root / "stdout"), "stderr_sha256": sha256(root / "stderr"),
        "wall_seconds": time.monotonic() - started, "acceptance_measurement": False,
    })
    return 0 if status == 0 and unchanged else 1


def verify_helper_receipt():
    root = HERE / "helper-validation-01"
    receipt = read_report(root / "receipt.json")
    need(receipt.get("schema") == "mycity-rare-helper-validation-v1"
         and receipt.get("command") == helper_command()
         and type(receipt.get("exit_code")) is int and receipt["exit_code"] == 0
         and receipt.get("source_unchanged") is True
         and receipt.get("source_files") == helper_source_hashes(),
         "helper regression receipt missing, failed or stale")
    hash_matches(root / "stdout", receipt["stdout_sha256"], "helper stdout")
    hash_matches(root / "stderr", receipt["stderr_sha256"], "helper stderr")
    stderr = (root / "stderr").read_text()
    ran = re.search(r"^Ran ([1-9][0-9]*) tests? in .+s$", stderr, re.MULTILINE)
    need(ran is not None and stderr.rstrip().endswith("OK"), "helper transcript does not show nonempty successful tests")
    return root / "receipt.json"


def launch(kind, phase):
    from admission import run_admission, SAFE_CHILD_ENV
    refuse_active_jobs()
    helper_receipt = verify_helper_receipt()
    source, binary, *_ = load_source()
    source_hash = sha256(SOURCE_FILE)
    helpers = helper_source_hashes()
    root = run_directory(kind, phase)
    need(not root.exists() and not root.is_symlink(), "run already exists; never overwrite or automatically retry")
    observer_root = root / "observed"
    socket = observer_root / "model/normal-pool/pool.sock"
    need(len(os.fsencode(socket)) + 1 <= 104, "resolved Unix socket exceeds macOS sun_path capacity")
    if phase == "formal":
        smoke_root = run_directory(kind, "smoke")
        smoke = read_report(smoke_root / "execution.json")
        need(smoke.get("source_fingerprint") == source["candidate_source"]["fingerprint"]
             and smoke.get("binary_sha256") == source["build"]["binary_sha256"]
             and smoke.get("source_receipt_sha256") == source_hash
             and smoke.get("helper_source_files") == helpers
             and smoke.get("exit_code") == 0, "formal batch requires successful same-identity smoke execution")
        fresh_smoke = collect_inspection(source, binary, kind, "smoke")
        need(fresh_smoke["reported_components_sufficient_only"]
             and fresh_smoke["report_hashes"] == smoke.get("report_hashes"),
             "smoke components missing, failed, or changed")
    root.mkdir()
    support = root / "controller-source"
    support.mkdir()
    for name in helpers:
        shutil.copy2(HERE / name, support / name)
        hash_matches(support / name, helpers[name], "controller support " + name)
    shutil.copy2(SOURCE_FILE, root / "source.json")
    shutil.copy2(helper_receipt, root / "helper-receipt.json")
    admitted = run_admission(root / "admission")
    need(admitted["status"] == "admitted_host_prerequisites_only", "host admission denied; model not started")
    # Revalidate mutable inputs outside the measured window, then close with
    # another live prerequisite observation immediately before native launch.
    load_source()
    need(source_hash == sha256(SOURCE_FILE) and helpers == helper_source_hashes(), "controller/source changed during admission")
    refuse_active_jobs()
    from admission import _probe_storage, _probe_pressure_and_swap, MAX_SAMPLE_GAP_SECONDS, MAX_SWAP_GROWTH_BYTES
    _probe_storage(subprocess.check_output, shutil.disk_usage)
    pressure, swap = _probe_pressure_and_swap(subprocess.check_output)
    need(time.monotonic() - admitted["window_ended_monotonic_seconds"] <= MAX_SAMPLE_GAP_SECONDS,
         "admission window became stale before launch")
    need(pressure == 1 and swap - admitted["initial_swap_used_bytes"] <= MAX_SWAP_GROWTH_BYTES,
         "pressure or swap changed after admission")
    anchors = str(Path(source["anchors"]["path"]).resolve(strict=True))
    model_command = [str(binary), "scale-rare-batch", anchors, str(observer_root / "model"), kind, phase]
    command = [str(binary), "native-observe", str(observer_root), "--", *model_command]
    write_new_json(root / "launch.json", {"command": command,
        "source_fingerprint": source["candidate_source"]["fingerprint"],
        "binary_sha256": source["build"]["binary_sha256"],
        "source_receipt_sha256": source_hash, "helper_source_files": helpers,
        "storage": "external HP P900 USB/APFS SSD", "full_M0": "not_accepted"})
    started = time.monotonic()
    # The native observer owns lifecycle, identity, pressure and its wall guard.
    # Do not inject MYCITY_* or create a competing Python measurement observer.
    with (root / "stdout").open("xb") as out, (root / "stderr").open("xb") as err:
        process = subprocess.Popen(command, cwd=REPO, env=dict(SAFE_CHILD_ENV),
                                   stdout=out, stderr=err, start_new_session=True)
        write_new_json(root / "observer-process.json", {
            "pid": process.pid, "command": command,
            "source_fingerprint": source["candidate_source"]["fingerprint"],
            "binary_sha256": source["build"]["binary_sha256"],
            "spawn_parent_monotonic_seconds": time.monotonic(),
            "identity_note": "PID alone is not identity; use native observer birth/lifecycle evidence",
        })
        try:
            status = process.wait()
        except BaseException as error:
            # subprocess.run kills its child on an interrupted wait. That can
            # strand native descendants. Preserve the original observer and
            # its PID/command instead; the live-process gate prevents restart.
            write_new_json(root / "wait-interrupted.json", {
                "observer_pid": process.pid, "error_class": type(error).__name__,
                "action": "observer_not_killed_or_restarted; inspect_original_process",
                "raw_evidence_audit": "pending", "full_M0": "not_accepted",
            })
            raise
    identity_unchanged = (source_hash == sha256(SOURCE_FILE) and helpers == helper_source_hashes()
                          and sha256(binary) == source["build"]["binary_sha256"])
    result = {"exit_code": status, "wall_seconds": time.monotonic() - started,
        "source_fingerprint": source["candidate_source"]["fingerprint"],
        "binary_sha256": source["build"]["binary_sha256"],
        "source_receipt_sha256": source_hash, "helper_source_files": helpers,
        "identity_unchanged": identity_unchanged, "raw_evidence_audit": "pending",
        "full_M0": "not_accepted", "memory_16gb_gate": "not_run"}
    try:
        inspection = collect_inspection(source, binary, kind, phase)
        write_new_json(root / "component-inspection.json", inspection)
        result.update({"report_hashes": inspection["report_hashes"],
                       "reported_components_sufficient_only": inspection["reported_components_sufficient_only"]})
    except Exception as error:
        result.update({"inspection_error_class": type(error).__name__, "reported_components_sufficient_only": False})
    write_new_json(root / "execution.json", result)
    return 0 if status == 0 and identity_unchanged and result["reported_components_sufficient_only"] else 1


def plan():
    print(json.dumps({
        "status": "source_only_not_run",
        "source_json": str(SOURCE_FILE),
        "source_json_present": SOURCE_FILE.is_file(),
        "baseline_only": {
            "source_archive_sha256": BASE_SOURCE_ARCHIVE_SHA256,
            "source_fingerprint": BASE_SOURCE_FINGERPRINT,
            "cargo_lock_sha256": BASE_LOCK_SHA256,
        },
        "required_before_run": [
            "candidate03 frozen extracted source tree, compile-scope archive, complete file manifest, and exact diff allowlist against the pinned 32c baseline",
            "candidate embedded build fingerprint, binary SHA256, and successful build receipt",
            "anchors, acceptance, policy, storage profile, and unchanged frozen limits",
            "execute helper regression tests and freeze the final Rust report layout before enabling launch; source-derived component classifiers exist but are untested",
        ],
        "class6_fields": ["sample_count_gate", "selected_latency_gate"],
        "source_class7_fields": [
            "air_cell_sample_count_gate", "air_cell_latency_gate",
            "eligible_linked_air_cell_samples", "air_cell_sample_admission_linkage",
        ],
        "class7_status_contract": {
            "smoke": "not_applicable_smoke_functional_only",
            "formal_sample_count": "sample_count_sufficient_only",
            "formal_latency": "passed_conservative_1us_bounds",
            "formal_rare_gate": PENDING_FORMAL,
        },
        "measurement": "not_run",
        "full_M0": "not_run",
        "memory_16GB": "not_run",
    }, indent=2))


def main(argv):
    if argv in ([], ["--help"], ["--plan"]):
        plan()
        return 0
    if argv == ["--test-helpers"]:
        with validation_lock():
            return test_helpers()
    if len(argv) == 3 and argv[0] == "--inspect" and argv[1] in KINDS and argv[2] in PHASES:
        return inspect_reports(argv[1], argv[2])
    if len(argv) == 3 and argv[0] == "--audit" and argv[1] in KINDS and argv[2] in PHASES:
        with validation_lock():
            return offline_audit(argv[1], argv[2])
    if len(argv) != 3 or argv[0] != "--run" or argv[1] not in KINDS or argv[2] not in PHASES:
        raise SystemExit("usage: run.py [--plan] | --test-helpers | --inspect claims|source smoke|formal | --audit claims|source smoke|formal | --run claims|source smoke|formal")
    with validation_lock():
        return launch(argv[1], argv[2])

if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
