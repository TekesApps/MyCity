"""Fixed component report checks, derived from candidate03 Rust source.

Source-only, not executed. These checks do not certify raw evidence, identity
coverage, snapshot overlap, physical memory, or the complete M0 rare-class gate.
"""

PENDING_FORMAL = "not_evaluated_pending_original_latency_and_observer_audit"
SMOKE = "not_applicable_smoke_functional_only"
LATENCY_PASS = "passed_conservative_1us_bounds"


def integer(value):
    return type(value) is int and value >= 0


def count_component(value):
    if not isinstance(value, dict):
        return False
    return (
        value.get("status") == "sample_count_sufficient_only"
        and value.get("minimum_trials") == 200
        and value.get("minimum_samples") == 200
        and value.get("completed_trials") == 200
        and value.get("qualified_trials") == 200
        and integer(value.get("qualified_samples"))
        and value["qualified_samples"] >= 200
        and value.get("all_trials_have_qualifying_sample") is True
    )


def latency_component(value, expected_class):
    if not isinstance(value, dict) or value.get("class") != expected_class:
        return False
    histogram = value.get("histogram")
    if not isinstance(histogram, dict):
        return False
    p95 = histogram.get("p95")
    p99 = histogram.get("p99")
    return (
        value.get("status") == LATENCY_PASS
        and histogram.get("gate") == LATENCY_PASS
        and integer(histogram.get("samples"))
        and histogram["samples"] >= 200
        and isinstance(p95, dict)
        and isinstance(p99, dict)
        and integer(p95.get("upper_inclusive_ns"))
        and integer(p99.get("upper_inclusive_ns"))
        and p95["upper_inclusive_ns"] <= 20_000_000
        and p99["upper_inclusive_ns"] <= 40_000_000
        and p95["upper_inclusive_ns"] <= p99["upper_inclusive_ns"]
        and p95.get("nearest_rank") == (histogram["samples"] * 95 + 99) // 100
        and p99.get("nearest_rank") == (histogram["samples"] * 99 + 99) // 100
    )


def sample_populations_match(counts, latency):
    return (isinstance(counts, dict) and isinstance(latency, dict)
            and isinstance(latency.get("histogram"), dict)
            and integer(counts.get("qualified_samples"))
            and counts["qualified_samples"] == latency["histogram"].get("samples"))


def classify_model_report(report, source, kind, phase):
    if kind not in ("claims", "source") or phase not in ("smoke", "formal"):
        raise ValueError("unsupported fixed report mode")
    expected_trials = 1 if phase == "smoke" else 200
    identity_matches = (
        isinstance(report, dict)
        and report.get("schema") == "mycity-rare-batch-report-v1"
        and report.get("source_sha256") == source
        # Rust Mode derives Serialize without rename_all. CLI arguments use
        # lowercase, while actual report values are the enum variant names.
        and report.get("mode") == {"smoke": "Smoke", "formal": "Formal"}[phase]
        and report.get("stratum") == kind
    )
    if not identity_matches:
        return {"identity_matches": False, "collection_complete": False,
                "formal_rare_gate": "not_verified_report_identity", "full_M0": "not_accepted"}
    complete = (report.get("planned_trials") == expected_trials
                and report.get("completed_trials") == expected_trials)
    shutdown = report.get("l1_and_pool_shutdown", {})
    restore = shutdown.get("restore_report", {}) if isinstance(shutdown, dict) else {}
    recovered = (isinstance(restore, dict) and restore.get("cold_reopen_and_scan") == "passed"
                 and shutdown.get("layout_stopped_by_owner_pipe") is True)
    if phase == "smoke":
        smoke_fields = [report.get("sample_count_gate", {}), report.get("selected_latency_gate", {})]
        if kind == "source":
            smoke_fields += [report.get("air_cell_sample_count_gate", {}), report.get("air_cell_latency_gate", {})]
        functional = (complete and recovered
                      and report.get("actual_status") == "completed_smoke_functional_only"
                      and all(isinstance(v, dict) and v.get("status") == SMOKE for v in smoke_fields))
        return {"identity_matches": True, "collection_complete": complete,
                "functional_smoke_report": functional,
                "count_component": "not_applicable_smoke",
                "latency_component": "not_applicable_smoke",
                "formal_rare_gate": "not_applicable_smoke", "full_M0": "not_accepted"}
    expected_class = "L2_claims_batch" if kind == "claims" else "air_source_page"
    counts = count_component(report.get("sample_count_gate"))
    latency = latency_component(report.get("selected_latency_gate"), expected_class)
    population_matches = sample_populations_match(report.get("sample_count_gate"), report.get("selected_latency_gate"))
    if kind == "source":
        counts = counts and count_component(report.get("air_cell_sample_count_gate"))
        latency = latency and latency_component(report.get("air_cell_latency_gate"), "air_cell_page")
        population_matches = population_matches and sample_populations_match(
            report.get("air_cell_sample_count_gate"), report.get("air_cell_latency_gate"))
    return {
        "identity_matches": True, "collection_complete": complete,
        "layout_restore_report": recovered,
        "count_component": "sufficient" if counts else "not_proven",
        "latency_component": "within_original_bounds" if latency and population_matches else "not_proven",
        "count_and_latency_sample_populations_match": population_matches,
        "model_keeps_formal_audit_pending": report.get("formal_rare_gate") == PENDING_FORMAL,
        "formal_rare_gate": "pending_independent_raw_identity_overlap_and_observer_audit",
        "memory_budget": "not_verified_by_this_component_checker",
        "full_M0": "not_accepted",
    }
