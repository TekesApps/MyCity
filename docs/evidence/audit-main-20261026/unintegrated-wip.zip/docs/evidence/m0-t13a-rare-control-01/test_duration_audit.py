"""Source tests for duration_audit; not executed during the current window."""

from __future__ import annotations

import hashlib
import tempfile
import unittest
from pathlib import Path

from duration_audit import AuditError, _same_file_identity, audit, audit_many


def record(class_index: int, duration_ns: int) -> bytes:
    return bytes((class_index,)) + duration_ns.to_bytes(8, "little")


class DurationAuditTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "cpu.raw"

    def audit_bytes(self, raw: bytes, ranges: list[tuple[int, int]], class_index: int = 2):
        self.path.write_bytes(raw)
        return audit(self.path, hashlib.sha256(raw).hexdigest(), ranges, class_index)

    def make_input(self, name: str, raw: bytes):
        path = Path(self.temp.name) / name
        path.write_bytes(raw)
        return path, hashlib.sha256(raw).hexdigest(), [(0, len(raw))]

    def test_wrong_hash_truncation_and_unaligned_range_are_rejected(self) -> None:
        raw = record(2, 10_000_000)
        self.path.write_bytes(raw)
        with self.assertRaisesRegex(AuditError, "sha256_mismatch"):
            audit(self.path, "0" * 64, [(0, len(raw))], 2)

        self.path.write_bytes(raw[:-1])
        with self.assertRaisesRegex(AuditError, "record_alignment"):
            audit(self.path, hashlib.sha256(raw[:-1]).hexdigest(), [], 2)

        self.path.write_bytes(raw * 2)
        with self.assertRaisesRegex(AuditError, "range_record_alignment"):
            audit(self.path, hashlib.sha256(raw * 2).hexdigest(), [(0, 8)], 2)

    def test_overlapping_and_repeated_ranges_are_rejected(self) -> None:
        raw = record(2, 10_000_000) * 3
        for ranges in [[(0, 18), (9, 27)], [(0, 9), (0, 9)]]:
            with self.subTest(ranges=ranges), self.assertRaisesRegex(AuditError, "ranges_overlap"):
                self.audit_bytes(raw, ranges)

    def test_symlink_is_not_accepted_as_raw_evidence(self) -> None:
        raw = record(2, 10_000_000)
        self.path.write_bytes(raw)
        link = Path(self.temp.name) / "cpu-link.raw"
        link.symlink_to(self.path)
        with self.assertRaisesRegex(AuditError, "not_regular_or_symlink"):
            audit(link, hashlib.sha256(raw).hexdigest(), [(0, len(raw))], 2)

    def test_path_identity_comparison_covers_device_inode_size_and_mtime(self) -> None:
        from types import SimpleNamespace

        original = SimpleNamespace(st_dev=1, st_ino=2, st_size=9, st_mtime_ns=10)
        self.assertTrue(_same_file_identity(original, original))
        for field, value in [
            ("st_dev", 3),
            ("st_ino", 3),
            ("st_size", 18),
            ("st_mtime_ns", 11),
        ]:
            changed = SimpleNamespace(
                st_dev=original.st_dev,
                st_ino=original.st_ino,
                st_size=original.st_size,
                st_mtime_ns=original.st_mtime_ns,
            )
            setattr(changed, field, value)
            self.assertFalse(_same_file_identity(original, changed))

    def test_illegal_classes_and_boolean_integer_inputs_are_rejected(self) -> None:
        raw = record(10, 10_000_000)
        self.path.write_bytes(raw)
        with self.assertRaisesRegex(AuditError, "raw_record_class"):
            audit(self.path, hashlib.sha256(raw).hexdigest(), [(0, 9)], 2)

        with self.assertRaisesRegex(AuditError, "class_index"):
            audit(self.path, hashlib.sha256(raw).hexdigest(), [(0, 9)], True)
        with self.assertRaisesRegex(AuditError, "range_offset_type"):
            audit(self.path, hashlib.sha256(raw).hexdigest(), [(False, 9)], 2)

    def test_199_is_count_insufficient_and_200_reaches_numeric_gates(self) -> None:
        raw_199 = record(2, 10_000_000) * 199
        result_199 = self.audit_bytes(raw_199, [(0, len(raw_199))])
        self.assertEqual(result_199["selected_sample_count"], 199)
        self.assertEqual(result_199["sample_count_gate"]["status"], "insufficient")
        self.assertEqual(result_199["p95_ns"], 10_000_000)
        self.assertEqual(result_199["p99_ns"], 10_000_000)
        self.assertEqual(result_199["maximum_ns"], 10_000_000)
        self.assertEqual(
            result_199["numeric_latency_gate"], "not_evaluable_insufficient_samples"
        )

        raw_200 = record(2, 10_000_000) * 200
        result_200 = self.audit_bytes(raw_200, [(0, len(raw_200))])
        self.assertEqual(result_200["selected_sample_count"], 200)
        self.assertEqual(result_200["sample_count_gate"]["status"], "sufficient")
        self.assertEqual(result_200["numeric_latency_gate"], "passed_numeric_only")
        self.assertEqual(result_200["maximum_ns"], 10_000_000)

    def test_single_long_tail_is_not_trimmed_from_nearest_rank_p99(self) -> None:
        raw = record(2, 10_000_000) * 98 + record(2, 41_000_000)
        result = self.audit_bytes(raw, [(0, len(raw))])
        self.assertEqual(result["selected_sample_count"], 99)
        self.assertEqual(result["p99_ns"], 41_000_000)
        self.assertEqual(result["maximum_ns"], 41_000_000)
        self.assertEqual(
            result["numeric_latency_gate"], "not_evaluable_insufficient_samples"
        )
        self.assertEqual(
            result["eligibility_identity_observer_overlap_normal_memory_full_m0"],
            "not_proven",
        )

    def test_many_single_sample_files_require_200_raw_samples(self) -> None:
        one = record(2, 10_000_000)
        inputs_199 = [self.make_input(f"n199-{i}.raw", one) for i in range(199)]
        result_199 = audit_many(inputs_199, 2)
        self.assertEqual(result_199["file_count"], 199)
        self.assertEqual(result_199["selected_sample_count"], 199)
        self.assertEqual(result_199["numeric_latency_gate"], "not_evaluable_insufficient_samples")

        inputs_200 = [self.make_input(f"n200-{i}.raw", one) for i in range(200)]
        result_200 = audit_many(inputs_200, 2)
        self.assertEqual(result_200["file_count"], 200)
        self.assertEqual(result_200["selected_sample_count"], 200)
        self.assertEqual(result_200["sample_count_gate"]["status"], "sufficient")
        self.assertEqual(result_200["numeric_latency_gate"], "passed_numeric_only")
        self.assertEqual(result_200["independent_trial_count_gate"], "not_proven")

    def test_many_uses_global_quantiles_not_average_per_file_percentiles(self) -> None:
        low = record(2, 1) * 100
        high = record(2, 100) * 100
        result = audit_many(
            [self.make_input("low.raw", low), self.make_input("high.raw", high)], 2
        )
        self.assertEqual(result["selected_sample_count"], 200)
        self.assertEqual(result["p95_ns"], 100)
        self.assertNotEqual(result["p95_ns"], (1 + 100) / 2)
        self.assertEqual(result["files"][0]["range_count"], 1)
        self.assertEqual(len(result["files"][0]["ranges_sha256"]), 64)
        self.assertNotIn("durations", result)

    def test_many_rejects_duplicate_inode_and_any_wrong_file_hash(self) -> None:
        raw = record(2, 10_000_000)
        first = self.make_input("first.raw", raw)
        hardlink = Path(self.temp.name) / "linked.raw"
        try:
            hardlink.hardlink_to(first[0])
        except OSError as exc:
            self.skipTest(f"hard links unavailable: {exc}")
        second = (hardlink, first[1], first[2])
        with self.assertRaisesRegex(AuditError, "duplicate_raw_file_inode"):
            audit_many([first, second], 2)

        wrong_hash = (self.make_input("other.raw", raw)[0], "0" * 64, [(0, len(raw))])
        with self.assertRaisesRegex(AuditError, "sha256_mismatch"):
            audit_many([first, wrong_hash], 2)


if __name__ == "__main__":
    unittest.main()
