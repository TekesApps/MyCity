"""Synthetic contract cases for report_contract.py; none are acceptance evidence."""

import importlib.util
import unittest
from pathlib import Path


MODULE_PATH = Path(__file__).with_name("report_contract.py")
SPEC = importlib.util.spec_from_file_location("rare_report_contract", MODULE_PATH)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError("could not load report_contract.py")
report_contract = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(report_contract)

SOURCE = "a" * 64


def count_gate(qualified_samples=200):
    return {
        "status": "sample_count_sufficient_only",
        "minimum_trials": 200,
        "minimum_samples": 200,
        "completed_trials": 200,
        "qualified_trials": 200,
        "qualified_samples": qualified_samples,
        "all_trials_have_qualifying_sample": True,
    }


def latency_gate(
    class_name,
    p95_ns=20_000_000,
    p99_ns=40_000_000,
    p95_rank=190,
    p99_rank=198,
):
    return {
        "class": class_name,
        "status": report_contract.LATENCY_PASS,
        "histogram": {
            "gate": report_contract.LATENCY_PASS,
            "samples": 200,
            "p95": {"upper_inclusive_ns": p95_ns, "nearest_rank": p95_rank},
            "p99": {"upper_inclusive_ns": p99_ns, "nearest_rank": p99_rank},
        },
    }


def formal_report(kind="source"):
    report = {
        "schema": "mycity-rare-batch-report-v1",
        "source_sha256": SOURCE,
        "mode": "Formal",
        "stratum": kind,
        "planned_trials": 200,
        "completed_trials": 200,
        "l1_and_pool_shutdown": {
            "restore_report": {"cold_reopen_and_scan": "passed"},
            "layout_stopped_by_owner_pipe": True,
        },
        "sample_count_gate": count_gate(),
        "selected_latency_gate": latency_gate(
            "L2_claims_batch" if kind == "claims" else "air_source_page"
        ),
        "formal_rare_gate": report_contract.PENDING_FORMAL,
    }
    if kind == "source":
        report["air_cell_sample_count_gate"] = count_gate()
        report["air_cell_latency_gate"] = latency_gate("air_cell_page")
    return report


def smoke_report(kind="source"):
    report = {
        "schema": "mycity-rare-batch-report-v1",
        "source_sha256": SOURCE,
        "mode": "Smoke",
        "stratum": kind,
        "planned_trials": 1,
        "completed_trials": 1,
        "actual_status": "completed_smoke_functional_only",
        "l1_and_pool_shutdown": {
            "restore_report": {"cold_reopen_and_scan": "passed"},
            "layout_stopped_by_owner_pipe": True,
        },
        "sample_count_gate": {"status": report_contract.SMOKE},
        "selected_latency_gate": {"status": report_contract.SMOKE},
    }
    if kind == "source":
        report["air_cell_sample_count_gate"] = {"status": report_contract.SMOKE}
        report["air_cell_latency_gate"] = {"status": report_contract.SMOKE}
    return report


class ReportContractTests(unittest.TestCase):
    def test_199_qualified_samples_do_not_pass_count_component(self):
        for kind, field in (
            ("claims", "sample_count_gate"),
            ("source", "air_cell_sample_count_gate"),
        ):
            with self.subTest(kind=kind):
                report = formal_report(kind)
                report[field] = count_gate(qualified_samples=199)
                result = report_contract.classify_model_report(
                    report, SOURCE, kind, "formal"
                )
                self.assertEqual(result["count_component"], "not_proven")

    def test_pass_label_does_not_override_p95_or_p99_limit(self):
        for histogram in (
            latency_gate("L2_claims_batch", p95_ns=20_000_001),
            latency_gate("L2_claims_batch", p99_ns=40_000_001),
        ):
            with self.subTest(histogram=histogram):
                report = formal_report("claims")
                report["selected_latency_gate"] = histogram
                result = report_contract.classify_model_report(
                    report, SOURCE, "claims", "formal"
                )
                self.assertEqual(result["latency_component"], "not_proven")

    def test_latency_class_name_must_match_component(self):
        report = formal_report("source")
        report["selected_latency_gate"] = latency_gate("air_cell_page")
        report["air_cell_latency_gate"] = latency_gate("air_source_page")
        result = report_contract.classify_model_report(
            report, SOURCE, "source", "formal"
        )
        self.assertEqual(result["latency_component"], "not_proven")

    def test_latency_nearest_rank_must_match_sample_population(self):
        for bad_latency in (
            latency_gate("L2_claims_batch", p95_rank=191),
            latency_gate("L2_claims_batch", p99_rank=199),
        ):
            with self.subTest(histogram=bad_latency):
                report = formal_report("claims")
                report["selected_latency_gate"] = bad_latency
                result = report_contract.classify_model_report(
                    report, SOURCE, "claims", "formal"
                )
                self.assertEqual(result["latency_component"], "not_proven")

    def test_latency_rejects_p95_above_p99_even_within_both_caps(self):
        report = formal_report("claims")
        report["selected_latency_gate"] = latency_gate(
            "L2_claims_batch", p95_ns=20_000_000, p99_ns=19_999_999
        )
        result = report_contract.classify_model_report(
            report, SOURCE, "claims", "formal"
        )
        self.assertEqual(result["latency_component"], "not_proven")

    def test_population_mismatch_blocks_claims_latency_component(self):
        report = formal_report("claims")
        report["sample_count_gate"] = count_gate(qualified_samples=400)
        result = report_contract.classify_model_report(
            report, SOURCE, "claims", "formal"
        )
        self.assertEqual(result["count_component"], "sufficient")
        self.assertFalse(result["count_and_latency_sample_populations_match"])
        self.assertEqual(result["latency_component"], "not_proven")

    def test_source_sample_populations_are_checked_independently(self):
        for count_field, latency_field in (
            ("sample_count_gate", "selected_latency_gate"),
            ("air_cell_sample_count_gate", "air_cell_latency_gate"),
        ):
            with self.subTest(count_field=count_field):
                report = formal_report("source")
                report[count_field] = count_gate(qualified_samples=400)
                result = report_contract.classify_model_report(
                    report, SOURCE, "source", "formal"
                )
                self.assertEqual(result["count_component"], "sufficient")
                self.assertFalse(
                    result["count_and_latency_sample_populations_match"]
                )
                self.assertEqual(result["latency_component"], "not_proven")

    def test_source_class_six_pass_does_not_promote_insufficient_class_seven(self):
        report = formal_report("source")
        report["air_cell_sample_count_gate"] = count_gate(qualified_samples=199)
        result = report_contract.classify_model_report(
            report, SOURCE, "source", "formal"
        )
        self.assertEqual(result["count_component"], "not_proven")
        self.assertEqual(
            result["formal_rare_gate"],
            "pending_independent_raw_identity_overlap_and_observer_audit",
        )
        self.assertNotEqual(result["formal_rare_gate"], "passed")
        self.assertEqual(result["full_M0"], "not_accepted")

    def test_sufficient_formal_components_still_leave_rare_gate_pending(self):
        report = formal_report("source")
        result = report_contract.classify_model_report(
            report, SOURCE, "source", "formal"
        )
        self.assertEqual(result["count_component"], "sufficient")
        self.assertEqual(result["latency_component"], "within_original_bounds")
        self.assertTrue(result["model_keeps_formal_audit_pending"])
        self.assertEqual(
            result["formal_rare_gate"],
            "pending_independent_raw_identity_overlap_and_observer_audit",
        )

    def test_source_digest_or_mode_mismatch_refuses_classification(self):
        report = formal_report("source")
        result = report_contract.classify_model_report(
            report, "b" * 64, "source", "formal"
        )
        self.assertFalse(result["identity_matches"])
        self.assertEqual(result["formal_rare_gate"], "not_verified_report_identity")

        report = formal_report("source")
        report["mode"] = "Smoke"
        result = report_contract.classify_model_report(
            report, SOURCE, "source", "formal"
        )
        self.assertFalse(result["identity_matches"])

        report = formal_report("source")
        report["mode"] = "formal"
        result = report_contract.classify_model_report(
            report, SOURCE, "source", "formal"
        )
        self.assertFalse(result["identity_matches"])

    def test_smoke_is_functional_only_and_does_not_require_200(self):
        report = smoke_report("source")
        report["planned_trials"] = 1
        report["completed_trials"] = 1
        result = report_contract.classify_model_report(
            report, SOURCE, "source", "smoke"
        )
        self.assertTrue(result["functional_smoke_report"])
        self.assertEqual(result["count_component"], "not_applicable_smoke")
        self.assertEqual(result["latency_component"], "not_applicable_smoke")
        self.assertEqual(result["formal_rare_gate"], "not_applicable_smoke")
        self.assertEqual(result["full_M0"], "not_accepted")

    def test_failed_cold_restore_cannot_be_a_functional_smoke(self):
        report = smoke_report("claims")
        report["l1_and_pool_shutdown"]["restore_report"][
            "cold_reopen_and_scan"
        ] = "failed"
        result = report_contract.classify_model_report(
            report, SOURCE, "claims", "smoke"
        )
        self.assertFalse(result["functional_smoke_report"])

    def test_wrong_stratum_refuses_classification(self):
        report = formal_report("claims")
        result = report_contract.classify_model_report(
            report, SOURCE, "source", "formal"
        )
        self.assertFalse(result["identity_matches"])
        self.assertEqual(result["formal_rare_gate"], "not_verified_report_identity")


if __name__ == "__main__":
    unittest.main()
