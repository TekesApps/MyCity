"""Synthetic launcher refusal/dispatch cases; never launch the model or observer."""

import json
import contextlib
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

import run


SOURCE = "source-fingerprint"
BINARY = "binary-digest"
SOURCE_RECEIPT = "source-receipt-digest"
HELPERS = {"run.py": "run-hash", "observer_contract.py": "observer-hash"}
HELPER_COMMAND = ["python", "-m", "unittest", "discover"]
REPORT_HASHES = {"observer": "observer-report-hash", "model": "model-report-hash"}


def fake_admission():
    module = types.ModuleType("admission")
    module.SAFE_CHILD_ENV = {}
    module.run_admission = Mock(side_effect=AssertionError("admission must not run"))
    return module


def synthetic_source():
    return {
        "candidate_source": {"fingerprint": SOURCE},
        "build": {"binary_sha256": BINARY},
        "anchors": {"path": "/synthetic/anchors"},
    }


def smoke_execution(**overrides):
    result = {
        "source_fingerprint": SOURCE,
        "binary_sha256": BINARY,
        "source_receipt_sha256": SOURCE_RECEIPT,
        "helper_source_files": HELPERS,
        "exit_code": 0,
        "report_hashes": REPORT_HASHES,
    }
    result.update(overrides)
    return result


class LaunchContractTests(unittest.TestCase):
    def test_main_run_routes_to_launch_without_starting_any_process(self):
        with (
            patch.object(run, "validation_lock", side_effect=contextlib.nullcontext) as lock,
            patch.object(run, "launch", return_value=0) as launch,
            patch.object(run.subprocess, "run") as process,
        ):
            self.assertEqual(run.main(["--run", "source", "smoke"]), 0)
        lock.assert_called_once_with()
        launch.assert_called_once_with("source", "smoke")
        process.assert_not_called()

    def test_main_test_helpers_route_uses_mock_lock_without_running_helpers(self):
        with (
            patch.object(run, "validation_lock", side_effect=contextlib.nullcontext) as lock,
            patch.object(run, "test_helpers", return_value=0) as helpers,
        ):
            self.assertEqual(run.main(["--test-helpers"]), 0)
        lock.assert_called_once_with()
        helpers.assert_called_once_with()

    def test_active_job_refusal_precedes_directory_creation_and_model_launch(self):
        with tempfile.TemporaryDirectory(dir="/tmp") as temporary:
            root = Path(temporary) / "run-that-must-not-exist"
            with (
                patch.dict(sys.modules, {"admission": fake_admission()}),
                patch.object(run, "refuse_active_jobs", side_effect=RuntimeError("busy")),
                patch.object(run, "run_directory", return_value=root),
                patch.object(run.subprocess, "run") as process,
            ):
                with self.assertRaisesRegex(RuntimeError, "busy"):
                    run.launch("claims", "smoke")
            self.assertFalse(root.exists())
            process.assert_not_called()

    def test_missing_helper_receipt_refuses_before_creating_a_run(self):
        with tempfile.TemporaryDirectory(dir="/tmp") as temporary:
            root = Path(temporary) / "run-that-must-not-exist"
            with (
                patch.dict(sys.modules, {"admission": fake_admission()}),
                patch.object(run, "HERE", Path(temporary)),
                patch.object(run, "refuse_active_jobs"),
                patch.object(run, "run_directory", return_value=root),
                patch.object(run.subprocess, "run") as process,
            ):
                with self.assertRaises(RuntimeError):
                    run.launch("claims", "smoke")
            self.assertFalse(root.exists())
            process.assert_not_called()

    def test_missing_source_receipt_refuses_before_creating_a_run(self):
        with tempfile.TemporaryDirectory(dir="/tmp") as temporary:
            root = Path(temporary) / "run-that-must-not-exist"
            missing_source = Path(temporary) / "source.json"
            with (
                patch.dict(sys.modules, {"admission": fake_admission()}),
                patch.object(run, "SOURCE_FILE", missing_source),
                patch.object(run, "refuse_active_jobs"),
                patch.object(run, "verify_helper_receipt", return_value=Path(temporary) / "receipt.json"),
                patch.object(run, "run_directory", return_value=root),
                patch.object(run.subprocess, "run") as process,
            ):
                with self.assertRaisesRegex(RuntimeError, "source.json missing"):
                    run.launch("claims", "smoke")
            self.assertFalse(root.exists())
            process.assert_not_called()

    def _launch_formal_until_smoke_gate(self, temporary, receipt, inspection):
        root_by_phase = {
            ("source", "formal"): Path(temporary) / "formal-run",
            ("source", "smoke"): Path(temporary) / "smoke-run",
        }
        admission = fake_admission()
        with (
            patch.dict(sys.modules, {"admission": admission}),
            patch.object(run, "HERE", Path(temporary) / "helpers"),
            patch.object(run, "SOURCE_FILE", Path(temporary) / "source.json"),
            patch.object(run, "refuse_active_jobs"),
            patch.object(run, "verify_helper_receipt", return_value=Path(temporary) / "helper-receipt.json"),
            patch.object(run, "load_source", return_value=(synthetic_source(), Path("/synthetic/candidate"))),
            patch.object(run, "sha256", return_value=SOURCE_RECEIPT),
            patch.object(run, "helper_source_hashes", return_value=HELPERS),
            patch.object(run, "run_directory", side_effect=lambda kind, phase: root_by_phase[(kind, phase)]),
            patch.object(run, "read_report", return_value=receipt),
            patch.object(run, "collect_inspection", return_value=inspection) as collect,
            patch.object(run.subprocess, "run") as process,
        ):
            with self.assertRaises(RuntimeError):
                run.launch("source", "formal")
        self.assertFalse(root_by_phase[("source", "formal")].exists())
        admission.run_admission.assert_not_called()
        process.assert_not_called()
        return collect

    def test_formal_requires_successful_smoke_receipt_from_same_identity(self):
        mismatches = (
            {"source_fingerprint": "different-source"},
            {"binary_sha256": "different-binary"},
            {"source_receipt_sha256": "stale-source-receipt"},
            {"helper_source_files": {"run.py": "stale-helper"}},
            {"exit_code": 1},
        )
        for mismatch in mismatches:
            with self.subTest(mismatch=mismatch), tempfile.TemporaryDirectory(dir="/tmp") as temporary:
                collect = self._launch_formal_until_smoke_gate(
                    temporary,
                    smoke_execution(**mismatch),
                    {"reported_components_sufficient_only": True, "report_hashes": REPORT_HASHES},
                )
                collect.assert_not_called()

    def test_formal_requires_inspected_smoke_components_and_matching_report_hashes(self):
        cases = (
            {"reported_components_sufficient_only": False, "report_hashes": REPORT_HASHES},
            {"reported_components_sufficient_only": True, "report_hashes": {"observer": "changed", "model": "model-report-hash"}},
        )
        for inspection in cases:
            with self.subTest(inspection=inspection), tempfile.TemporaryDirectory(dir="/tmp") as temporary:
                collect = self._launch_formal_until_smoke_gate(
                    temporary, smoke_execution(), inspection
                )
                collect.assert_called_once()

    def test_helper_receipt_rejects_stale_sources_nonzero_exit_and_zero_test_transcript(self):
        cases = (
            ("stale source manifest", {"source_files": {"run.py": "old-hash", "observer_contract.py": "observer-hash"}}, "Ran 1 test in 0.01s\n\nOK\n"),
            ("source changed", {"source_unchanged": False}, "Ran 1 test in 0.01s\n\nOK\n"),
            ("nonzero exit", {"exit_code": 1}, "Ran 1 test in 0.01s\n\nOK\n"),
            ("zero tests", {}, "Ran 0 tests in 0.01s\n\nOK\n"),
        )
        for label, overrides, transcript in cases:
            with self.subTest(label=label), tempfile.TemporaryDirectory(dir="/tmp") as temporary:
                root = Path(temporary) / "helper-validation-01"
                root.mkdir()
                stdout = root / "stdout"
                stderr = root / "stderr"
                stdout.write_text("synthetic stdout\n")
                stderr.write_text(transcript)
                receipt = {
                    "schema": "mycity-rare-helper-validation-v1",
                    "command": HELPER_COMMAND,
                    "exit_code": 0,
                    "source_files": HELPERS,
                    "source_unchanged": True,
                    "stdout_sha256": "stdout-hash",
                    "stderr_sha256": "stderr-hash",
                }
                receipt.update(overrides)
                (root / "receipt.json").write_text(json.dumps(receipt))
                digest_by_path = {stdout: "stdout-hash", stderr: "stderr-hash"}
                with (
                    patch.object(run, "HERE", Path(temporary)),
                    patch.object(run, "helper_command", return_value=HELPER_COMMAND),
                    patch.object(run, "helper_source_hashes", return_value=HELPERS),
                    patch.object(run, "sha256", side_effect=lambda path: digest_by_path[Path(path)]),
                ):
                    with self.assertRaises(RuntimeError):
                        run.verify_helper_receipt()

    def test_helper_receipt_positive_synthetic_nonempty_transcript(self):
        with tempfile.TemporaryDirectory(dir="/tmp") as temporary:
            root = Path(temporary) / "helper-validation-01"
            root.mkdir()
            stdout = root / "stdout"
            stderr = root / "stderr"
            stdout.write_text("synthetic stdout\n")
            stderr.write_text("Ran 2 tests in 0.01s\n\nOK\n")
            (root / "receipt.json").write_text(json.dumps({
                "schema": "mycity-rare-helper-validation-v1",
                "command": HELPER_COMMAND,
                "exit_code": 0,
                "source_files": HELPERS,
                "source_unchanged": True,
                "stdout_sha256": "stdout-hash",
                "stderr_sha256": "stderr-hash",
            }))
            digest_by_path = {stdout: "stdout-hash", stderr: "stderr-hash"}
            with (
                patch.object(run, "HERE", Path(temporary)),
                patch.object(run, "helper_command", return_value=HELPER_COMMAND),
                patch.object(run, "helper_source_hashes", return_value=HELPERS),
                patch.object(run, "sha256", side_effect=lambda path: digest_by_path[Path(path)]),
            ):
                self.assertEqual(run.verify_helper_receipt(), root / "receipt.json")

    def test_run_directory_uses_four_fixed_nonoverwriting_prefixes(self):
        with tempfile.TemporaryDirectory(dir="/tmp") as temporary:
            (Path(temporary) / "work").mkdir()
            with patch.object(run, "REPO", Path(temporary)):
                expected = {
                    ("claims", "smoke"): "rb3-cs-01",
                    ("claims", "formal"): "rb3-cf-01",
                    ("source", "smoke"): "rb3-ss-01",
                    ("source", "formal"): "rb3-sf-01",
                }
                for (kind, phase), name in expected.items():
                    with self.subTest(kind=kind, phase=phase):
                        self.assertEqual(run.run_directory(kind, phase).name, name)


if __name__ == "__main__":
    unittest.main()
