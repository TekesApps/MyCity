"""Numeric-only audit of frozen 9-byte CPU duration records.

This module verifies file bytes and selected aligned ranges. It does not prove
that a range is eligible, belongs to a process identity, overlaps an observer
window, or satisfies a memory or full-M0 acceptance gate.
"""

from __future__ import annotations

import hashlib
import os
import stat
from pathlib import Path
from typing import Iterable

RECORD_BYTES = 9
RAW_BYTE_CAP = 128 * 1024
MAX_RECORDS = RAW_BYTE_CAP // RECORD_BYTES
MAX_INPUT_FILES = 600
TOTAL_RAW_BYTE_CAP = 128 * 1024 * 1024
MAX_VALID_FILE_BYTES = MAX_RECORDS * RECORD_BYTES
EFFECTIVE_RAW_BYTE_CAP = min(
    TOTAL_RAW_BYTE_CAP, MAX_INPUT_FILES * MAX_VALID_FILE_BYTES
)
MAX_TOTAL_RECORDS = EFFECTIVE_RAW_BYTE_CAP // RECORD_BYTES
MIN_SAMPLES = 200
P95_LIMIT_NS = 20_000_000
P99_LIMIT_NS = 40_000_000


class AuditError(ValueError):
    """The raw stream or its caller-supplied identity/ranges are invalid."""


def _is_int(value: object) -> bool:
    # bool is a subclass of int, but must never be accepted as an offset/class.
    return isinstance(value, int) and not isinstance(value, bool)


def _same_file_identity(left: os.stat_result, right: os.stat_result) -> bool:
    return (
        left.st_dev == right.st_dev
        and left.st_ino == right.st_ino
        and left.st_size == right.st_size
        and left.st_mtime_ns == right.st_mtime_ns
    )


def _validated_ranges(
    ranges: Iterable[tuple[int, int]], file_size: int
) -> list[tuple[int, int]]:
    result: list[tuple[int, int]] = []
    for item in ranges:
        if len(result) >= MAX_RECORDS:
            raise AuditError("too_many_ranges")
        if not isinstance(item, (tuple, list)) or len(item) != 2:
            raise AuditError("range_shape")
        start, end = item
        if not _is_int(start) or not _is_int(end):
            raise AuditError("range_offset_type")
        if start < 0 or end <= start or end > file_size:
            raise AuditError("range_bounds")
        if start % RECORD_BYTES or end % RECORD_BYTES:
            raise AuditError("range_record_alignment")
        result.append((start, end))

    result.sort()
    previous_end = -1
    for start, end in result:
        if start < previous_end:
            raise AuditError("ranges_overlap")
        previous_end = end
    return result


def _validate_inputs(expected_sha256: str, class_index: int) -> None:
    if not isinstance(expected_sha256, str) or len(expected_sha256) != 64:
        raise AuditError("expected_sha256_shape")
    if any(char not in "0123456789abcdefABCDEF" for char in expected_sha256):
        raise AuditError("expected_sha256_shape")
    _validate_class_index(class_index)


def _validate_class_index(class_index: int) -> None:
    if not _is_int(class_index) or not 0 <= class_index <= 9:
        raise AuditError("class_index")


def _read_selected(
    path: str | os.PathLike[str],
    expected_sha256: str,
    ranges: Iterable[tuple[int, int]],
    class_index: int,
    seen_inodes: set[tuple[int, int]] | None = None,
) -> tuple[str, int, list[tuple[int, int]], list[int]]:
    _validate_inputs(expected_sha256, class_index)
    raw_path = Path(path)
    try:
        path_before = raw_path.lstat()
        if stat.S_ISLNK(path_before.st_mode) or not stat.S_ISREG(path_before.st_mode):
            raise AuditError("raw_file_not_regular_or_symlink")
        flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
        with os.fdopen(os.open(raw_path, flags), "rb") as stream:
            before = os.fstat(stream.fileno())
            if not stat.S_ISREG(before.st_mode):
                raise AuditError("raw_file_not_regular")
            if not _same_file_identity(path_before, before):
                raise AuditError("raw_file_path_changed_before_read")
            inode = (before.st_dev, before.st_ino)
            if seen_inodes is not None:
                if inode in seen_inodes:
                    raise AuditError("duplicate_raw_file_inode")
                seen_inodes.add(inode)
            file_size = before.st_size
            if file_size > RAW_BYTE_CAP:
                raise AuditError("raw_file_too_large")
            if file_size % RECORD_BYTES:
                raise AuditError("raw_file_record_alignment")
            selected_ranges = _validated_ranges(ranges, file_size)

            digest = hashlib.sha256()
            durations: list[int] = []
            range_index = 0
            offset = 0
            for _ in range(file_size // RECORD_BYTES):
                record = stream.read(RECORD_BYTES)
                if len(record) != RECORD_BYTES:
                    raise AuditError("raw_file_truncated")
                digest.update(record)
                cls = record[0]
                if cls > 9:
                    raise AuditError("raw_record_class")

                record_end = offset + RECORD_BYTES
                while (
                    range_index < len(selected_ranges)
                    and offset >= selected_ranges[range_index][1]
                ):
                    range_index += 1
                if range_index < len(selected_ranges):
                    start, end = selected_ranges[range_index]
                    if start <= offset and record_end <= end and cls == class_index:
                        durations.append(int.from_bytes(record[1:], "little"))
                offset = record_end

            if stream.read(1):
                raise AuditError("raw_file_grew_during_read")
            after = os.fstat(stream.fileno())
            if (
                not _same_file_identity(before, after)
            ):
                raise AuditError("raw_file_changed_during_read")
            path_after = raw_path.lstat()
            if (
                stat.S_ISLNK(path_after.st_mode)
                or not stat.S_ISREG(path_after.st_mode)
                or not _same_file_identity(before, path_after)
            ):
                raise AuditError("raw_file_path_changed_during_read")
    except AuditError:
        raise
    except OSError as exc:
        raise AuditError("raw_file_io") from exc

    actual_sha256 = digest.hexdigest()
    if actual_sha256 != expected_sha256.lower():
        raise AuditError("raw_file_sha256_mismatch")
    return actual_sha256, file_size, selected_ranges, durations


def _range_digest(ranges: list[tuple[int, int]]) -> str:
    digest = hashlib.sha256()
    for start, end in ranges:
        digest.update(start.to_bytes(8, "little"))
        digest.update(end.to_bytes(8, "little"))
    return digest.hexdigest()


def _numeric_summary(durations: list[int]) -> dict[str, object]:
    durations.sort()
    sample_count = len(durations)
    p95_ns = durations[(95 * sample_count + 99) // 100 - 1] if sample_count else None
    p99_ns = durations[(99 * sample_count + 99) // 100 - 1] if sample_count else None
    maximum_ns = durations[-1] if sample_count else None
    latency_pass = (
        sample_count >= MIN_SAMPLES
        and p95_ns <= P95_LIMIT_NS
        and p99_ns <= P99_LIMIT_NS
    )
    return {
        "selected_sample_count": sample_count,
        "sample_count_gate": {
            "status": "sufficient" if sample_count >= MIN_SAMPLES else "insufficient",
            "required": MIN_SAMPLES,
            "observed": sample_count,
        },
        "p95_ns": p95_ns,
        "p99_ns": p99_ns,
        "maximum_ns": maximum_ns,
        "p95_limit_ns": P95_LIMIT_NS,
        "p99_limit_ns": P99_LIMIT_NS,
        "numeric_latency_gate": (
            "passed_numeric_only"
            if latency_pass
            else "not_evaluable_insufficient_samples"
            if sample_count < MIN_SAMPLES
            else "failed_numeric_only"
        ),
    }


def audit(
    path: str | os.PathLike[str],
    expected_sha256: str,
    ranges: Iterable[tuple[int, int]],
    class_index: int,
) -> dict[str, object]:
    """Verify one bounded raw file and summarize one class in eligible ranges.

    Each record is exactly ``class:u8 + duration_ns:u64le``. Ranges are
    half-open byte offsets, must be 9-byte aligned, and may not overlap. The
    complete raw file is streamed once for both SHA-256 and record decoding.
    Selected durations use an exact list bounded by the 128 KiB raw cap.
    """
    actual_sha256, file_size, selected_ranges, durations = _read_selected(
        path, expected_sha256, ranges, class_index
    )

    return {
        "schema": "mycity-raw-duration-numeric-audit-v1",
        "raw_sha256": actual_sha256,
        "raw_bytes": file_size,
        "class_index": class_index,
        "range_count": len(selected_ranges),
        "ranges_sha256": _range_digest(selected_ranges),
        "ranges_sha256_encoding": "sorted half-open u64le(start)||u64le(end) pairs",
        **_numeric_summary(durations),
        "eligibility_identity_observer_overlap_normal_memory_full_m0": "not_proven",
    }


def audit_many(
    inputs: Iterable[
        tuple[str | os.PathLike[str], str, Iterable[tuple[int, int]]]
    ],
    class_index: int,
) -> dict[str, object]:
    """Aggregate original durations across distinct raw files, then rank once.

    Each input is ``(path, expected_sha256, ranges)`` and is streamed once by
    the same verifier as :func:`audit`. The 600-file ceiling is the 200-trial
    by three-producer raw-file ceiling; source-stratum worker files are usually
    at most 400 (two workers per trial), with Sim records not made eligible by
    this numeric-only function. The combined sample count does not prove 200
    independent trials.

    This is post-observer offline QA. At most 8,737,800 durations are retained
    for exact global nearest-rank quantiles. The Python list plus integer
    objects and in-place sort scratch are estimated at roughly 420 MiB at that
    ceiling, excluding interpreter/allocator overhead. It is not a game-path
    operation and does not demonstrate the DRIVER 1 MiB budget.
    """
    _validate_class_index(class_index)
    durations: list[int] = []
    file_summaries: list[dict[str, object]] = []
    seen_inodes: set[tuple[int, int]] = set()
    total_bytes = 0
    total_ranges = 0

    for ordinal, item in enumerate(inputs, start=1):
        if ordinal > MAX_INPUT_FILES:
            raise AuditError("too_many_input_files")
        if not isinstance(item, (tuple, list)) or len(item) != 3:
            raise AuditError("input_shape")
        path, expected_sha256, ranges = item
        actual_sha256, file_size, selected_ranges, samples = _read_selected(
            path, expected_sha256, ranges, class_index, seen_inodes
        )
        total_bytes += file_size
        if total_bytes > TOTAL_RAW_BYTE_CAP:
            raise AuditError("total_raw_bytes_too_large")
        if len(durations) + len(samples) > MAX_TOTAL_RECORDS:
            raise AuditError("total_selected_records_too_large")
        durations.extend(samples)
        range_digest = _range_digest(selected_ranges)
        total_ranges += len(selected_ranges)
        file_summaries.append(
            {
                "ordinal": ordinal,
                "path": os.fspath(path),
                "raw_sha256": actual_sha256,
                "raw_bytes": file_size,
                "range_count": len(selected_ranges),
                "ranges_sha256": range_digest,
                "selected_sample_count": len(samples),
            }
        )

    return {
        "schema": "mycity-raw-duration-numeric-audit-many-v1",
        "class_index": class_index,
        "file_count": len(file_summaries),
        "file_count_limit": MAX_INPUT_FILES,
        "file_count_limit_basis": "200 trials x 3 producer raw-file ceiling; source worker files usually <=400",
        "total_raw_bytes": total_bytes,
        "total_raw_byte_limit": TOTAL_RAW_BYTE_CAP,
        "effective_max_total_raw_bytes": EFFECTIVE_RAW_BYTE_CAP,
        "total_range_count": total_ranges,
        "range_binding_encoding": "per-file SHA-256 of sorted half-open u64le(start)||u64le(end) pairs",
        "max_selected_records": MAX_TOTAL_RECORDS,
        "offline_scratch_estimate": "about 420 MiB at max_selected_records; excludes interpreter/allocator overhead",
        "execution_scope": "post-observer offline QA; not game-path and not DRIVER-budget evidence",
        "independent_trial_count_gate": "not_proven",
        "files": file_summaries,
        **_numeric_summary(durations),
        "eligibility_identity_observer_overlap_normal_memory_full_m0": "not_proven",
    }
