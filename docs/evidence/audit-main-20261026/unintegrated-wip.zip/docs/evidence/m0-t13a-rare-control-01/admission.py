"""Fail-closed macOS host admission gate; never launches or manages a model process."""
from __future__ import annotations

import json
import os
import plistlib
import re
import shutil
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

HP_MOUNT = Path("/Volumes/HP P900")
HP_VOLUME_UUID = "4289CF6D-F09D-4831-8558-4AB223E4EE04"
EXPECTED_FILESYSTEM = "apfs"
WORK_LINK = Path("/Users/frankqin/dev/MyCity/work")
TARGET_LINK = Path("/Users/frankqin/dev/MyCity/target")
EXPECTED_WORK = HP_MOUNT / "dev/MyCity/work"
EXPECTED_TARGET = HP_MOUNT / "dev/MyCity/target"
MIN_FREE_BYTES = 2 * 1024**3
MAX_SWAP_GROWTH_BYTES = 256 * 1024**2
NORMAL_PRESSURE_LEVEL = 1
NORMAL_WINDOW_SECONDS = 120.0
TOTAL_DEADLINE_SECONDS = 600.0
SAMPLE_INTERVAL_SECONDS = 5.0
MAX_SAMPLE_GAP_SECONDS = 10.0
CHILD_TIMEOUT_SECONDS = 5.0
SAFE_CHILD_ENV = {"PATH": "/usr/bin:/bin:/usr/sbin:/sbin", "LANG": "C", "LC_ALL": "C"}
SWAP_USED_RE = re.compile(r"(?:^|\s)used\s*=\s*([0-9]+(?:\.[0-9]+)?)\s*([KMGT]?)(?=\s|,|$)", re.IGNORECASE)


class AdmissionError(RuntimeError):
    """Configuration or evidence-path error; no model is launched."""


def parse_swap_used_bytes(output: str) -> int:
    """Parse `sysctl vm.swapusage`; K/M/G/T use binary units."""
    matches = list(SWAP_USED_RE.finditer(output.strip()))
    if len(matches) != 1:
        raise ValueError("vm.swapusage must contain exactly one parseable used= value")
    value = float(matches[0].group(1))
    unit = matches[0].group(2).upper()
    scale = {"": 1, "K": 1024, "M": 1024**2, "G": 1024**3, "T": 1024**4}[unit]
    return int(value * scale)


def parse_pressure_level(output: str) -> int:
    value = output.strip()
    if not re.fullmatch(r"[0-9]+", value):
        raise ValueError("memory pressure sysctl must be one integer dispatch flag")
    return int(value)


def parse_process_rows(output: str) -> list[dict[str, object]]:
    """Parse ps pid/ppid/comm columns without splitting paths containing spaces."""
    rows = []
    for line_number, line in enumerate(output.splitlines(), start=1):
        if not line.strip():
            continue
        fields = line.strip().split(maxsplit=2)
        if len(fields) != 3:
            raise ValueError(f"malformed ps row at line {line_number}")
        try:
            pid = int(fields[0])
            ppid = int(fields[1])
        except ValueError as error:
            raise ValueError(f"invalid pid fields in ps row at line {line_number}") from error
        if pid <= 0 or ppid < 0 or not fields[2]:
            raise ValueError(f"invalid process identity in ps row at line {line_number}")
        rows.append({"pid": pid, "ppid": ppid, "comm": fields[2]})
    if not rows:
        raise ValueError("ps returned no process rows")
    return rows


def parse_volume_identity(plist_bytes: bytes) -> dict[str, str | None]:
    data = plistlib.loads(plist_bytes)
    return {
        "mount_point": data.get("MountPoint"),
        "volume_uuid": data.get("VolumeUUID"),
        "filesystem": data.get("FilesystemType", data.get("FilesystemName")),
    }


def validate_storage_profile(
    *,
    work_link: Path,
    target_link: Path,
    expected_work: Path,
    expected_target: Path,
    mount: Path,
    identity: dict[str, str | None],
    free_bytes: int,
    expected_uuid: str = HP_VOLUME_UUID,
    expected_filesystem: str = EXPECTED_FILESYSTEM,
    minimum_free_bytes: int = MIN_FREE_BYTES,
) -> dict[str, object]:
    for link, expected, label in (
        (work_link, expected_work, "work"),
        (target_link, expected_target, "target"),
    ):
        if not link.is_symlink():
            raise ValueError(f"{label} path must remain an explicit symlink")
        if link.resolve(strict=True) != expected.resolve(strict=True):
            raise ValueError(f"{label} symlink does not resolve to the pinned external SSD path")
        if not link.resolve(strict=True).is_relative_to(mount.resolve(strict=True)):
            raise ValueError(f"{label} path resolves outside the pinned external volume")
    if identity.get("mount_point") != str(mount):
        raise ValueError("diskutil mount point differs from pinned HP P900 mount")
    if identity.get("volume_uuid") != expected_uuid:
        raise ValueError("diskutil volume UUID differs from pinned HP P900 volume")
    if str(identity.get("filesystem", "")).lower() != expected_filesystem.lower():
        raise ValueError("external volume is not the pinned APFS profile")
    if free_bytes < minimum_free_bytes:
        raise ValueError("external volume available space is below the frozen 2 GiB floor")
    return {
        "work_link_valid": True,
        "target_link_valid": True,
        "mount_point": str(mount),
        "volume_uuid": expected_uuid,
        "filesystem": expected_filesystem,
        "available_bytes": free_bytes,
        "minimum_available_bytes": minimum_free_bytes,
    }


def blockers_from_process_rows(rows: list[dict[str, object]], own_pid: int) -> list[dict[str, object]]:
    """Return only pid, executable basename, and refusal reason; never preserve argv."""
    from run import process_refusal

    adapted = [
        {"pid": row["pid"], "ppid": row["ppid"], "comm": row["comm"], "args": ""}
        for row in rows
    ]
    blocked = process_refusal(adapted, own_pid)
    known = {item["pid"] for item in blocked}
    for row in rows:
        if row["pid"] == own_pid or row["pid"] in known:
            continue
        exe = Path(str(row["comm"])).name
        if exe == "mycity-headless":
            # ps comm is not an argv parser. Fail closed when the exact subcommand is unknown.
            blocked.append({"pid": row["pid"], "exe": exe, "reason": "unclassified_headless_active"})
    return blocked


def _run_child(command: list[str], *, runner: Callable, timeout: float = CHILD_TIMEOUT_SECONDS):
    return runner(command, env=dict(SAFE_CHILD_ENV), timeout=timeout)


def _command_text(result) -> str:
    if isinstance(result, bytes):
        return result.decode("utf-8", "strict")
    return str(result)


def _probe_processes(runner: Callable, own_pid: int) -> list[dict[str, object]]:
    output = _run_child(["/bin/ps", "-axo", "pid=,ppid=,comm="], runner=runner)
    return blockers_from_process_rows(parse_process_rows(_command_text(output)), own_pid)


def _probe_storage(runner: Callable, disk_usage: Callable) -> dict[str, object]:
    output = _run_child(["/usr/sbin/diskutil", "info", "-plist", str(HP_MOUNT)], runner=runner)
    identity = parse_volume_identity(output if isinstance(output, bytes) else str(output).encode())
    work_resolved = WORK_LINK.resolve(strict=True)
    free = disk_usage(work_resolved).free
    return validate_storage_profile(
        work_link=WORK_LINK,
        target_link=TARGET_LINK,
        expected_work=EXPECTED_WORK,
        expected_target=EXPECTED_TARGET,
        mount=HP_MOUNT,
        identity=identity,
        free_bytes=free,
    )


def _probe_pressure_and_swap(runner: Callable) -> tuple[int, int]:
    pressure = _run_child(
        ["/usr/sbin/sysctl", "-n", "kern.memorystatus_vm_pressure_level"], runner=runner
    )
    swap = _run_child(["/usr/sbin/sysctl", "vm.swapusage"], runner=runner)
    return parse_pressure_level(_command_text(pressure)), parse_swap_used_bytes(_command_text(swap))


def run_admission(
    evidence_dir: Path,
    *,
    runner: Callable = subprocess.check_output,
    disk_usage: Callable = shutil.disk_usage,
    monotonic: Callable = time.monotonic,
    sleep: Callable = time.sleep,
    wall_clock: Callable = lambda: datetime.now(timezone.utc).isoformat(),
    own_pid: int | None = None,
) -> dict[str, object]:
    """Record a bounded admission decision only; never starts, stops, or retries a model."""
    evidence_dir = Path(evidence_dir)
    if evidence_dir.exists() or evidence_dir.is_symlink():
        raise AdmissionError("evidence directory already exists; refusing overwrite")
    if not evidence_dir.parent.is_dir():
        raise AdmissionError("evidence parent must already exist")
    evidence_dir.mkdir()
    own_pid = os.getpid() if own_pid is None else own_pid
    start = monotonic()
    deadline = start + TOTAL_DEADLINE_SECONDS
    first_swap: int | None = None
    window_start: float | None = None
    previous_sample: float | None = None
    sample_count = 0
    reason = "admission_deadline_expired"
    status = "denied"
    jsonl_path = evidence_dir / "admission-samples.jsonl"
    result_path = evidence_dir / "admission-result.json"

    with jsonl_path.open("x", encoding="utf-8") as stream:
        while True:
            now = monotonic()
            if now >= deadline:
                break
            row: dict[str, object] = {
                "sample_index": sample_count,
                "wall_time_utc": wall_clock(),
                "elapsed_seconds": now - start,
            }
            try:
                pressure, swap_used = _probe_pressure_and_swap(runner)
                if first_swap is None:
                    first_swap = swap_used
                swap_growth = max(0, swap_used - first_swap)
                blockers = _probe_processes(runner, own_pid)
                storage = _probe_storage(runner, disk_usage)
                observed_at = monotonic()
                row["elapsed_seconds"] = observed_at - start
                row.update({
                    "pressure_level": pressure,
                    "swap_used_bytes": swap_used,
                    "swap_initial_bytes": first_swap,
                    "swap_growth_bytes": swap_growth,
                    "process_blockers": blockers,
                    "storage": storage,
                })
                sample_ok = (
                    observed_at < deadline
                    and pressure == NORMAL_PRESSURE_LEVEL
                    and swap_growth <= MAX_SWAP_GROWTH_BYTES
                    and not blockers
                )
                if previous_sample is not None and observed_at - previous_sample > MAX_SAMPLE_GAP_SECONDS:
                    window_start = None
                    row["window_reset_reason"] = "sample_gap_exceeded"
                if sample_ok:
                    if window_start is None:
                        window_start = observed_at
                    qualified_seconds = observed_at - window_start
                    row["continuous_normal_seconds"] = qualified_seconds
                    row["sample_qualified"] = True
                    if qualified_seconds >= NORMAL_WINDOW_SECONDS:
                        status = "admitted_host_prerequisites_only"
                        reason = "normal_pressure_window_and_swap_process_storage_gates_satisfied"
                        row["decision"] = "admitted"
                        stream.write(json.dumps(row, sort_keys=True) + "\n")
                        stream.flush()
                        os.fsync(stream.fileno())
                        sample_count += 1
                        break
                else:
                    if observed_at >= deadline:
                        reason = "admission_deadline_expired"
                    elif pressure != NORMAL_PRESSURE_LEVEL:
                        reason = "memory_pressure_not_normal"
                    elif swap_growth > MAX_SWAP_GROWTH_BYTES:
                        reason = "swap_growth_limit_exceeded"
                    elif blockers:
                        reason = "cargo_or_mycity_process_active"
                    window_start = None
                    row["continuous_normal_seconds"] = 0.0
                    row["sample_qualified"] = False
                    row["window_reset_reason"] = reason
                row["decision"] = "continue_waiting"
            except Exception as error:  # Fail closed and retain only the exception class, not command/env data.
                reason = "probe_failed:" + type(error).__name__
                status = "denied"
                row["probe_error"] = type(error).__name__
                row["sample_qualified"] = False
                row["continuous_normal_seconds"] = 0.0
                row["decision"] = "denied"
                stream.write(json.dumps(row, sort_keys=True) + "\n")
                stream.flush()
                os.fsync(stream.fileno())
                sample_count += 1
                break
            stream.write(json.dumps(row, sort_keys=True) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
            sample_count += 1
            previous_sample = observed_at
            if monotonic() >= deadline:
                reason = "admission_deadline_expired"
                break
            sleep(min(SAMPLE_INTERVAL_SECONDS, max(0.0, deadline - monotonic())))

    result = {
        "schema": "mycity-rare-host-admission-v1",
        "status": status,
        "reason": reason,
        "samples": sample_count,
        "required_continuous_normal_seconds": NORMAL_WINDOW_SECONDS,
        "deadline_seconds": TOTAL_DEADLINE_SECONDS,
        "elapsed_seconds": max(0.0, monotonic() - start),
        "window_ended_monotonic_seconds": previous_sample if status == "denied" else observed_at,
        "initial_swap_used_bytes": first_swap,
        "child_environment_allowlist": sorted(SAFE_CHILD_ENV),
        "max_swap_growth_bytes": MAX_SWAP_GROWTH_BYTES,
        "minimum_external_free_bytes": MIN_FREE_BYTES,
        "admission_only": True,
        "model_started": False,
        "performance_acceptance": False,
    }
    with result_path.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    return result
