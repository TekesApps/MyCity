"""Synthetic contract tests for batch_audit; never constitute M0 evidence."""
import hashlib
import json
import tempfile
import unittest
from pathlib import Path

import batch_audit


SOURCE = "a" * 64
BINARY = "b" * 64


def _record(class_id, duration_ns):
    return bytes([class_id]) + duration_ns.to_bytes(8, "little")


class BatchAuditContractTests(unittest.TestCase):
    def _fixture(self, kind="claims", phase="smoke", *, row_changes=None,
                 ranges_changes=None, raw=None, final_newline=True, rows=1):
        root = Path(tempfile.mkdtemp(dir="/tmp", prefix="mycity-batch-audit-"))
        (root / "trials").mkdir()
        class_ids = [2] if kind == "claims" else [6, 7]
        raw = raw if raw is not None else b"".join(_record(cls, i + 1) for i, cls in enumerate(class_ids))
        lines = []
        for ordinal in range(1, rows + 1):
            trial = f"{kind}-{ordinal:03d}"
            trial_root = root / "trials" / trial
            trial_root.mkdir()
            raw_path = trial_root / "samples.bin"
            raw_path.write_bytes(raw)
            counts = [None] * 10
            for cls in class_ids:
                counts[cls] = 1
            item = {
                "path": "samples.bin", "start": 0, "end": len(raw),
                "expected_samples_by_class": counts,
                "expected_file_sha256": hashlib.sha256(raw).hexdigest(),
            }
            if ranges_changes:
                ranges_changes(item, ordinal)
            row = {
                "ordinal": ordinal, "trial": trial, "stratum": kind,
                "source_sha256": SOURCE, "binary_sha256": BINARY,
                "eligible_duration_ranges": [item],
            }
            if row_changes:
                row_changes(row, ordinal)
            lines.append(json.dumps(row, separators=(",", ":")).encode())
        ledger = b"\n".join(lines) + (b"\n" if final_newline else b"")
        (root / "trial-analysis.jsonl").write_bytes(ledger)
        return root

    def _audit(self, root, kind="claims", phase="smoke", *, source=SOURCE, binary=BINARY):
        return batch_audit.audit_batch(root, source, binary, kind, phase)

    def test_one_row_smoke_is_numeric_but_not_a_formal_count_pass(self):
        report = self._audit(self._fixture())
        result = report["classes"]["L2_claims_batch"]
        self.assertEqual(report["observed_analysis_rows"], 1)
        self.assertEqual(result["numeric"]["selected_sample_count"], 1)
        self.assertEqual(result["claimed_trial_rows_with_samples"], 1)
        self.assertEqual(result["actual_independent_trial_identity_gate"], "not_proven_by_numeric_audit")
        self.assertEqual(report["memory_16gb_gate"], "not_run")
        self.assertEqual(report["full_M0"], "not_accepted")

    def test_source_classes_six_and_seven_are_counted_independently(self):
        report = self._audit(self._fixture(kind="source"), kind="source")
        for name in ("air_source_page", "air_cell_page"):
            self.assertEqual(report["classes"][name]["numeric"]["selected_sample_count"], 1)
            self.assertEqual(report["classes"][name]["claimed_trial_rows_with_samples"], 1)

    def test_source_binary_and_ordinal_mismatches_are_rejected(self):
        root = self._fixture(row_changes=lambda row, _: row.update(source_sha256="c" * 64))
        with self.assertRaises(ValueError):
            self._audit(root)
        root = self._fixture(row_changes=lambda row, _: row.update(binary_sha256="c" * 64))
        with self.assertRaises(ValueError):
            self._audit(root)
        root = self._fixture(row_changes=lambda row, _: row.update(ordinal=2))
        with self.assertRaises(ValueError):
            self._audit(root)

    def test_missing_row_and_missing_final_newline_are_rejected(self):
        with self.assertRaises(ValueError):
            self._audit(self._fixture(phase="formal"), phase="formal")
        with self.assertRaises(ValueError):
            self._audit(self._fixture(final_newline=False))

    def test_parent_escape_path_is_rejected(self):
        root = self._fixture(ranges_changes=lambda item, _: item.update(path="../escape.bin"))
        with self.assertRaises(ValueError):
            self._audit(root)

    def test_overlapping_ranges_are_rejected(self):
        raw = _record(2, 1) + _record(2, 2)

        def ranges(item, _):
            item["end"] = 18
            item["expected_samples_by_class"][2] = 2

        root = self._fixture(raw=raw, ranges_changes=ranges)
        row = json.loads((root / "trial-analysis.jsonl").read_text())
        row["eligible_duration_ranges"].append({
            **row["eligible_duration_ranges"][0], "start": 9, "end": 18,
        })
        (root / "trial-analysis.jsonl").write_text(json.dumps(row) + "\n")
        with self.assertRaises(ValueError):
            self._audit(root)

    def test_per_file_expected_count_mismatch_is_rejected(self):
        root = self._fixture(ranges_changes=lambda item, _: item["expected_samples_by_class"].__setitem__(2, 2))
        with self.assertRaises(ValueError):
            self._audit(root)

    def test_wrong_file_sha_is_rejected(self):
        root = self._fixture(ranges_changes=lambda item, _: item.update(expected_file_sha256="0" * 64))
        with self.assertRaises(ValueError):
            self._audit(root)


class HistogramCrosscheckTests(unittest.TestCase):
    def test_exact_rank_values_fit_conservative_intervals(self):
        numeric = {"selected_sample_count": 200, "p95_ns": 190, "p99_ns": 198}
        histogram = {
            "samples": 200,
            "p95": {"nearest_rank": 190, "lower_exclusive_ns": 189, "upper_inclusive_ns": 190},
            "p99": {"nearest_rank": 198, "lower_exclusive_ns": 197, "upper_inclusive_ns": 198},
        }
        result = batch_audit.verify_reported_histogram(numeric, histogram)
        self.assertEqual(result["population_and_quantile_intervals"], "matched_raw_numeric_values")
        self.assertEqual(result["eligibility_and_full_gate"], "not_proven_by_numeric_crosscheck")

    def test_off_by_tail_interval_and_rank_are_rejected(self):
        numeric = {"selected_sample_count": 200, "p95_ns": 190, "p99_ns": 198}
        histogram = {
            "samples": 200,
            "p95": {"nearest_rank": 190, "lower_exclusive_ns": 190, "upper_inclusive_ns": 191},
            "p99": {"nearest_rank": 198, "lower_exclusive_ns": 197, "upper_inclusive_ns": 198},
        }
        with self.assertRaises(ValueError):
            batch_audit.verify_reported_histogram(numeric, histogram)
        histogram["p95"] = {"nearest_rank": 191, "lower_exclusive_ns": 189, "upper_inclusive_ns": 190}
        with self.assertRaises(ValueError):
            batch_audit.verify_reported_histogram(numeric, histogram)

    def test_histogram_population_mismatch_is_rejected(self):
        numeric = {"selected_sample_count": 200, "p95_ns": 190, "p99_ns": 198}
        histogram = {
            "samples": 199,
            "p95": {"nearest_rank": 190, "lower_exclusive_ns": 189, "upper_inclusive_ns": 190},
            "p99": {"nearest_rank": 198, "lower_exclusive_ns": 197, "upper_inclusive_ns": 198},
        }
        with self.assertRaises(ValueError):
            batch_audit.verify_reported_histogram(numeric, histogram)

    def test_zero_and_u64_max_quantiles_are_valid_brackets(self):
        zero = {"selected_sample_count": 1, "p95_ns": 0, "p99_ns": 0}
        zero_hist = {
            "samples": 1,
            "p95": {"nearest_rank": 1, "lower_exclusive_ns": 0, "upper_inclusive_ns": 0},
            "p99": {"nearest_rank": 1, "lower_exclusive_ns": 0, "upper_inclusive_ns": 0},
        }
        batch_audit.verify_reported_histogram(zero, zero_hist)
        maximum = (1 << 64) - 1
        upper = {"selected_sample_count": 1, "p95_ns": maximum, "p99_ns": maximum}
        upper_hist = {
            "samples": 1,
            "p95": {"nearest_rank": 1, "lower_exclusive_ns": maximum - 1, "upper_inclusive_ns": maximum},
            "p99": {"nearest_rank": 1, "lower_exclusive_ns": maximum - 1, "upper_inclusive_ns": maximum},
        }
        batch_audit.verify_reported_histogram(upper, upper_hist)


if __name__ == "__main__":
    unittest.main()
