#!/usr/bin/env python3
"""Bounded read-only PROC_PIDREGIONINFO sample for one pinned live phase.

This candidate reads only region metadata. It never starts/stops a target,
reads mapped bytes, or treats region counters as additive physical footprint.
No native call is made until the observer/source/executable/OS identity and
phase have matched the explicit command-line pins.
"""
from __future__ import annotations

import argparse
import ctypes
import hashlib
import importlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import resource
import re
import sys
import time
import tracemalloc

SUPPORT_SHA256 = {
    "observe.py": "0d7ddad946762bb3a9b683caa71dcf99cda6de08ff14c45c6877757e0d468d5d",
    "native_metrics.py": "4a672f7c711f30250ec493f63dad6ba95895e97ec5d10edcc99d034eb989051e",
    "process_activity.py": "1abbc0771180936fa660b34db4f6428f199fd467e0f866548e8a12bdb4c58aa9",
    "frame_codec.py": "005be0c42f1703e0aae4d6e7597d83e65654ffb805f22456873ae042e4a9b97f",
}
SDK_HEADER_SHA256 = {
    "libproc.h": "246d87709fc6b9157ce5cf3c475656ac48e0e1ae8bbdc46cf45acd34294448cd",
    "sys/proc_info.h": "e427fa96b348537b21552b9de71e01039410bcad2cedee5584c5e5fddafd70fc",
    "mach/vm_statistics.h": "b2b81f9e7efff57b648b4705a1ad08ffb55b99d0966b02c110f95fa454e175b7",
}
CLOCK_HANDSHAKE_SHA256 = "9c092e487ea1348901d70e6417f67096596f6f36c1f6405ea3eeb62a9d2f88ac"
REGION_FIELDS = [
    ("pri_protection", "uint32_t"),
    ("pri_max_protection", "uint32_t"),
    ("pri_inheritance", "uint32_t"),
    ("pri_flags", "uint32_t"),
    ("pri_offset", "uint64_t"),
    ("pri_behavior", "uint32_t"),
    ("pri_user_wired_count", "uint32_t"),
    ("pri_user_tag", "uint32_t"),
    ("pri_pages_resident", "uint32_t"),
    ("pri_pages_shared_now_private", "uint32_t"),
    ("pri_pages_swapped_out", "uint32_t"),
    ("pri_pages_dirtied", "uint32_t"),
    ("pri_ref_count", "uint32_t"),
    ("pri_shadow_depth", "uint32_t"),
    ("pri_share_mode", "uint32_t"),
    ("pri_private_pages_resident", "uint32_t"),
    ("pri_shared_pages_resident", "uint32_t"),
    ("pri_obj_id", "uint32_t"),
    ("pri_depth", "uint32_t"),
    ("pri_address", "uint64_t"),
    ("pri_size", "uint64_t"),
]
REGION_OFFSETS = [0, 4, 8, 12, 16, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60, 64, 68, 72, 76, 80, 88]
REGION_SIZE = 96
MAX_REGIONS = 512
MAX_SCAN_SECONDS = 1.0
MAX_INPUT_BYTES = 256 * 1024
MAX_INPUT_ROWS = 256
MAX_INPUT_LINE_BYTES = 8192
MAX_OUTPUT_BYTES = 128 * 1024
MAX_WAIT_SECONDS = 620.0
MAX_PRE_SAMPLE_AGE_NS = 1_500_000_000
MAX_POST_BRACKET_WAIT_SECONDS = 3.0
MAX_TAGS = 128
U64_MAX = (1 << 64) - 1
PHASES = {"prepared", "filled", "retiring", "returned"}


class Incomplete(RuntimeError):
    pass


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(65536):
            h.update(chunk)
    return h.hexdigest()


def load_clock_handshake():
    path = Path(__file__).with_name("clock_handshake.py")
    if sha256(path) != CLOCK_HANDSHAKE_SHA256:
        raise Incomplete("clock_handshake_helper_sha256_mismatch")
    spec = importlib.util.spec_from_file_location("mycity_clock_handshake", path)
    if spec is None or spec.loader is None:
        raise Incomplete("clock_handshake_helper_import_unavailable")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def regular_file(path: Path, *, max_bytes: int | None = None) -> os.stat_result:
    info = path.lstat()
    if path.is_symlink() or not path.is_file():
        raise Incomplete("path_not_regular_file")
    if max_bytes is not None and info.st_size > max_bytes:
        raise Incomplete("input_file_cap")
    return info


class JsonlTail:
    """Small append-only reader; replacement, truncation, and cap hits fail closed."""

    def __init__(self, path: Path):
        self.path = path
        self.inode: tuple[int, int] | None = None
        self.offset = 0
        self.total = 0
        self.rows = 0
        self.pending = bytearray()
        self.decoded: list[dict] = []

    def refresh(self) -> list[dict]:
        try:
            info = regular_file(self.path, max_bytes=MAX_INPUT_BYTES)
        except FileNotFoundError:
            return []
        inode = (info.st_dev, info.st_ino)
        if self.inode is None:
            self.inode = inode
        elif inode != self.inode or info.st_size < self.offset:
            raise Incomplete("observer_log_replaced_or_truncated")
        delta = info.st_size - self.offset
        if self.total + delta > MAX_INPUT_BYTES:
            raise Incomplete("observer_log_byte_cap")
        with self.path.open("rb") as stream:
            stream.seek(self.offset)
            chunk = stream.read(delta)
        if len(chunk) != delta:
            raise Incomplete("observer_log_changed_during_read")
        self.offset += len(chunk)
        self.total += len(chunk)
        self.pending.extend(chunk)
        new: list[dict] = []
        while True:
            newline = self.pending.find(b"\n")
            if newline < 0:
                if len(self.pending) >= MAX_INPUT_LINE_BYTES:
                    raise Incomplete("observer_log_line_cap")
                break
            raw = bytes(self.pending[: newline + 1])
            del self.pending[: newline + 1]
            if len(raw) > MAX_INPUT_LINE_BYTES:
                raise Incomplete("observer_log_line_cap")
            self.rows += 1
            if self.rows > MAX_INPUT_ROWS:
                raise Incomplete("observer_log_row_cap")
            value = json.loads(raw)
            if not isinstance(value, dict):
                raise Incomplete("observer_log_row_not_object")
            self.decoded.append(value)
            new.append(value)
        return new


def import_pinned_support(support_dir: Path):
    for name, expected in SUPPORT_SHA256.items():
        path = support_dir / name
        regular_file(path)
        if sha256(path) != expected:
            raise Incomplete(f"support_hash_mismatch:{name}")
    sys.path.insert(0, str(support_dir))
    native = importlib.import_module("native_metrics")
    observe = importlib.import_module("observe")
    observe.native = native
    return native, observe


def sdk_provenance(native) -> tuple[dict, type[ctypes.Structure], dict[int, list[str]], int]:
    sdk = native.SDK
    hashes = {}
    for relative, expected in SDK_HEADER_SHA256.items():
        path = sdk / relative
        regular_file(path)
        actual = sha256(path)
        if actual != expected:
            raise Incomplete(f"sdk_header_hash_mismatch:{relative}")
        hashes[relative] = actual
    if platform.system() != "Darwin" or platform.machine() not in {"arm64", "x86_64"}:
        raise Incomplete("unsupported_platform_or_architecture")
    sdk_fields = native.fields(
        "sys/proc_info.h",
        "proc_regioninfo",
        {"uint32_t": ctypes.c_uint32, "uint64_t": ctypes.c_uint64},
    )
    names_and_sizes = [(name, ctypes.sizeof(kind)) for name, kind in sdk_fields]
    if names_and_sizes != [(name, 4 if kind == "uint32_t" else 8) for name, kind in REGION_FIELDS]:
        raise Incomplete("unsupported_proc_regioninfo_field_layout")

    class ProcRegionInfo(ctypes.Structure):
        _fields_ = sdk_fields

    offsets = [getattr(ProcRegionInfo, name).offset for name, _ in REGION_FIELDS]
    if ctypes.sizeof(ProcRegionInfo) != REGION_SIZE or offsets != REGION_OFFSETS:
        raise Incomplete("unsupported_proc_regioninfo_abi_layout")
    page_size = int(os.sysconf("SC_PAGE_SIZE"))
    if page_size <= 0:
        raise Incomplete("page_size_unavailable")
    tags: dict[int, list[str]] = {}
    vm_header = (sdk / "mach/vm_statistics.h").read_text()
    for name, value in re.findall(r"^\s*#define\s+(VM_MEMORY_[A-Z0-9_]+)\s+([0-9]+)\b", vm_header, re.M):
        tags.setdefault(int(value), []).append(name)
    return (
        {"headers_sha256": hashes, "proc_regioninfo_size_bytes": ctypes.sizeof(ProcRegionInfo),
         "proc_regioninfo_offsets": dict(zip((n for n, _ in REGION_FIELDS), offsets)),
         "proc_pidregioninfo_flavor": native.constant("sys/proc_info.h", "PROC_PIDREGIONINFO"),
         "page_size_bytes": page_size, "vm_memory_tag_names_from_header": len(tags)},
        ProcRegionInfo,
        {k: sorted(v) for k, v in tags.items()},
        page_size,
    )


def expected_target(row: dict, role: str, pid: int, start_abstime: int, exe_path: Path) -> dict:
    if row.get("type") != "phase_sample" or row.get("native_capture_complete") is not True:
        raise Incomplete("phase_sample_not_complete")
    target = row.get(role)
    if not isinstance(target, dict):
        raise Incomplete("target_role_missing")
    if target.get("pid") != pid or target.get("os_process_start_abstime") != start_abstime:
        raise Incomplete("target_pid_or_os_start_mismatch")
    captured_path = target.get("executable_path")
    if not isinstance(captured_path, str) or Path(captured_path) != exe_path:
        raise Incomplete("target_executable_path_mismatch")
    process_name = target.get("process_name")
    if not isinstance(process_name, str) or not process_name:
        raise Incomplete("target_process_name_missing")
    parent_pid = target.get("parent_pid")
    footprint = target.get("phys_footprint_bytes")
    if not isinstance(parent_pid, int) or not isinstance(footprint, int) or footprint < 0:
        raise Incomplete("target_parent_or_footprint_missing")
    return target


def absolute_interval(row: dict) -> tuple[int, int]:
    value = row.get("absolute_monotonic_ns")
    if not isinstance(value, dict) or any(value.get(key) != expected for key, expected in
            shared_clock_record().items() if key in {"function", "clock_name", "clock_id", "unit"}):
        raise Incomplete("absolute_monotonic_clock_or_unit_missing")
    begin = value.get("begin")
    end = value.get("end")
    if type(begin) is not int or type(end) is not int or begin < 0 or end < 0:
        raise Incomplete("absolute_monotonic_timestamp_missing_or_invalid")
    if begin > end:
        raise Incomplete("absolute_monotonic_interval_reversed")
    return begin, end


def monotonic_clock_record() -> dict:
    info = time.get_clock_info("monotonic")
    if not info.monotonic:
        raise Incomplete("local_monotonic_clock_not_monotonic")
    return {
        "function": "time.clock_gettime_ns",
        "clock_name": "CLOCK_MONOTONIC",
        "clock_id": int(time.CLOCK_MONOTONIC),
        "unit": "ns",
        "implementation": info.implementation,
        "resolution_ns": int(round(info.resolution * 1_000_000_000)),
        "monotonic": bool(info.monotonic),
        "adjustable": bool(info.adjustable),
    }


def shared_clock_record() -> dict:
    return monotonic_clock_record()


def shared_absolute_clock_ns() -> int:
    return time.clock_gettime_ns(time.CLOCK_MONOTONIC)


def bracket_order_error(pre_begin: int, pre_end: int, scan_begin: int, scan_end: int,
                        post_begin: int, post_end: int) -> str | None:
    values = (pre_begin, pre_end, scan_begin, scan_end, post_begin, post_end)
    if any(type(value) is not int or value < 0 for value in values):
        return "absolute_monotonic_timestamp_missing_or_invalid"
    if not pre_begin <= pre_end <= scan_begin <= scan_end <= post_begin <= post_end:
        return "absolute_monotonic_bracket_order_invalid"
    if scan_begin - pre_end > MAX_PRE_SAMPLE_AGE_NS:
        return "pre_phase_sample_stale"
    return None


def post_bracket_candidate(rows: list[dict], role: str, pid: int, start_abstime: int,
                          exe_path: Path, phase: str, fingerprint: list,
                          pre_target: dict, scan_end_ns: int) -> tuple[dict | None, str | None]:
    """Find a valid post-scan row, or fail the whole bracket on lifecycle change."""
    for row in rows:
        if row.get("type") == "observer_terminal":
            return None, "observer_terminal_before_post_bracket"
        if row.get("type") != "phase_sample":
            continue
        if row.get("phase") != phase:
            return None, "phase_changed_before_post_bracket"
        if row.get("event_fingerprint") != fingerprint:
            return None, "phase_event_changed_before_post_bracket"
        target = expected_target(row, role, pid, start_abstime, exe_path)
        if any(target.get(key) != pre_target.get(key) for key in
               ("pid", "os_process_start_abstime", "parent_pid", "process_name", "executable_path")):
            return None, "target_identity_changed_before_post_bracket"
        event = row.get("event")
        if not isinstance(event, dict) or event.get("phase") != phase or event.get("generation") != fingerprint[1]:
            return None, "phase_event_generation_changed_before_post_bracket"
        capture_begin, capture_end = absolute_interval(row)
        if capture_begin >= scan_end_ns and capture_end >= capture_begin:
            return row, None
    return None, None


def update_phase_candidate(rows: list[dict], candidate: dict | None, phase_seen: bool,
                           role: str, pid: int, start_abstime: int, exe_path: Path,
                           phase: str) -> tuple[dict | None, bool]:
    """Keep the newest complete sample for one unchanged phase/identity lifecycle."""
    candidate_fingerprint = candidate.get("event_fingerprint") if candidate else None
    candidate_target = expected_target(candidate, role, pid, start_abstime, exe_path) if candidate else None
    for row in rows:
        if row.get("type") == "observer_terminal":
            raise Incomplete("observer_terminated_before_target_phase")
        if row.get("type") != "phase_sample":
            continue
        row_phase = row.get("phase")
        if row_phase != phase:
            if phase_seen:
                raise Incomplete("phase_changed_before_region_scan")
            continue
        if candidate is not None:
            fingerprint = row.get("event_fingerprint")
            if fingerprint != candidate_fingerprint:
                raise Incomplete("phase_event_changed_before_region_scan")
        target = expected_target(row, role, pid, start_abstime, exe_path)
        fingerprint = row.get("event_fingerprint")
        if not isinstance(fingerprint, list) or len(fingerprint) != 5 or fingerprint[0] != phase:
            raise Incomplete("phase_event_fingerprint_missing")
        event = row.get("event")
        if not isinstance(event, dict) or event.get("phase") != phase or event.get("generation") != fingerprint[1]:
            raise Incomplete("phase_event_fingerprint_mismatch")
        absolute_interval(row)
        if candidate_target is not None and any(
                target.get(key) != candidate_target.get(key) for key in
                ("pid", "os_process_start_abstime", "parent_pid", "process_name", "executable_path")):
            raise Incomplete("target_identity_changed_before_region_scan")
        candidate = row
        candidate_fingerprint = fingerprint
        candidate_target = target
        phase_seen = True
    return candidate, phase_seen


def candidate_is_fresh(candidate: dict, now_ns: int) -> bool:
    _begin, end = absolute_interval(candidate)
    if end > now_ns:
        raise Incomplete("phase_sample_timestamp_in_future_or_clock_mismatch")
    return now_ns - end <= MAX_PRE_SAMPLE_AGE_NS


def check_identity(native, observe, pid: int, start_abstime: int, parent_pid: int, process_name: str, exe_path: Path) -> dict:
    expected_relation = (parent_pid, None, None, process_name)
    usage, error, proof = observe.bound_usage(pid, expected_relation, start_abstime)
    if error or usage is None:
        raise Incomplete("target_identity_unavailable:" + str(error))
    actual_path = native.process_path(pid)
    if actual_path is None or Path(actual_path) != exe_path:
        raise Incomplete("target_path_changed_or_unavailable")
    return {"proof": proof, "usage": usage, "executable_path": actual_path}


def empty_totals() -> dict:
    return {
        "regions": 0,
        "region_range_bytes": 0,
        "resident_pages": 0,
        "private_resident_pages": 0,
        "shared_resident_pages": 0,
        "shared_now_private_pages": 0,
        "swapped_out_pages": 0,
        "dirtied_pages": 0,
        "user_wired_count": 0,
    }


def add_region_totals(total: dict, region) -> None:
    total["regions"] += 1
    total["region_range_bytes"] += int(region.pri_size)
    total["resident_pages"] += int(region.pri_pages_resident)
    total["private_resident_pages"] += int(region.pri_private_pages_resident)
    total["shared_resident_pages"] += int(region.pri_shared_pages_resident)
    total["shared_now_private_pages"] += int(region.pri_pages_shared_now_private)
    total["swapped_out_pages"] += int(region.pri_pages_swapped_out)
    total["dirtied_pages"] += int(region.pri_pages_dirtied)
    total["user_wired_count"] += int(region.pri_user_wired_count)


def region_scan(native, Region, tags: dict[int, list[str]], pid: int, page_size: int) -> dict:
    region = Region()
    flavor = native.constant("sys/proc_info.h", "PROC_PIDREGIONINFO")
    start = shared_absolute_clock_ns()
    deadline = start + int(MAX_SCAN_SECONDS * 1_000_000_000)
    address = 0
    previous_end = 0
    totals = empty_totals()
    by_tag: dict[int, dict] = {}
    status = "incomplete"
    reason = None
    errno_value = None
    for _ in range(MAX_REGIONS):
        if shared_absolute_clock_ns() >= deadline:
            reason = "region_scan_time_cap"
            break
        ctypes.set_errno(0)
        got = native.lib.proc_pidinfo(pid, flavor, address, ctypes.byref(region), ctypes.sizeof(region))
        call_errno = ctypes.get_errno()
        if shared_absolute_clock_ns() > deadline:
            reason = "region_scan_time_cap"
            break
        if got == 0:
            errno_value = call_errno
            reason = "region_query_empty_while_target_may_be_live"
            break
        if got != ctypes.sizeof(region):
            errno_value = call_errno
            reason = "region_query_short_or_unknown_abi"
            break
        begin = int(region.pri_address)
        size = int(region.pri_size)
        end = begin + size
        if size <= 0 or end > U64_MAX or end <= address or begin < address or begin < previous_end:
            reason = "region_address_or_size_nonprogress"
            break
        tag = int(region.pri_user_tag)
        if tag not in by_tag and len(by_tag) >= MAX_TAGS:
            reason = "region_tag_cardinality_cap"
            break
        bucket = by_tag.setdefault(tag, empty_totals())
        add_region_totals(totals, region)
        add_region_totals(bucket, region)
        previous_end = end
        address = end
    else:
        reason = "region_count_cap"
    scan_end = shared_absolute_clock_ns()
    elapsed = scan_end - start
    if reason is None:
        reason = "region_scan_no_explicit_end_marker"
    category_bytes = {
        key: value * page_size
        for key, value in totals.items()
        if key.endswith("_pages")
    }
    by_tag_rows = [
        {"user_tag_value": tag, "sdk_names": tags.get(tag, []), **counts,
         "page_category_bytes": {k: v * page_size for k, v in counts.items() if k.endswith("_pages")}}
        for tag, counts in sorted(by_tag.items())
    ]
    return {
        "status": status,
        "reason": reason,
        "errno": errno_value,
        "scan_begin_absolute_monotonic_ns": start,
        "scan_end_absolute_monotonic_ns": scan_end,
        "scan_clock": shared_clock_record(),
        "scan_elapsed_ns": elapsed,
        "max_regions": MAX_REGIONS,
        "max_scan_seconds": MAX_SCAN_SECONDS,
        "scan_time_limit_semantics": "cooperative_checks_between_and_after_synchronous_proc_pidinfo_calls; not_hard_preemptible",
        "output_byte_cap": MAX_OUTPUT_BYTES,
        "output_byte_cap_bounds_python_heap": False,
        "regions_returned": totals["regions"],
        "next_query_address": address,
        "region_range_bytes": totals["region_range_bytes"] if totals["regions"] else None,
        "page_size_bytes": page_size,
        "page_counters_non_additive": True,
        "page_counters": totals if totals["regions"] else None,
        "page_counter_bytes_at_system_page_size": category_bytes if totals["regions"] else None,
        "by_user_tag": by_tag_rows if totals["regions"] else None,
        "full_address_space_enumerated": False,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--support-dir", required=True, type=Path)
    parser.add_argument("--observer-jsonl", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--source-sha256", required=True)
    parser.add_argument("--phase-observer-sha256", required=True)
    parser.add_argument("--clock-handshake-fd", required=True, type=int)
    parser.add_argument("--clock-handshake-only", action="store_true",
                        help="complete the inherited clock handshake, print its receipt, then exit before native/query work")
    parser.add_argument("--exe", required=True, type=Path)
    parser.add_argument("--exe-sha256", required=True)
    parser.add_argument("--phase", required=True, choices=sorted(PHASES))
    parser.add_argument("--role", required=True, choices=("pool", "model_helper", "supervisor"))
    parser.add_argument("--pid", required=True, type=int)
    parser.add_argument("--os-start-abstime", required=True, type=int)
    return parser.parse_args()


def run(args: argparse.Namespace) -> dict:
    if (not re.fullmatch(r"[0-9a-f]{64}", args.source_sha256)
            or not re.fullmatch(r"[0-9a-f]{64}", args.exe_sha256)
            or not re.fullmatch(r"[0-9a-f]{64}", args.phase_observer_sha256)):
        raise Incomplete("invalid_source_or_executable_sha256")
    if args.pid <= 0 or args.os_start_abstime <= 0:
        raise Incomplete("invalid_target_identity")
    exe = args.exe.resolve(strict=True)
    if regular_file(exe).st_mode & 0o111 == 0 or sha256(exe) != args.exe_sha256:
        raise Incomplete("executable_path_or_hash_pin_mismatch")
    args.output.parent.resolve(strict=True)
    if args.output.exists() or args.output.is_symlink() or args.output == args.observer_jsonl:
        raise Incomplete("output_must_be_fresh_and_separate")

    clock_handshake = load_clock_handshake()
    clock_handshake_receipt = clock_handshake.child_handshake(args.clock_handshake_fd,
                                                              "region_observer")
    if args.clock_handshake_only:
        return {
            "schema": "mycity-clock-handshake-only-v1",
            "status": "accepted",
            "clock_handshake_helper_sha256": CLOCK_HANDSHAKE_SHA256,
            "clock_handshake": clock_handshake_receipt,
            "native_queries_performed": False,
            "target_observed": False,
        }

    native, observe = import_pinned_support(args.support_dir.resolve(strict=True))
    sdk, Region, tags, page_size = sdk_provenance(native)
    tail = JsonlTail(args.observer_jsonl)
    start = time.monotonic()
    observer_start = None
    target_row = None
    target_phase_seen = False
    while time.monotonic() - start < MAX_WAIT_SECONDS:
        for row in tail.refresh():
            if row.get("type") == "observer_start":
                if observer_start is not None:
                    raise Incomplete("duplicate_observer_start")
                if (row.get("status") != "running"
                        or row.get("expected_source_sha256") != args.source_sha256
                        or row.get("observer_sha256") != args.phase_observer_sha256
                        or row.get("executable_sha256") != args.exe_sha256
                        or row.get("support_sha256") != SUPPORT_SHA256
                        or row.get("monotonic_clock") != monotonic_clock_record()):
                    raise Incomplete("observer_source_or_executable_pin_mismatch")
                observer_start = row
            elif row.get("type") == "observer_terminal":
                raise Incomplete("observer_terminated_before_target_phase")
            elif row.get("type") == "phase_sample":
                if row.get("phase") == args.phase and observer_start is None:
                    raise Incomplete("phase_before_observer_start_record")
                target_row, target_phase_seen = update_phase_candidate(
                    [row], target_row, target_phase_seen, args.role, args.pid,
                    args.os_start_abstime, exe, args.phase,
                )
        if target_row is not None and candidate_is_fresh(target_row, shared_absolute_clock_ns()):
            break
        time.sleep(0.05)
    if target_row is None:
        raise Incomplete("target_phase_wait_timeout")
    if not candidate_is_fresh(target_row, shared_absolute_clock_ns()):
        raise Incomplete("target_phase_sample_stale")
    target_info = expected_target(target_row, args.role, args.pid, args.os_start_abstime, exe)
    pre_begin, pre_end = absolute_interval(target_row)
    fingerprint = target_row.get("event_fingerprint")
    event = target_row["event"]
    if args.role == "model_helper" and (event.get("pid") != args.pid or event.get("application_instance_unix_ns") != fingerprint[4]):
        raise Incomplete("model_helper_event_identity_mismatch")

    rusage_pre = check_identity(
        native, observe, args.pid, args.os_start_abstime,
        target_info["parent_pid"], target_info["process_name"], exe,
    )
    self_usage_before = observe.usage(os.getpid())
    self_rusage_before = resource.getrusage(resource.RUSAGE_SELF)
    self_tracemalloc_before = tracemalloc.get_traced_memory() if tracemalloc.is_tracing() else (None, None)
    region_result = region_scan(native, Region, tags, args.pid, page_size)
    rusage_post = None
    post_error = None
    try:
        rusage_post = check_identity(
            native, observe, args.pid, args.os_start_abstime,
            target_info["parent_pid"], target_info["process_name"], exe,
        )
    except Incomplete as exc:
        post_error = str(exc)

    scan_end = region_result["scan_end_absolute_monotonic_ns"]
    bracket_end_row = None
    bracket_invalid_reason = None
    bracket_deadline = scan_end / 1_000_000_000 + MAX_POST_BRACKET_WAIT_SECONDS
    if not pre_begin <= pre_end <= region_result["scan_begin_absolute_monotonic_ns"]:
        bracket_invalid_reason = "absolute_monotonic_bracket_order_invalid"
    elif region_result["scan_begin_absolute_monotonic_ns"] - pre_end > MAX_PRE_SAMPLE_AGE_NS:
        bracket_invalid_reason = "pre_phase_sample_stale"
    while bracket_invalid_reason is None and time.monotonic() < bracket_deadline:
        new_rows = tail.refresh()
        bracket_end_row, bracket_invalid_reason = post_bracket_candidate(
            new_rows, args.role, args.pid, args.os_start_abstime, exe,
            args.phase, fingerprint, target_info, scan_end,
        )
        if bracket_end_row is not None:
            break
        if bracket_invalid_reason is not None:
            break
        if not new_rows:
            time.sleep(0.05)

    scan_begin = region_result["scan_begin_absolute_monotonic_ns"]
    bracket_ok = (
        pre_begin <= pre_end <= scan_begin <= scan_end
        and scan_begin - pre_end <= MAX_PRE_SAMPLE_AGE_NS
        and bracket_end_row is not None
        and rusage_post is not None
    )
    post_begin = post_end = None
    if bracket_end_row is not None:
        post_begin, post_end = absolute_interval(bracket_end_row)
        order_error = bracket_order_error(pre_begin, pre_end, scan_begin, scan_end,
                                          post_begin, post_end)
        bracket_invalid_reason = bracket_invalid_reason or order_error
        bracket_ok = bracket_ok and order_error is None
    else:
        order_error = None
    footprint = target_info["phys_footprint_bytes"]
    categories = region_result["page_counter_bytes_at_system_page_size"]
    region_result["phase_validation"] = "same_phase_bracket_confirmed" if bracket_ok else "unvalidated_raw"
    if bracket_ok:
        region_result["footprint_comparison_not_reconciled"] = {
            "observer_phase_sample_footprint_bytes": footprint,
            "proc_pid_rusage_before_bytes": rusage_pre["usage"]["phys_footprint_bytes"],
            "proc_pid_rusage_after_bytes": rusage_post["usage"]["phys_footprint_bytes"] if rusage_post else None,
            "difference_from_region_resident_pages_bytes": footprint - categories["resident_pages"] if categories else None,
            "difference_from_region_private_resident_pages_bytes": footprint - categories["private_resident_pages"] if categories else None,
            "difference_from_region_shared_resident_pages_bytes": footprint - categories["shared_resident_pages"] if categories else None,
            "interpretation": "diagnostic arithmetic against only the observed region prefix; null means no valid region page sample; these counters are not a disjoint or additive reconstruction of phys_footprint",
        }
    else:
        region_result["footprint_comparison_not_reconciled"] = None
    own_usage_after = observe.usage(os.getpid())
    self_rusage_after = resource.getrusage(resource.RUSAGE_SELF)
    self_tracemalloc_after = tracemalloc.get_traced_memory() if tracemalloc.is_tracing() else (None, None)
    return {
        "schema": "mycity-proc-pidregioninfo-bounded-observer-candidate-v1",
        "status": "incomplete",
        "reason": post_error or bracket_invalid_reason or ("phase_bracket_not_observed" if not bracket_ok else region_result["reason"]),
        "diagnostic_only": True,
        "source_sha256": args.source_sha256,
        "phase_observer_sha256": args.phase_observer_sha256,
        "clock_handshake_helper_sha256": CLOCK_HANDSHAKE_SHA256,
        "clock_handshake": clock_handshake_receipt,
        "exe_sha256": args.exe_sha256,
        "observer_sha256": sha256(Path(__file__).resolve()),
        "support_sha256": SUPPORT_SHA256,
        "sdk": sdk,
        "target": {"role": args.role, "pid": args.pid, "os_start_abstime": args.os_start_abstime,
                   "phase": args.phase, "event_fingerprint": fingerprint,
                   "application_instance_unix_ns": target_info.get("application_instance_unix_ns")},
        "phase_bracket": {
            "clock": monotonic_clock_record(),
            "pre_absolute_begin_ns": pre_begin,
            "pre_absolute_end_ns": pre_end,
            "scan_absolute_begin_ns": scan_begin,
            "scan_absolute_end_ns": scan_end,
            "post_absolute_begin_ns": post_begin,
            "post_absolute_end_ns": post_end,
            "pre_sample_max_age_ns": MAX_PRE_SAMPLE_AGE_NS,
            "post_wait_max_seconds": MAX_POST_BRACKET_WAIT_SECONDS,
            "strict_total_order": post_begin is not None and post_end is not None and order_error is None,
            "same_phase_and_event_fingerprint_after_scan": bracket_ok,
        },
        "target_identity_before": rusage_pre,
        "target_identity_after": rusage_post,
        "region_sample": region_result if bracket_ok else None,
        "unvalidated_raw_region_observation": region_result if not bracket_ok else None,
        "sampler_resource_cost_separate": {
            "self_proc_pid_rusage_before": self_usage_before,
            "self_proc_pid_rusage_after": own_usage_after,
            "self_maxrss_bytes_before": self_rusage_before.ru_maxrss,
            "self_maxrss_bytes_after": self_rusage_after.ru_maxrss,
            "self_tracemalloc_before_region_scan_bytes": self_tracemalloc_before,
            "self_tracemalloc_after_wait_before_json_encode_bytes": self_tracemalloc_after,
            "json_decode_and_encode_temporaries_are_observer_cost": True,
            "output_serialization_heap_is_not_in_tracemalloc_after_sample": True,
            "not_part_of_target_footprint_or_subtracted_from_it": True,
        },
        "claim_boundary": {
            "region_api_authority": "SDK-derived proc_pidinfo PROC_PIDREGIONINFO metadata only",
            "memory_contents_read": False,
            "thread_count_used_as_stack_residency": False,
            "region_pages_are_unique_physical_bytes": False,
            "region_page_totals_added_to_or_subtracted_from_phys_footprint": False,
            "full_address_space_enumeration": False,
            "one_second_limit_is_hard_preemptive": False,
            "128kib_output_cap_limits_python_heap": False,
            "memory_or_performance_acceptance": False,
        },
    }


def main() -> int:
    args = parse_args()
    tracemalloc.start(8)
    try:
        report = run(args)
    except Exception as exc:
        report = {
            "schema": "mycity-proc-pidregioninfo-bounded-observer-candidate-v1",
            "status": "incomplete",
            "reason": type(exc).__name__ + ":" + str(exc)[:256],
            "diagnostic_only": True,
            "memory_or_performance_acceptance": False,
        }
    if report.get("schema") == "mycity-clock-handshake-only-v1":
        sys.stdout.write(json.dumps(report, sort_keys=True, separators=(",", ":")) + "\n")
        return 0
    raw = encode_report(report)
    args.output.parent.resolve(strict=True)
    with args.output.open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    return 2


def encode_report(report: dict) -> bytes:
    raw = (json.dumps(report, sort_keys=True, separators=(",", ":")) + "\n").encode()
    if len(raw) > MAX_OUTPUT_BYTES:
        raw = json.dumps({"schema": "mycity-proc-pidregioninfo-bounded-observer-candidate-v1",
                          "status": "incomplete", "reason": "output_byte_cap",
                          "diagnostic_only": True, "memory_or_performance_acceptance": False},
                         sort_keys=True, separators=(",", ":")).encode() + b"\n"
    return raw


if __name__ == "__main__":
    raise SystemExit(main())
