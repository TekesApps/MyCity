# Observer entry and cross-process clock: limited diagnostic — 2026-10-24

Issue #112; #113 endurance and original M0 #20 remain open. This work changes Python
diagnostic scripts only. No Cargo/Rust build, Rust executable invocation, Model launch,
target native query, long pressure test or frozen-load/acceptance change occurred.

## Failure preserved and repair

The 495 failure remains a real failed native-diagnostic entry attempt: phase observer
`importlib.util` was unavailable and the socket peer closed, before native region capture.
Both observers now explicitly import that submodule. Their `--clock-handshake-only` mode
exits before importing native support, reading target events or querying a target. Argument,
path and executable hash checks still run; region starts its own tracemalloc.

The original advisor found a second issue in the private v1 helper: its final receipt could
replace previously exchanged timestamps with zeros while retaining locally ordered triples.
The coordinator reproduced this using a controlled Python peer; the accepted invalid v1
receipt and complete original scripts are retained, not relabelled as a successful handshake.

Protocol v2 now binds the first five receipt timestamps to the actual exchange and checks:

`parent_before <= child_sample <= parent_after <= child_before <= parent_sample <= child_after <= parent_receive`.

The final ACK carries parent receive time; the child checks its order and receipt digest.
PID/component, nonce, message stage, identity stability, explicit clock identity, three-second
deadline and line cap remain. Both observer helper pins were updated together to
`9c092e487ea1348901d70e6417f67096596f6f36c1f6405ea3eeb62a9d2f88ac`.
Old v1 receipts are historical and do not establish v2 acceptance.

## Actual bounded validation

Evidence root: `/Volumes/HP P900/dev/MyCity/work/m0-observer-entry-clock-20261024/`.
`fixed-observer-v2.zip` and `fixed-inputs.json` preserve seven exact script/document inputs;
commands, logs, receipts and negative outputs are complete originals. All inputs were
unchanged during execution. Post-run documentation is distinct from the frozen archive.

- `01-clock-protocol`: 4 tests passed, including 14 malformed-parent-side branches, actual
  helper subprocess receipt equality, wrong OS-parent PID and altered final ACK rejection.
  Cases cover wrong clock name/ID/unit, component/PID, nonce/stage/echo, substituted receipt,
  reversed cross-round order, future child time, EOF, excessive line and no-reply timeout.
- `02-synthetic-boundaries`: original 14 tests passed; these use fake native/region data and
  some real controlled Python clock exchanges, not a native target capture.
- Both actual observer main entries launched with Python 3.9.6 `-B -I -S`, exit 0. The parent
  and child receipts match exactly, including digest, actual Popen PID and interpreter path.
  Both sides use `time.clock_gettime_ns(CLOCK_MONOTONIC)`, ID 6, nanoseconds, with the complete
  seven-timestamp order verified. Legacy `time.monotonic_ns()` was not used across processes.
- Missing handshake FD and altered helper bytes at each actual observer entry were correctly
  rejected (3 cases). Region failure produces only an `incomplete` diagnostic.

Support directory and phase-event path deliberately do not exist; the target run root and
positive observer output files were not created. A retained v157/451 executable/source pair
was only hashed for parser metadata checks, never started or presented as current Rust build.
PID/start arguments are explicit early-exit metadata sentinels, not observed target identity.
Acceptance requires both process exit/receipt results, not merely parent return before the
child consumes its final ACK.

The original advisor read actual evidence and accepted this limited entry/clock result with
no remaining blocker. It did not itself run compilation, tests or native sampling.

## Unchanged gates and remaining dependencies

This proves Python observer entry and cross-process clock handshake only. It does not prove
495 native sampling restored, real target PID/start/phase validation, region ABI/permissions,
six-point phase bracketing, four lifecycle phases, memory reclamation or normal-load speed.
Model/native sampling, long pressure, formal M0 and true16GB remain not run here. The original
normal/common8MiB/three-round/four-speed/8h/16GB standards are unchanged; old failure remains.

All unrelated WIP, private candidates, fixed executables, sources and recovery originals are
retained. Evidence budget16MiB; no worktree/target/history deletion or publish/PR/tag occurred.
Next: separately schedule a bounded live-target identity/phase/native diagnostic using the
verified handshake before any original-load retry; do not automatically start it from these
results or manufacture an acceptance result from metadata-only sentinel arguments.
