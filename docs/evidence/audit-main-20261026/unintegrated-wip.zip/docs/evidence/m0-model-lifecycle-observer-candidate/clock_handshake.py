#!/usr/bin/env python3
"""Bounded CLOCK_MONOTONIC handshake for two local Python processes."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import platform
import secrets
import socket
import sys
import time

PROTOCOL = "mycity-clock-handshake-v2"
MAX_LINE_BYTES = 4096
MAX_HANDSHAKE_SECONDS = 3.0
CLOCK_FUNCTION = "time.clock_gettime_ns"
CLOCK_NAME = "CLOCK_MONOTONIC"
CLOCK_UNIT = "ns"


class HandshakeError(RuntimeError):
    pass


def clock_id() -> int:
    value = getattr(time, "CLOCK_MONOTONIC", None)
    if type(value) is not int:
        raise HandshakeError("clock_monotonic_id_unavailable")
    return value


def clock_ns() -> int:
    value = time.clock_gettime_ns(clock_id())
    if type(value) is not int or value < 0:
        raise HandshakeError("clock_monotonic_read_invalid")
    return value


def identity(component: str) -> dict:
    if not isinstance(component, str) or not component or len(component) > 64:
        raise HandshakeError("component_invalid")
    return {
        "component": component,
        "pid": os.getpid(),
        "interpreter_path": str(Path(sys.executable).resolve()),
        "python_version": platform.python_version(),
        "clock_function": CLOCK_FUNCTION,
        "clock_name": CLOCK_NAME,
        "clock_id": clock_id(),
        "clock_unit": CLOCK_UNIT,
        "clock_implementation": time.get_clock_info("monotonic").implementation,
    }


def _validate_identity(value: object) -> dict:
    if not isinstance(value, dict):
        raise HandshakeError("identity_missing")
    required_strings = ("component", "interpreter_path", "python_version", "clock_function",
                        "clock_name", "clock_unit", "clock_implementation")
    if any(not isinstance(value.get(key), str) or not value[key] for key in required_strings):
        raise HandshakeError("identity_field_missing")
    if type(value.get("pid")) is not int or value["pid"] <= 0:
        raise HandshakeError("identity_pid_invalid")
    if (value.get("clock_function") != CLOCK_FUNCTION or value.get("clock_name") != CLOCK_NAME
            or value.get("clock_id") != clock_id() or value.get("clock_unit") != CLOCK_UNIT):
        raise HandshakeError("clock_identity_mismatch")
    if type(value.get("clock_id")) is not int:
        raise HandshakeError("clock_id_invalid")
    return value


def _encode(value: dict) -> bytes:
    raw = (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")
    if len(raw) > MAX_LINE_BYTES:
        raise HandshakeError("handshake_line_too_large")
    return raw


def _send(sock: socket.socket, value: dict, deadline: float) -> None:
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise HandshakeError("handshake_timeout")
    sock.settimeout(remaining)
    sock.sendall(_encode(value))


def _receive(sock: socket.socket, deadline: float) -> dict:
    data = bytearray()
    while True:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise HandshakeError("handshake_timeout")
        sock.settimeout(remaining)
        chunk = sock.recv(min(512, MAX_LINE_BYTES + 1 - len(data)))
        if not chunk:
            raise HandshakeError("handshake_peer_closed")
        data.extend(chunk)
        if len(data) > MAX_LINE_BYTES:
            raise HandshakeError("handshake_line_too_large")
        newline = data.find(b"\n")
        if newline >= 0:
            if newline != len(data) - 1:
                raise HandshakeError("handshake_multiple_or_trailing_lines")
            try:
                value = json.loads(data[:-1])
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise HandshakeError("handshake_json_invalid") from exc
            if not isinstance(value, dict):
                raise HandshakeError("handshake_message_not_object")
            return value


def _require(value: dict, kind: str, nonce: str) -> None:
    if value.get("protocol") != PROTOCOL or value.get("kind") != kind or value.get("nonce") != nonce:
        raise HandshakeError("handshake_message_mismatch:" + kind)


def _check_ns(value: object, field: str) -> int:
    if type(value) is not int or value < 0:
        raise HandshakeError("timestamp_invalid:" + field)
    return value


def _canonical_digest(value: dict) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def parent_handshake(sock: socket.socket, expected_child_pid: int, expected_child_component: str,
                     component: str = "root_runner") -> dict:
    """Run the parent side on the socket retained after Popen(pass_fds=...)."""
    if type(expected_child_pid) is not int or expected_child_pid <= 0:
        raise HandshakeError("expected_child_pid_invalid")
    if expected_child_component not in {"phase_observer", "region_observer"}:
        raise HandshakeError("expected_child_component_invalid")
    deadline = time.monotonic() + MAX_HANDSHAKE_SECONDS
    parent = identity(component)
    nonce = secrets.token_hex(16)
    parent_before = clock_ns()
    _send(sock, {"protocol": PROTOCOL, "kind": "parent_challenge", "nonce": nonce,
                 "parent": parent, "parent_before_ns": parent_before}, deadline)
    response = _receive(sock, deadline)
    _require(response, "child_response", nonce)
    child = _validate_identity(response.get("child"))
    if child["pid"] != expected_child_pid:
        raise HandshakeError("child_pid_does_not_match_popen_pid")
    if child["component"] != expected_child_component:
        raise HandshakeError("child_component_mismatch")
    initial_child = child
    child_sample = _check_ns(response.get("child_sample_ns"), "child_sample")
    if response.get("parent_before_ns") != parent_before:
        raise HandshakeError("challenge_timestamp_echo_mismatch")
    parent_after = clock_ns()
    if not parent_before <= child_sample <= parent_after:
        raise HandshakeError("parent_challenge_order_invalid")
    _send(sock, {"protocol": PROTOCOL, "kind": "parent_ack", "nonce": nonce,
                 "parent": parent, "parent_before_ns": parent_before,
                 "child_sample_ns": child_sample, "parent_after_ns": parent_after,
                 "ordered": True}, deadline)

    challenge = _receive(sock, deadline)
    _require(challenge, "child_challenge", nonce)
    child = _validate_identity(challenge.get("child"))
    if child != initial_child:
        raise HandshakeError("child_identity_changed_during_handshake")
    child_before = _check_ns(challenge.get("child_before_ns"), "child_before")
    parent_sample = clock_ns()
    _send(sock, {"protocol": PROTOCOL, "kind": "parent_response", "nonce": nonce,
                 "parent": parent, "child_before_ns": child_before,
                 "parent_sample_ns": parent_sample}, deadline)
    receipt_message = _receive(sock, deadline)
    parent_receive = clock_ns()
    _require(receipt_message, "receipt", nonce)
    receipt = receipt_message.get("receipt")
    if not isinstance(receipt, dict):
        raise HandshakeError("receipt_missing")
    receipt_child = _validate_identity(receipt.get("child"))
    receipt_parent = _validate_identity(receipt.get("parent"))
    if receipt_child != child or receipt_parent != parent:
        raise HandshakeError("receipt_identity_changed")
    times = {key: _check_ns(receipt.get(key), key) for key in
             ("parent_before_ns", "child_sample_ns", "parent_after_ns",
              "child_before_ns", "parent_sample_ns", "child_after_ns")}
    exchanged = {"parent_before_ns": parent_before, "child_sample_ns": child_sample,
                 "parent_after_ns": parent_after, "child_before_ns": child_before,
                 "parent_sample_ns": parent_sample}
    for key, observed in exchanged.items():
        if times[key] != observed:
            raise HandshakeError("receipt_timestamp_mismatch:" + key)
    if not times["parent_before_ns"] <= times["child_sample_ns"] <= times["parent_after_ns"]:
        raise HandshakeError("parent_challenge_order_invalid")
    if not times["child_before_ns"] <= times["parent_sample_ns"] <= times["child_after_ns"]:
        raise HandshakeError("child_challenge_order_invalid")
    if not (times["parent_before_ns"] <= times["child_sample_ns"] <= times["parent_after_ns"]
            <= times["child_before_ns"] <= times["parent_sample_ns"]
            <= times["child_after_ns"] <= parent_receive):
        raise HandshakeError("handshake_total_order_invalid")
    if receipt.get("ordered") is not True:
        raise HandshakeError("receipt_not_ordered")
    digest = _canonical_digest(receipt)
    _send(sock, {"protocol": PROTOCOL, "kind": "ack", "nonce": nonce,
                 "accepted": True, "receipt_sha256": digest,
                 "parent_receive_ns": parent_receive}, deadline)
    return {"protocol": PROTOCOL, "accepted": True, "nonce": nonce,
            "parent": parent, "child": child, **times, "ordered": True,
            "parent_receive_ns": parent_receive, "receipt_sha256": digest}


def child_handshake(fd: int, component: str) -> dict:
    """Run the child side using an inherited socketpair descriptor; closes it."""
    if type(fd) is not int or fd < 0:
        raise HandshakeError("inherited_fd_invalid")
    sock = socket.socket(fileno=fd)
    deadline = time.monotonic() + MAX_HANDSHAKE_SECONDS
    try:
        child = identity(component)
        challenge = _receive(sock, deadline)
        nonce = challenge.get("nonce")
        if (challenge.get("protocol") != PROTOCOL or challenge.get("kind") != "parent_challenge"
                or not isinstance(nonce, str) or not 16 <= len(nonce) <= 64):
            raise HandshakeError("parent_challenge_invalid")
        parent = _validate_identity(challenge.get("parent"))
        if parent["pid"] != os.getppid():
            raise HandshakeError("parent_pid_does_not_match_os_parent")
        parent_before = _check_ns(challenge.get("parent_before_ns"), "parent_before")
        child_sample = clock_ns()
        _send(sock, {"protocol": PROTOCOL, "kind": "child_response", "nonce": nonce,
                     "child": child, "parent_before_ns": parent_before,
                     "child_sample_ns": child_sample}, deadline)
        ack = _receive(sock, deadline)
        _require(ack, "parent_ack", nonce)
        ack_parent = _validate_identity(ack.get("parent"))
        parent_after = _check_ns(ack.get("parent_after_ns"), "parent_after")
        if ack_parent != parent or ack.get("parent_before_ns") != parent_before or ack.get("child_sample_ns") != child_sample:
            raise HandshakeError("parent_ack_identity_or_echo_mismatch")
        if not parent_before <= child_sample <= parent_after or ack.get("ordered") is not True:
            raise HandshakeError("parent_challenge_order_invalid")

        child_before = clock_ns()
        _send(sock, {"protocol": PROTOCOL, "kind": "child_challenge", "nonce": nonce,
                     "child": child, "child_before_ns": child_before}, deadline)
        response = _receive(sock, deadline)
        _require(response, "parent_response", nonce)
        response_parent = _validate_identity(response.get("parent"))
        parent_sample = _check_ns(response.get("parent_sample_ns"), "parent_sample")
        if response_parent != parent or response.get("child_before_ns") != child_before:
            raise HandshakeError("parent_response_identity_or_echo_mismatch")
        child_after = clock_ns()
        if not parent_after <= child_before <= parent_sample <= child_after:
            raise HandshakeError("child_challenge_order_invalid")
        receipt = {"parent": parent, "child": child,
                   "parent_before_ns": parent_before, "child_sample_ns": child_sample,
                   "parent_after_ns": parent_after, "child_before_ns": child_before,
                   "parent_sample_ns": parent_sample, "child_after_ns": child_after,
                   "ordered": True}
        digest = _canonical_digest(receipt)
        _send(sock, {"protocol": PROTOCOL, "kind": "receipt", "nonce": nonce,
                     "receipt": receipt}, deadline)
        final_ack = _receive(sock, deadline)
        _require(final_ack, "ack", nonce)
        if final_ack.get("accepted") is not True or final_ack.get("receipt_sha256") != digest:
            raise HandshakeError("parent_final_ack_rejected")
        parent_receive = _check_ns(final_ack.get("parent_receive_ns"), "parent_receive")
        if not child_after <= parent_receive <= clock_ns():
            raise HandshakeError("parent_final_ack_order_invalid")
        return {"protocol": PROTOCOL, "accepted": True, "nonce": nonce,
                **receipt, "parent_receive_ns": parent_receive, "receipt_sha256": digest}
    finally:
        sock.close()
