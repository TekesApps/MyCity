#!/usr/bin/env python3
"""Synthetic-only boundary checks; these never call macOS proc_pidinfo."""
from __future__ import annotations

import ctypes
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import unittest

SOURCE = Path(__file__).with_name("observe_vm_regions.py")
SPEC = importlib.util.spec_from_file_location("observe_vm_regions_candidate", SOURCE)
assert SPEC is not None and SPEC.loader is not None
observer = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(observer)
HANDSHAKE_SOURCE = SOURCE.with_name("clock_handshake.py")
HANDSHAKE_SPEC = importlib.util.spec_from_file_location("mycity_clock_handshake_test", HANDSHAKE_SOURCE)
assert HANDSHAKE_SPEC is not None and HANDSHAKE_SPEC.loader is not None
handshake = importlib.util.module_from_spec(HANDSHAKE_SPEC)
HANDSHAKE_SPEC.loader.exec_module(handshake)


class SyntheticRegion(ctypes.Structure):
    _fields_ = [
        ("pri_protection", ctypes.c_uint32), ("pri_max_protection", ctypes.c_uint32),
        ("pri_inheritance", ctypes.c_uint32), ("pri_flags", ctypes.c_uint32),
        ("pri_offset", ctypes.c_uint64), ("pri_behavior", ctypes.c_uint32),
        ("pri_user_wired_count", ctypes.c_uint32), ("pri_user_tag", ctypes.c_uint32),
        ("pri_pages_resident", ctypes.c_uint32),
        ("pri_pages_shared_now_private", ctypes.c_uint32), ("pri_pages_swapped_out", ctypes.c_uint32),
        ("pri_pages_dirtied", ctypes.c_uint32), ("pri_ref_count", ctypes.c_uint32),
        ("pri_shadow_depth", ctypes.c_uint32), ("pri_share_mode", ctypes.c_uint32),
        ("pri_private_pages_resident", ctypes.c_uint32),
        ("pri_shared_pages_resident", ctypes.c_uint32), ("pri_obj_id", ctypes.c_uint32),
        ("pri_depth", ctypes.c_uint32), ("pri_address", ctypes.c_uint64),
        ("pri_size", ctypes.c_uint64),
    ]


class FakeProcInfo:
    def __init__(self, regions):
        self.regions = regions
        self.calls = 0

    def proc_pidinfo(self, _pid, _flavor, _address, out, out_size):
        if self.calls >= len(self.regions):
            return 0
        address, size = self.regions[self.calls]
        self.calls += 1
        region = ctypes.cast(out, ctypes.POINTER(SyntheticRegion)).contents
        region.pri_address = address
        region.pri_size = size
        region.pri_user_tag = 1
        region.pri_pages_resident = 1
        region.pri_private_pages_resident = 1
        return ctypes.sizeof(SyntheticRegion)


class FakeNative:
    def __init__(self, regions):
        self.lib = FakeProcInfo(regions)

    @staticmethod
    def constant(_header, _name):
        return 7


def phase_row(*, phase="filled", fingerprint=None, capture_begin=117_000_000,
              absolute_begin=900_000_000_000, absolute_end=900_000_000_100,
              pid=42, start=99, name="headless"):
    fingerprint = fingerprint or ["filled", 3, "event", 4, 5]
    return {
        "type": "phase_sample", "phase": phase,
        "event_fingerprint": fingerprint,
        "native_capture_complete": True,
        "capture_begin_monotonic_ns": capture_begin,
        "capture_end_monotonic_ns": capture_begin + 1,
        "absolute_monotonic_ns": {
            "function": "time.clock_gettime_ns",
            "clock_name": "CLOCK_MONOTONIC",
            "clock_id": int(observer.time.CLOCK_MONOTONIC),
            "unit": "ns",
            "begin": absolute_begin, "end": absolute_end,
        },
        "event": {"phase": phase, "generation": fingerprint[1]},
        "pool": {"pid": pid, "os_process_start_abstime": start,
                 "executable_path": "/tmp/headless", "process_name": name,
                 "parent_pid": 7, "phys_footprint_bytes": 1234},
    }


class SyntheticBoundaries(unittest.TestCase):
    def test_both_observers_pin_shared_handshake_helper_sha(self):
        digest = hashlib.sha256(HANDSHAKE_SOURCE.read_bytes()).hexdigest()
        for filename in ("observe_model_lifecycle.py", "observe_vm_regions.py"):
            source = SOURCE.with_name(filename).read_text()
            self.assertIn(f'CLOCK_HANDSHAKE_SHA256 = "{digest}"', source)

    def test_producer_declares_absolute_clock_without_removing_legacy_fields(self):
        producer = SOURCE.with_name("observe_model_lifecycle.py").read_text()
        self.assertIn('"monotonic_clock": monotonic_clock_record()', producer)
        self.assertIn('"absolute_monotonic_ns": {', producer)
        self.assertIn('absolute_capture_begin_ns = shared_absolute_clock_ns()', producer)
        self.assertIn('def shared_absolute_clock_ns() -> int:', producer)
        self.assertIn('"capture_begin_monotonic_ns": captured_ns', producer)
        self.assertIn('"capture_end_monotonic_ns": legacy_capture_end_ns', producer)

    def test_shared_clock_is_increasing_across_two_fresh_python_processes(self):
        program = (
            "import json,time; "
            "print(json.dumps({'clock_id': int(time.CLOCK_MONOTONIC), "
            "'clock_gettime_ns': time.clock_gettime_ns(time.CLOCK_MONOTONIC), "
            "'monotonic_ns': time.monotonic_ns()}))"
        )
        first = json.loads(subprocess.check_output([sys.executable, "-c", program], text=True))
        second = json.loads(subprocess.check_output([sys.executable, "-c", program], text=True))
        self.assertEqual(first["clock_id"], second["clock_id"])
        self.assertEqual(first["clock_id"], int(observer.time.CLOCK_MONOTONIC))
        self.assertGreater(second["clock_gettime_ns"], first["clock_gettime_ns"])
        delta = second["clock_gettime_ns"] - first["clock_gettime_ns"]
        print("FRESH_SUBPROCESS_SHARED_CLOCK:", first["clock_gettime_ns"],
              second["clock_gettime_ns"], "delta_ns=", delta,
              "process_monotonic_ns=", first["monotonic_ns"], second["monotonic_ns"])

    def test_socketpair_clock_handshake_binds_actual_child_pid(self):
        script = (
            "import importlib.util,json,sys; "
            "p=sys.argv[1]; s=importlib.util.spec_from_file_location('clock_handshake_child',p); "
            "m=importlib.util.module_from_spec(s); s.loader.exec_module(m); "
            "print(json.dumps(m.child_handshake(int(sys.argv[2]),sys.argv[3]),sort_keys=True))"
        )
        for component in ("phase_observer", "region_observer"):
            with self.subTest(component=component):
                parent_sock, child_sock = socket.socketpair()
                child_sock.set_inheritable(True)
                process = subprocess.Popen(
                    [sys.executable, "-c", script, str(HANDSHAKE_SOURCE),
                     str(child_sock.fileno()), component],
                    pass_fds=(child_sock.fileno(),), stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE, text=True,
                )
                child_sock.close()
                try:
                    parent_receipt = handshake.parent_handshake(
                        parent_sock, expected_child_pid=process.pid,
                        expected_child_component=component,
                        component="synthetic_test_parent")
                    stdout, stderr = process.communicate(timeout=5)
                finally:
                    parent_sock.close()
                self.assertEqual(process.returncode, 0, stderr)
                child_receipt = json.loads(stdout)
                self.assertTrue(parent_receipt["accepted"])
                self.assertTrue(child_receipt["accepted"])
                self.assertEqual(parent_receipt["receipt_sha256"], child_receipt["receipt_sha256"])
                self.assertEqual(child_receipt["child"]["pid"], process.pid)
                self.assertEqual(child_receipt["child"]["component"], component)
                self.assertEqual(child_receipt["parent"]["pid"], os.getpid())
                self.assertLessEqual(child_receipt["parent_before_ns"],
                                     child_receipt["child_sample_ns"])
                self.assertLessEqual(child_receipt["child_sample_ns"],
                                     child_receipt["parent_after_ns"])
                self.assertLessEqual(child_receipt["child_before_ns"],
                                     child_receipt["parent_sample_ns"])
                self.assertLessEqual(child_receipt["parent_sample_ns"],
                                     child_receipt["child_after_ns"])
                print("SOCKETPAIR_HANDSHAKE_ACCEPTED:", component,
                      "parent_pid=", child_receipt["parent"]["pid"],
                      "child_pid=", child_receipt["child"]["pid"],
                      "clock_id=", child_receipt["child"]["clock_id"])

    def test_nonprogressing_region_is_incomplete(self):
        native = FakeNative([(0x1000, 0x1000), (0x1000, 0x1000)])
        result = observer.region_scan(native, SyntheticRegion, {}, 42, 4096)
        self.assertEqual(result["status"], "incomplete")
        self.assertEqual(result["reason"], "region_address_or_size_nonprogress")
        self.assertEqual(result["regions_returned"], 1)

    def test_short_region_record_is_not_end_of_map(self):
        native = FakeNative([(0x1000, 0x1000)])
        native.lib.proc_pidinfo = lambda *_args: ctypes.sizeof(SyntheticRegion) - 1
        result = observer.region_scan(native, SyntheticRegion, {}, 42, 4096)
        self.assertEqual(result["reason"], "region_query_short_or_unknown_abi")
        self.assertEqual(result["regions_returned"], 0)

    def test_phase_identity_changes_invalidate_post_bracket(self):
        phase = "filled"
        fingerprint = [phase, 3, "event", 4, 5]
        exe = Path("/tmp/headless")
        pre_row = phase_row(fingerprint=fingerprint, absolute_begin=899_999_999_700,
                            absolute_end=899_999_999_800)
        base = phase_row(fingerprint=fingerprint, absolute_begin=900_000_000_100,
                         absolute_end=900_000_000_200)
        pre_target = pre_row["pool"]
        valid, reason = observer.post_bracket_candidate(
            [base], "pool", 42, 99, exe, phase, fingerprint, pre_target, 900_000_000_000)
        self.assertIsNotNone(valid)
        self.assertIsNone(reason)
        changed_phase, reason = observer.post_bracket_candidate(
            [phase_row(phase="returned", fingerprint=fingerprint)],
            "pool", 42, 99, exe, phase, fingerprint, pre_target, 900_000_000_000)
        self.assertIsNone(changed_phase)
        self.assertEqual(reason, "phase_changed_before_post_bracket")
        changed_event, reason = observer.post_bracket_candidate(
            [phase_row(fingerprint=[phase, 4, "event", 4, 5])],
            "pool", 42, 99, exe, phase, fingerprint, pre_target, 900_000_000_000)
        self.assertIsNone(changed_event)
        self.assertEqual(reason, "phase_event_changed_before_post_bracket")
        terminal, reason = observer.post_bracket_candidate(
            [base, {"type": "observer_terminal"}],
            "pool", 42, 99, exe, phase, fingerprint, pre_target, 900_000_000_250)
        self.assertIsNone(terminal)
        self.assertEqual(reason, "observer_terminal_before_post_bracket")
        changed_name = phase_row(fingerprint=fingerprint, name="renamed",
                                 absolute_begin=900_000_000_300, absolute_end=900_000_000_400)
        _, reason = observer.post_bracket_candidate(
            [changed_name], "pool", 42, 99, exe, phase, fingerprint,
            pre_target, 900_000_000_250)
        self.assertEqual(reason, "target_identity_changed_before_post_bracket")

    def test_late_attach_uses_latest_fresh_same_identity_sample(self):
        phase = "filled"
        fingerprint = [phase, 3, "event", 4, 5]
        old = phase_row(fingerprint=fingerprint, absolute_begin=10_000,
                        absolute_end=10_100)
        latest = phase_row(fingerprint=fingerprint, absolute_begin=20_000,
                           absolute_end=20_100)
        selected, seen = observer.update_phase_candidate(
            [old, latest], None, False, "pool", 42, 99,
            Path("/tmp/headless"), phase)
        self.assertTrue(seen)
        self.assertIs(selected, latest)
        self.assertFalse(observer.candidate_is_fresh(old, 20_000 + observer.MAX_PRE_SAMPLE_AGE_NS + 1))
        self.assertTrue(observer.candidate_is_fresh(latest, 20_000 + 200))

    def test_late_attach_cannot_skip_phase_terminal_or_identity_conflict(self):
        phase = "filled"
        fingerprint = [phase, 3, "event", 4, 5]
        good = phase_row(fingerprint=fingerprint, absolute_begin=10_000,
                         absolute_end=10_100)
        exe = Path("/tmp/headless")
        conflicts = [
            ([good, phase_row(phase="returned", fingerprint=fingerprint)],
             "phase_changed_before_region_scan"),
            ([good, {"type": "observer_terminal"}],
             "observer_terminated_before_target_phase"),
            ([good, phase_row(fingerprint=[phase, 4, "event", 4, 5])],
             "phase_event_changed_before_region_scan"),
            ([good, phase_row(name="replaced")],
             "target_identity_changed_before_region_scan"),
        ]
        for rows, expected_reason in conflicts:
            with self.subTest(reason=expected_reason):
                with self.assertRaisesRegex(observer.Incomplete, expected_reason):
                    observer.update_phase_candidate(rows, None, False, "pool", 42, 99,
                                                    exe, phase)

    def test_legacy_relative_clock_cannot_bracket_absolute_scan(self):
        row = phase_row(capture_begin=117_000_000)
        self.assertLess(row["capture_end_monotonic_ns"], 1_000_000_000_000)
        self.assertEqual(observer.absolute_interval(row), (900_000_000_000, 900_000_000_100))
        del row["absolute_monotonic_ns"]
        with self.assertRaisesRegex(observer.Incomplete, "absolute_monotonic_clock_or_unit_missing"):
            observer.absolute_interval(row)

    def test_absolute_interval_and_complete_bracket_order_fail_closed(self):
        row = phase_row(absolute_begin=10**12, absolute_end=10**12 - 1)
        with self.assertRaisesRegex(observer.Incomplete, "absolute_monotonic_interval_reversed"):
            observer.absolute_interval(row)
        with self.assertRaisesRegex(observer.Incomplete, "absolute_monotonic_timestamp_missing_or_invalid"):
            observer.absolute_interval(phase_row(absolute_begin=True))
        self.assertIsNone(observer.bracket_order_error(10, 20, 20, 30, 30, 40))
        self.assertEqual(observer.bracket_order_error(10, 20, 19, 30, 30, 40),
                         "absolute_monotonic_bracket_order_invalid")
        self.assertEqual(observer.bracket_order_error(10, 20, 1_500_000_021,
                                                      1_500_000_030, 1_500_000_040,
                                                      1_500_000_050),
                         "pre_phase_sample_stale")

    def test_target_identity_change_fails_closed(self):
        exe = Path("/tmp/headless")
        with self.assertRaises(observer.Incomplete):
            observer.expected_target(phase_row(pid=43), "pool", 42, 99, exe)
        with self.assertRaises(observer.Incomplete):
            observer.expected_target(phase_row(start=100), "pool", 42, 99, exe)
        row = phase_row(name="renamed")
        self.assertEqual(observer.expected_target(row, "pool", 42, 99, exe)["process_name"], "renamed")

    def test_process_name_relation_and_executable_path_are_independent(self):
        class Observe:
            def __init__(self):
                self.relation = None

            def bound_usage(self, _pid, relation, _start):
                self.relation = relation
                return ({"phys_footprint_bytes": 1234}, None, {"ok": True})

            @staticmethod
            def usage(_pid):
                return {"phys_footprint_bytes": 1}

        class Native:
            @staticmethod
            def process_path(_pid):
                return "/tmp/headless"

        observe = Observe()
        observer.check_identity(Native(), observe, 42, 99, 7, "captured-short-name", Path("/tmp/headless"))
        self.assertEqual(observe.relation, (7, None, None, "captured-short-name"))
        with self.assertRaises(observer.Incomplete):
            observer.check_identity(Native(), observe, 42, 99, 7, "captured-short-name", Path("/tmp/other"))

    def test_output_cap_is_byte_only_and_produces_bounded_failclosed_record(self):
        normal = observer.encode_report({"status": "incomplete", "data": "ok"})
        self.assertLessEqual(len(normal), observer.MAX_OUTPUT_BYTES)
        oversized = observer.encode_report({"status": "incomplete", "data": "x" * observer.MAX_OUTPUT_BYTES})
        self.assertLessEqual(len(oversized), observer.MAX_OUTPUT_BYTES)
        self.assertIn(b'"reason":"output_byte_cap"', oversized)


if __name__ == "__main__":
    print("SYNTHETIC_ONLY: no native proc_pidinfo or target process is used")
    unittest.main(verbosity=2)
