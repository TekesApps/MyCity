# Bounded macOS VM-region attribution candidate

This is a new, separate diagnostic candidate. It does not replace or edit the earlier `observe_model_lifecycle.py` (`5bb214c2…b0702e2`) or any preserved failed run. It reads the existing phase observer JSONL and samples **one explicitly pinned process** during one explicitly pinned phase. It does not launch or stop the model process, read mapped bytes, or serve as an M0 memory/performance gate.

## Local SDK/API check

The read-only SDK inspection used the installed Command Line Tools SDK at `/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/usr/include`:

| Header | SHA-256 |
|---|---|
| `libproc.h` | `246d87709fc6b9157ce5cf3c475656ac48e0e1ae8bbdc46cf45acd34294448cd` |
| `sys/proc_info.h` | `e427fa96b348537b21552b9de71e01039410bcad2cedee5584c5e5fddafd70fc` |
| `mach/vm_statistics.h` | `b2b81f9e7efff57b648b4705a1ad08ffb55b99d0966b02c110f95fa454e175b7` |

That SDK declares `proc_pidinfo`, `PROC_PIDREGIONINFO` (`7`), and the 21-field `proc_regioninfo` structure. Its fields are parsed from the pinned local header at runtime; exact field names/order, LP64 offsets, and 96-byte size must match or the script refuses before querying a target. Page size comes from `sysconf`; `VM_MEMORY_*` tag labels are parsed from the pinned local header, with numeric tag values preserved. Apple XNU's public test exercises `PROC_PIDREGIONINFO` using a mapped address as the query argument, and the public wrapper passes that address through to `proc_pidinfo` ([XNU `proc_info.c`](https://github.com/apple/darwin-xnu/blob/main/bsd/kern/proc_info.c), [XNU `libproc.c`](https://github.com/apple-oss-distributions/xnu/blob/main/libsyscall/wrappers/libproc/libproc.c), [XNU `proc_info.c` test](https://github.com/apple/darwin-xnu/blob/main/tests/proc_info.c)).

The process can deny or race a region query. A zero/short return while the target might still live is recorded as incomplete, never treated as an end-of-map. The candidate rejects non-advancing/overlapping addresses, zero region sizes, arithmetic overflow, ABI changes, PID reuse, executable changes, source mismatch, phase changes, and missing native identity. It stops at 512 returned regions or checks a 1-second budget between and immediately after synchronous `proc_pidinfo` calls. The time budget is cooperative: a blocked native call cannot be hard-preempted, so this is not a strict 1-second wall-clock guarantee. Either cap is incomplete. This candidate has no explicit SDK end-of-map proof, so even a bounded prefix returned before a zero/short response stays `incomplete`; a full address-space walk is **not claimed**.

The sample reports separate SDK page fields (`resident`, `private resident`, `shared resident`, `shared-now-private`, `swapped`, `dirtied`, and `wired`) grouped by the SDK user-tag value/name. These are diagnostic counters, not a disjoint reconstruction of `phys_footprint`. Their byte conversions use the runtime page size, but no category totals are added to or subtracted from physical footprint. The reported arithmetic deltas are explicitly non-reconciliation comparisons. Thread count is never treated as stack residency; region tags alone do not prove stack residency.

## Exact run binding and limits

The runner must start before the normal-pool lifecycle CLI and point at that run's live native-observer JSONL. Supply the current run's frozen source SHA, executable path and SHA, the phase-observer SHA, phase, PID, and Mach OS-start-abstime. The copied phase observer is based on the published candidate at SHA `e4cc3a2a849e6813dc1a6b0aae2c29888cc8f6dd168a23eb8b60967561e4028f`; its current private candidate SHA is `45139b2ca8a943331e325f7b2a4a4234828d4342aa5931a39a48592895bfb4e`. Its `observer_start` row pins its built file SHA and clock descriptor. Each successful phase row retains legacy `capture_begin_monotonic_ns`/`capture_end_monotonic_ns` fields and adds `absolute_monotonic_ns` using `time.clock_gettime_ns(time.CLOCK_MONOTONIC)`, explicit `CLOCK_MONOTONIC` ID, `ns`, begin, and end. The region observer candidate SHA is `cee63b7ab1c64ce7466dcf429449a3d8093a16ee07a2510891ab28e165782a5b`; it reads and scans with the same clock function and ID, pins the producer SHA and exact clock descriptor, and uses only this new absolute interval; absent or invalid absolute times fail closed, with no fallback to legacy values. The subprocess self-check verifies two fresh Python processes observe the same increasing `CLOCK_MONOTONIC` domain; it is not a native Model run. The observer selects the newest complete sample for the requested phase and exact target identity; it does not accept the first stale historical row. After the requested phase is first observed, any terminal, different phase, changed fingerprint/generation, or changed PID/start/parent/name/executable rejects the whole scan instead of skipping ahead. The bracket requires `pre_begin ≤ pre_end ≤ scan_begin ≤ scan_end ≤ post_begin ≤ post_end`. The pre sample age is capped at 1.5 seconds: the periodic filled sample is 1 Hz, with a fixed 0.5-second allowance for scheduling and observer-loop delay. It waits at most 3 seconds from scan end for a post sample. Both samples must preserve phase fingerprint/generation and target PID, OS start, parent, process name, and executable path. The target relation is checked against the captured native `process_name`; the complete executable path is checked independently with `proc_pidpath`, since a short process-name field can be truncated. The observer start row must pin the same source/executable and all four support helpers. The script validates all support helper hashes and the exact local SDK header hashes before region queries. A valid bracket only establishes observation order and identity; it does not prove VM mappings remained static or that region records were sampled simultaneously.

One invocation covers one target role (`pool`, `model_helper`, or `supervisor`) and one phase. The region query budget is 512 regions / a cooperative 1-second check; input observation is capped at 256 rows / 256 KiB / 8 KiB per row; output serialization is capped at 128 KiB. The output cap limits bytes written, not Python heap use. JSON decoding, report construction, JSON encoding, and the fallback report may allocate temporary Python objects; that transient memory is observer overhead and must be measured/accounted separately. The included `tracemalloc` readings bracket the region scan and wait, but the final reading occurs before JSON encoding and therefore does not measure serialization temporaries. No pressure file or model payload is opened. The report separately records the sampler's own process usage and Python allocation counters; those figures are not silently netted against target usage and must be accounted for by the root observer.

A post-scan terminal row, changed phase, or changed event fingerprint invalidates the entire bracket wait. The region data, if any, is retained only as `unvalidated_raw_region_observation`; it is excluded from the valid `region_sample` and footprint comparison. The candidate does not extend or reinterpret the phase after such a change.

## Per-process clock handshake

Both scripts pin `clock_handshake.py` by SHA-256. The producer accepts optional `--clock-handshake-fd`; the region observer requires it. The root runner creates one `socket.socketpair()` per child, passes the child descriptor with `Popen(..., pass_fds=(child_fd,))`, closes its local child descriptor, and calls `parent_handshake(parent_socket, expected_child_pid=popen.pid, expected_child_component="phase_observer"|"region_observer")`. Each child runs `child_handshake(fd, component)` before any target capture or region query. The parent verifies the reported child PID equals the actual `Popen.pid`, and the child verifies the reported parent PID equals `os.getppid()`.

The bounded v1 exchange is: `parent_challenge(parent_before_ns,parent_identity)` → `child_response(parent_before_ns,child_sample_ns,child_identity)` → `parent_ack(parent_before_ns,child_sample_ns,parent_after_ns)` → `child_challenge(child_before_ns,child_identity)` → `parent_response(child_before_ns,parent_sample_ns,parent_identity)` → `receipt(all six timestamps, both identities, ordered=true)` → `ack(receipt_sha256,accepted=true)`. Every message carries protocol name and nonce; all timestamps use `time.clock_gettime_ns(time.CLOCK_MONOTONIC)`. Each JSON line is at most 4096 bytes and the full exchange has a 3-second monotonic timeout. A missing FD, malformed message, PID mismatch, failed ordering, clock ID/name/unit mismatch, timeout, or final-ack mismatch rejects startup. It never calculates offsets or translates timestamps. The producer records the accepted receipt in `observer_start`; the region report records its own receipt. The host-local socketpair unit test validates this protocol with fresh child processes, but only the later native run can bind the actual producer and region observer PIDs to its receipts.

Command shape (replace all placeholders from the exact run receipt; do not reuse old PIDs or hashes):

```sh
python3 observe_vm_regions.py \
  --support-dir /Users/frankqin/dev/MyCity/docs/evidence/m0-t13a-joint-smoke-control-03 \
  --observer-jsonl <fresh-run-native-observer.jsonl> \
  --output <fresh-run-vm-region-target.json> \
  --source-sha256 <fresh-source-sha256> \
  --phase-observer-sha256 <fresh-phase-observer-sha256> \
  --exe <fresh-pinned-mycity-headless> \
  --exe-sha256 <fresh-executable-sha256> \
  --phase filled --role model_helper \
  --pid <observed-pid> --os-start-abstime <observed-mach-start-abstime>
```

Expected exit `2` with `status: incomplete` is a recorded fail-closed outcome, not a pass. If a future, separately reviewed implementation proves the requested scan boundary, exit `0` could mean only that bounded observation was captured; it would not certify a complete address-space map, physical-footprint reconciliation, memory savings, 16 GB operation, or eight-hour stability. If SDK headers/layout, target identity, phase bracket, or permissions are unavailable, the result stays incomplete.

## Validation state

The Python boundary suite exercises synthetic records and two fresh Python subprocesses for the shared clock (no Model target). It covers legacy-versus-absolute clock rejection, cross-process clock monotonicity, latest-fresh late attach, absolute interval/order/staleness, short record, non-progressing region address, phase/fingerprint/terminal/identity invalidation, target path relation, producer-field contract, and bounded output encoding. The observed Python 3.9.6 subprocess values and clock-ID receipt are preserved in `clock-domain-subprocess-selfcheck.json`: `CLOCK_MONOTONIC` advanced by 16,326,000 ns, while `time.monotonic_ns()` went from 7,898,541 to 8,288,000 across processes. This host-local evidence does not establish native sampling or Model behavior. Run it with:

```sh
python3 docs/evidence/m0-model-lifecycle-observer-candidate/test_observe_vm_regions_synthetic.py
```

No Cargo, native query, target launch, or performance run was performed. Runtime ABI and permission behavior remain `not_run`; root schedules the first live validation against a fresh source/executable and preserves its output. Synthetic test success does not establish native sampling correctness or explain the 347 physical-memory residual.


## Current takeover result (2026-10-24)

The private hashes and not-run statements above describe earlier candidates. Current canonical v2 script hashes and actual entry/clock-only evidence are in `ENTRY-CLOCK-STATUS.md` and the referenced `fixed-inputs.json`. Both scripts explicitly import importlib.util and pin the v2 helper. Only early-exit Python entry/clock diagnostics were run; native region/ABI/phase sampling remains untested here. No old hash or not-run evidence was overwritten.
