"""Bounded real Python/socketpair protocol tests; no Model or native target queries."""
from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import unittest
from unittest import mock

SOURCE = Path(__file__).with_name("clock_handshake.py")
SPEC = importlib.util.spec_from_file_location("clock_under_test", SOURCE)
clock = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(clock)

CHILD = r'''
import importlib.util,json,socket,sys,time
s=importlib.util.spec_from_file_location('clock_child',sys.argv[1]);h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
fd=int(sys.argv[2]);mode=sys.argv[3]
if mode=='real':
    print(json.dumps(h.child_handshake(fd,'region_observer')),flush=True)
    sys.exit(0)
sock=socket.socket(fileno=fd);deadline=time.monotonic()+h.MAX_HANDSHAKE_SECONDS
challenge=h._receive(sock,deadline)
if mode=='eof':sys.exit(0)
if mode=='timeout':time.sleep(h.MAX_HANDSHAKE_SECONDS+0.1);sys.exit(0)
if mode=='oversized':sock.sendall(b'x'*(h.MAX_LINE_BYTES+1)+b'\n');sys.exit(0)
nonce=challenge['nonce'];parent=challenge['parent'];child=h.identity('region_observer')
if mode=='wrong_pid':child['pid']+=1
if mode=='wrong_component':child['component']='phase_observer'
if mode=='wrong_clock_name':child['clock_name']='CLOCK_MONOTONIC_RAW'
if mode=='wrong_clock_id':child['clock_id']+=1
if mode=='wrong_clock_unit':child['clock_unit']='us'
sample=h.clock_ns()
def send(kind,**extra):h._send(sock,dict(protocol=h.PROTOCOL,kind=kind,nonce=nonce,**extra),deadline)
parent_before=challenge['parent_before_ns']
if mode=='wrong_echo':parent_before+=1
if mode=='wrong_nonce':nonce+='x'
send('receipt' if mode=='wrong_kind' else 'child_response',child=child,parent_before_ns=parent_before,child_sample_ns=sample)
ack=h._receive(sock,deadline)
child_before=parent_before if mode=='second_round_too_early' else h.clock_ns()
send('child_challenge',child=child,child_before_ns=child_before)
response=h._receive(sock,deadline)
receipt=dict(parent=parent,child=child,ordered=True,parent_before_ns=parent_before,
             child_sample_ns=sample,parent_after_ns=ack['parent_after_ns'],
             child_before_ns=child_before,parent_sample_ns=response['parent_sample_ns'],
             child_after_ns=h.clock_ns())
if mode=='substituted_receipt':
    for k in ['parent_before_ns','child_sample_ns','parent_after_ns','child_before_ns','parent_sample_ns','child_after_ns']:receipt[k]=0
if mode=='future_child_after':receipt['child_after_ns']+=10**15
send('receipt',receipt=receipt)
print(json.dumps(h._receive(sock,deadline)),flush=True)
'''


def launch(mode):
    left, right = socket.socketpair()
    process = subprocess.Popen(
        [sys.executable, "-B", "-I", "-S", "-c", CHILD, str(SOURCE), str(right.fileno()), mode],
        pass_fds=(right.fileno(),), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
    )
    right.close()
    return left, process


class ClockProtocol(unittest.TestCase):
    def finish(self, sock, process):
        sock.close()
        try:
            return process.communicate(timeout=5)
        finally:
            if process.poll() is None:
                # Only the fresh child owned by this test; never another project's process.
                process.kill()
                process.communicate(timeout=2)

    def test_real_child_and_parent_bind_the_full_exchange(self):
        sock, process = launch("real")
        try:
            parent = clock.parent_handshake(sock, process.pid, "region_observer")
        finally:
            stdout, stderr = self.finish(sock, process)
        self.assertEqual(process.returncode, 0, stderr)
        child = json.loads(stdout)
        self.assertEqual(parent, child)
        self.assertEqual(child["parent"]["pid"], os.getpid())
        self.assertEqual(child["child"]["pid"], process.pid)
        names = ["parent_before_ns", "child_sample_ns", "parent_after_ns", "child_before_ns",
                 "parent_sample_ns", "child_after_ns", "parent_receive_ns"]
        values = [child[key] for key in names]
        self.assertEqual(values, sorted(values))

    def test_parent_rejects_invalid_protocol_clock_and_receipts(self):
        cases = {
            "wrong_pid": "child_pid_does_not_match_popen_pid",
            "wrong_component": "child_component_mismatch",
            "wrong_clock_name": "clock_identity_mismatch",
            "wrong_clock_id": "clock_identity_mismatch",
            "wrong_clock_unit": "clock_identity_mismatch",
            "wrong_echo": "challenge_timestamp_echo_mismatch",
            "wrong_nonce": "handshake_message_mismatch",
            "wrong_kind": "handshake_message_mismatch",
            "substituted_receipt": "receipt_timestamp_mismatch",
            "second_round_too_early": "handshake_total_order_invalid",
            "future_child_after": "handshake_total_order_invalid",
            "eof": "handshake_peer_closed",
            "oversized": "handshake_line_too_large",
            "timeout": "timed out",
        }
        for mode, reason in cases.items():
            with self.subTest(mode=mode):
                sock, process = launch(mode)
                try:
                    with self.assertRaises((clock.HandshakeError, TimeoutError, socket.timeout)) as caught:
                        clock.parent_handshake(sock, process.pid, "region_observer")
                    self.assertIn(reason, str(caught.exception))
                    print(json.dumps({"negative_case": mode, "rejected": str(caught.exception)}))
                finally:
                    self.finish(sock, process)

    def test_real_child_rejects_wrong_parent_pid(self):
        sock, process = launch("real")
        parent = clock.identity("test_parent")
        parent["pid"] += 1
        try:
            clock._send(sock, {"protocol": clock.PROTOCOL, "kind": "parent_challenge",
                              "nonce": "a" * 32, "parent": parent,
                              "parent_before_ns": clock.clock_ns()},
                        clock.time.monotonic() + clock.MAX_HANDSHAKE_SECONDS)
            stdout, stderr = process.communicate(timeout=5)
            self.assertNotEqual(process.returncode, 0)
            self.assertEqual(stdout, "")
            self.assertIn("parent_pid_does_not_match_os_parent", stderr)
        finally:
            self.finish(sock, process)

    def test_real_child_rejects_tampered_final_digest(self):
        sock, process = launch("real")
        original_send = clock._send

        def changed_send(peer, message, deadline):
            if message.get("kind") == "ack":
                message = {**message, "receipt_sha256": "0" * 64}
            original_send(peer, message, deadline)

        try:
            with mock.patch.object(clock, "_send", changed_send):
                clock.parent_handshake(sock, process.pid, "region_observer")
            stdout, stderr = process.communicate(timeout=5)
            self.assertNotEqual(process.returncode, 0)
            self.assertEqual(stdout, "")
            self.assertIn("parent_final_ack_rejected", stderr)
        finally:
            self.finish(sock, process)


if __name__ == "__main__":
    unittest.main(verbosity=2)
