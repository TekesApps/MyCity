//! Bounded deterministic group traffic assignment on an explicitly authorized directed graph.
//! This module is pure CPU calculation; callers persist inputs/results through the shared host.
use serde::{Deserialize, Serialize};
use std::collections::BTreeSet;

pub const MAX_NODES: usize = 128;
pub const MAX_EDGES: usize = 512;
pub const MAX_ENTRANCES: usize = 128;
pub const MAX_DEMANDS: usize = 512;
pub const MAX_ASSIGNMENT_STEPS: usize = 512;
const COST_SCALE: u64 = 10_000;
const BPR_ALPHA: u128 = 1_500; // 0.15 * COST_SCALE
const BPR_SCALE: u128 = 10_000;
const BPR_POWER_DENOMINATOR: u128 = 10_000_000_000_000_000; // SCALE^4

#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct Node {
    pub id: u32,
}

/// `city_from != city_to` marks a city boundary. `boundary_source` must be unique.
#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct RoadEdge {
    pub id: u32,
    pub from: u32,
    pub to: u32,
    pub city_from: u32,
    pub city_to: u32,
    pub free_flow_seconds: u32,
    pub capacity_people: u32,
    pub mode_mask: u8,
    pub open: bool,
    pub boundary_source: Option<u64>,
}

/// Entry is a granted topological connection, never inferred from geometric proximity.
#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct Entrance {
    pub id: u32,
    pub owner: u32,
    pub node: u32,
    pub mode_mask: u8,
    pub authorized: bool,
}

/// One aggregate OD cohort in a single assignment period.
#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct OdDemand {
    pub source_id: u64,
    pub origin_entrance: u32,
    pub destination_entrance: u32,
    pub mode: u8,
    pub people: u32,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct Opening {
    pub revision: u64,
    pub nodes: Vec<Node>,
    pub edges: Vec<RoadEdge>,
    pub entrances: Vec<Entrance>,
    pub demands: Vec<OdDemand>,
}

#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub enum Error {
    Limit,
    DuplicateId,
    MissingNode,
    InvalidEdge,
    DuplicateBoundarySource,
    InvalidEntrance,
    UnauthorizedEntrance,
    InvalidDemand,
    DuplicateDemandSource,
    Overflow,
}

#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct EdgeFlow {
    pub edge_id: u32,
    pub people: u64,
    pub capacity_people: u32,
    pub cost_seconds: u64,
}
#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct Unserved {
    pub source_id: u64,
    pub people: u32,
}
#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct BoundaryFlow {
    pub source_id: u64,
    pub people: u64,
}
#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct DemandOutcome {
    pub source_id: u64,
    pub requested_people: u32,
    pub served_people: u32,
    pub unserved_people: u32,
    /// Integer mean path cost for served people; `None` means nobody could travel.
    pub mean_travel_seconds: Option<u64>,
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct Assignment {
    pub network_revision: u64,
    pub edge_flows: Vec<EdgeFlow>,
    pub unserved: Vec<Unserved>,
    pub boundary_flows: Vec<BoundaryFlow>,
    pub demand_outcomes: Vec<DemandOutcome>,
    pub requested_people: u64,
    pub served_people: u64,
    pub unserved_people: u64,
    pub routing_steps: u16,
}

impl Opening {
    pub fn validate(&self) -> Result<(), Error> {
        if self.nodes.is_empty()
            || self.nodes.len() > MAX_NODES
            || self.edges.len() > MAX_EDGES
            || self.entrances.len() > MAX_ENTRANCES
            || self.demands.len() > MAX_DEMANDS
        {
            return Err(Error::Limit);
        }
        let mut nodes = BTreeSet::new();
        for n in &self.nodes {
            if !nodes.insert(n.id) {
                return Err(Error::DuplicateId);
            }
        }
        let mut edges = BTreeSet::new();
        let mut boundary = BTreeSet::new();
        for e in &self.edges {
            if !edges.insert(e.id) {
                return Err(Error::DuplicateId);
            }
            if !nodes.contains(&e.from) || !nodes.contains(&e.to) {
                return Err(Error::MissingNode);
            }
            if e.from == e.to
                || e.free_flow_seconds == 0
                || e.capacity_people == 0
                || e.mode_mask == 0
            {
                return Err(Error::InvalidEdge);
            }
            if e.city_from != e.city_to {
                let Some(key) = e.boundary_source else {
                    return Err(Error::InvalidEdge);
                };
                if !boundary.insert(key) {
                    return Err(Error::DuplicateBoundarySource);
                }
            } else if e.boundary_source.is_some() {
                return Err(Error::InvalidEdge);
            }
        }
        let mut entrances = BTreeSet::new();
        for x in &self.entrances {
            if !entrances.insert(x.id) {
                return Err(Error::DuplicateId);
            }
            if !nodes.contains(&x.node) || x.mode_mask == 0 {
                return Err(Error::InvalidEntrance);
            }
        }
        let emap: Vec<_> = self.entrances.iter().collect();
        let mut sources = BTreeSet::new();
        for d in &self.demands {
            if d.people == 0 || d.mode == 0 || d.mode.count_ones() != 1 {
                return Err(Error::InvalidDemand);
            }
            if !sources.insert(d.source_id) {
                return Err(Error::DuplicateDemandSource);
            }
            let a = emap
                .iter()
                .find(|x| x.id == d.origin_entrance)
                .ok_or(Error::InvalidDemand)?;
            let b = emap
                .iter()
                .find(|x| x.id == d.destination_entrance)
                .ok_or(Error::InvalidDemand)?;
            if !a.authorized
                || !b.authorized
                || a.mode_mask & d.mode == 0
                || b.mode_mask & d.mode == 0
            {
                return Err(Error::UnauthorizedEntrance);
            }
        }
        Ok(())
    }

    /// Deterministic incremental loading. Edits must produce a new opening/revision; stale
    /// assignments are rejected by consumers via `network_revision` comparison.
    pub fn assign(&self) -> Result<Assignment, Error> {
        self.validate()?;
        let mut edges = self.edges.clone();
        edges.sort_by_key(|e| e.id);
        let mut entrances = self.entrances.clone();
        entrances.sort_by_key(|e| e.id);
        let mut demands = self.demands.clone();
        demands.sort_by_key(|d| d.source_id);
        let mut flow = vec![0u64; edges.len()];
        let mut served = 0u64;
        let mut requested = 0u64;
        let mut unserved = Vec::new();
        let mut demand_outcomes = Vec::with_capacity(demands.len());
        let mut steps = 0u16;
        for d in demands {
            requested = requested
                .checked_add(u64::from(d.people))
                .ok_or(Error::Overflow)?;
            let from = entrances
                .binary_search_by_key(&d.origin_entrance, |x| x.id)
                .map_err(|_| Error::InvalidDemand)?;
            let to = entrances
                .binary_search_by_key(&d.destination_entrance, |x| x.id)
                .map_err(|_| Error::InvalidDemand)?;
            let (origin, destination) = (entrances[from].node, entrances[to].node);
            let mut remaining = u64::from(d.people);
            let mut demand_served = 0u64;
            let mut weighted_seconds = 0u128;
            while remaining > 0 && usize::from(steps) < MAX_ASSIGNMENT_STEPS {
                let path = shortest_path(&self.nodes, &edges, &flow, origin, destination, d.mode)?;
                let Some(path) = path else { break };
                if path.is_empty() {
                    break;
                }
                let room = path
                    .iter()
                    .map(|i| u64::from(edges[*i].capacity_people).saturating_sub(flow[*i]))
                    .min()
                    .unwrap_or(0);
                if room == 0 {
                    break;
                }
                let amount = remaining.min(room);
                let path_cost = path.iter().try_fold(0u64, |sum, i| {
                    sum.checked_add(congested_cost(
                        edges[*i].free_flow_seconds,
                        edges[*i].capacity_people,
                        flow[*i],
                    )?)
                    .ok_or(Error::Overflow)
                })?;
                weighted_seconds = weighted_seconds
                    .checked_add(
                        u128::from(amount)
                            .checked_mul(u128::from(path_cost))
                            .ok_or(Error::Overflow)?,
                    )
                    .ok_or(Error::Overflow)?;
                for i in path {
                    flow[i] = flow[i].checked_add(amount).ok_or(Error::Overflow)?;
                }
                remaining -= amount;
                demand_served = demand_served.checked_add(amount).ok_or(Error::Overflow)?;
                served = served.checked_add(amount).ok_or(Error::Overflow)?;
                steps = steps.checked_add(1).ok_or(Error::Overflow)?;
            }
            if remaining > 0 {
                unserved.push(Unserved {
                    source_id: d.source_id,
                    people: u32::try_from(remaining).map_err(|_| Error::Overflow)?,
                });
            }
            demand_outcomes.push(DemandOutcome {
                source_id: d.source_id,
                requested_people: d.people,
                served_people: u32::try_from(demand_served).map_err(|_| Error::Overflow)?,
                unserved_people: u32::try_from(remaining).map_err(|_| Error::Overflow)?,
                mean_travel_seconds: if demand_served == 0 {
                    None
                } else {
                    Some(
                        u64::try_from(weighted_seconds / u128::from(demand_served))
                            .map_err(|_| Error::Overflow)?,
                    )
                },
            });
        }
        let mut edge_flows = Vec::with_capacity(edges.len());
        for (i, e) in edges.iter().enumerate() {
            if !e.open {
                continue;
            }
            edge_flows.push(EdgeFlow {
                edge_id: e.id,
                people: flow[i],
                capacity_people: e.capacity_people,
                cost_seconds: congested_cost(e.free_flow_seconds, e.capacity_people, flow[i])?,
            });
        }
        let mut boundary_flows = Vec::new();
        for (i, e) in edges.iter().enumerate() {
            if let Some(source_id) = e.boundary_source {
                if flow[i] > 0 {
                    boundary_flows.push(BoundaryFlow {
                        source_id,
                        people: flow[i],
                    });
                }
            }
        }
        boundary_flows.sort_by_key(|x| x.source_id);
        let unserved_people = unserved.iter().try_fold(0u64, |a, x| {
            a.checked_add(u64::from(x.people)).ok_or(Error::Overflow)
        })?;
        Ok(Assignment {
            network_revision: self.revision,
            edge_flows,
            unserved,
            boundary_flows,
            demand_outcomes,
            requested_people: requested,
            served_people: served,
            unserved_people,
            routing_steps: steps,
        })
    }
}

fn congested_cost(free: u32, cap: u32, flow: u64) -> Result<u64, Error> {
    let ratio = u128::from(flow)
        .checked_mul(u128::from(COST_SCALE))
        .ok_or(Error::Overflow)?
        / u128::from(cap);
    let fourth = ratio
        .checked_mul(ratio)
        .and_then(|x| x.checked_mul(x))
        .and_then(|x| x.checked_mul(x))
        .ok_or(Error::Overflow)?;
    let increment = BPR_ALPHA.checked_mul(fourth).ok_or(Error::Overflow)? / BPR_POWER_DENOMINATOR;
    let scaled = BPR_SCALE.checked_add(increment).ok_or(Error::Overflow)?;
    u64::try_from(
        u128::from(free)
            .checked_mul(scaled)
            .ok_or(Error::Overflow)?
            / BPR_SCALE,
    )
    .map_err(|_| Error::Overflow)
}

fn shortest_path(
    nodes: &[Node],
    edges: &[RoadEdge],
    flow: &[u64],
    origin: u32,
    destination: u32,
    mode: u8,
) -> Result<Option<Vec<usize>>, Error> {
    let n = nodes.len();
    let mut dist = vec![u64::MAX; n];
    let mut prev = vec![None; n];
    let mut used = vec![false; n];
    let oi = nodes
        .iter()
        .position(|x| x.id == origin)
        .ok_or(Error::MissingNode)?;
    let di = nodes
        .iter()
        .position(|x| x.id == destination)
        .ok_or(Error::MissingNode)?;
    dist[oi] = 0;
    for _ in 0..n {
        let Some(u) = (0..n)
            .filter(|i| !used[*i])
            .min_by_key(|i| (dist[*i], nodes[*i].id))
        else {
            break;
        };
        if dist[u] == u64::MAX {
            break;
        }
        if u == di {
            break;
        }
        used[u] = true;
        for (ei, e) in edges.iter().enumerate() {
            if !e.open
                || e.from != nodes[u].id
                || e.mode_mask & mode == 0
                || flow[ei] >= u64::from(e.capacity_people)
            {
                continue;
            }
            let Some(v) = nodes.iter().position(|x| x.id == e.to) else {
                return Err(Error::MissingNode);
            };
            if used[v] {
                continue;
            }
            let cost = congested_cost(e.free_flow_seconds, e.capacity_people, flow[ei])?;
            let alt = dist[u].checked_add(cost).ok_or(Error::Overflow)?;
            if alt < dist[v]
                || (alt == dist[v]
                    && prev[v]
                        .map(|old: usize| edges[old].id > e.id)
                        .unwrap_or(true))
            {
                dist[v] = alt;
                prev[v] = Some(ei);
            }
        }
    }
    if dist[di] == u64::MAX {
        return Ok(None);
    }
    let mut path = Vec::new();
    let mut at = di;
    while at != oi {
        let Some(ei) = prev[at] else { return Ok(None) };
        path.push(ei);
        at = nodes
            .iter()
            .position(|x| x.id == edges[ei].from)
            .ok_or(Error::MissingNode)?;
        if path.len() > n {
            return Err(Error::InvalidEdge);
        }
    }
    path.reverse();
    Ok(Some(path))
}

#[cfg(test)]
mod tests {
    use super::*;
    fn base(capacity: u32, people: u32) -> Opening {
        Opening {
            revision: 1,
            nodes: vec![Node { id: 1 }, Node { id: 2 }, Node { id: 3 }],
            edges: vec![
                RoadEdge {
                    id: 10,
                    from: 1,
                    to: 2,
                    city_from: 1,
                    city_to: 1,
                    free_flow_seconds: 10,
                    capacity_people: capacity,
                    mode_mask: 1,
                    open: true,
                    boundary_source: None,
                },
                RoadEdge {
                    id: 11,
                    from: 1,
                    to: 3,
                    city_from: 1,
                    city_to: 1,
                    free_flow_seconds: 20,
                    capacity_people: 20,
                    mode_mask: 1,
                    open: true,
                    boundary_source: None,
                },
                RoadEdge {
                    id: 12,
                    from: 3,
                    to: 2,
                    city_from: 1,
                    city_to: 1,
                    free_flow_seconds: 20,
                    capacity_people: 20,
                    mode_mask: 1,
                    open: true,
                    boundary_source: None,
                },
            ],
            entrances: vec![
                Entrance {
                    id: 1,
                    owner: 1,
                    node: 1,
                    mode_mask: 1,
                    authorized: true,
                },
                Entrance {
                    id: 2,
                    owner: 2,
                    node: 2,
                    mode_mask: 1,
                    authorized: true,
                },
            ],
            demands: vec![OdDemand {
                source_id: 7,
                origin_entrance: 1,
                destination_entrance: 2,
                mode: 1,
                people,
            }],
        }
    }
    #[test]
    fn nearby_geometry_without_granted_entrance_does_not_create_access() {
        let mut x = base(20, 5);
        x.entrances[0].authorized = false;
        assert_eq!(x.assign(), Err(Error::UnauthorizedEntrance));
    }
    #[test]
    fn entrance_must_allow_the_demand_mode() {
        let mut x = base(20, 5);
        x.entrances[0].mode_mask = 2;
        assert_eq!(x.assign(), Err(Error::UnauthorizedEntrance));
    }
    #[test]
    fn closed_directed_road_changes_reachable_assignment() {
        let mut x = base(20, 15);
        x.edges[0].open = false;
        let a = x.assign().unwrap();
        assert_eq!(a.served_people, 15);
        assert!(a.edge_flows.iter().find(|e| e.edge_id == 10).is_none());
    }
    #[test]
    fn capacity_limits_served_people_and_expansion_changes_cost() {
        let mut x = base(5, 10);
        let a = x.assign().unwrap();
        assert_eq!(a.served_people, 10);
        assert_eq!(a.unserved_people, 0);
        assert!(
            a.edge_flows
                .iter()
                .find(|e| e.edge_id == 10)
                .unwrap()
                .people
                <= 5
        );
        let before = a
            .edge_flows
            .iter()
            .find(|e| e.edge_id == 10)
            .unwrap()
            .cost_seconds;
        x.revision += 1;
        x.edges[0].capacity_people = 20;
        let b = x.assign().unwrap();
        assert!(
            b.edge_flows
                .iter()
                .find(|e| e.edge_id == 10)
                .unwrap()
                .cost_seconds
                < before
        );
        assert_ne!(a.network_revision, b.network_revision);
    }
    #[test]
    fn no_path_is_reported_as_unserved() {
        let mut x = base(20, 4);
        x.edges.iter_mut().for_each(|e| e.open = false);
        let a = x.assign().unwrap();
        assert_eq!(a.unserved_people, 4);
        assert_eq!(a.served_people, 0);
    }
    #[test]
    fn duplicate_demand_and_boundary_sources_are_rejected() {
        let mut x = base(20, 2);
        x.demands.push(x.demands[0]);
        assert_eq!(x.validate(), Err(Error::DuplicateDemandSource));
        let mut y = base(20, 2);
        y.edges[0].city_to = 2;
        y.edges[0].boundary_source = Some(9);
        y.edges[1].city_to = 2;
        y.edges[1].boundary_source = Some(9);
        assert_eq!(y.validate(), Err(Error::DuplicateBoundarySource));
    }
    #[test]
    fn identical_input_produces_identical_aggregates() {
        let x = base(20, 18);
        assert_eq!(x.assign().unwrap(), x.assign().unwrap());
    }
}
