//! Pre-implementation typed capacity inventory. No runtime grant or allocation proof.
use crate::{
    air::{Source, State, STRATEGY},
    arena::{AccountDomain, Arena, Handle, InventoryDomain},
    assembly::{Account, OpeningSource, Stock, World, MAX_ACCOUNTS, MAX_SOURCES, MAX_STOCKS},
    background::SOURCE_LIMIT,
    timeline::{Claim, Payroll, CLAIM_LIMIT, PAYROLL_LIMIT},
    transaction::{
        prepared_header_bytes, Engine, JournalRecord, Lease, Resource, MAX_LEASES, MAX_RECEIPTS,
        MAX_RESOURCES,
    },
};
use serde::Serialize;
use std::mem::size_of;

#[derive(Debug, Serialize)]
pub struct Part {
    pub name: &'static str,
    pub count: usize,
    pub record_bytes: usize,
    pub bytes: usize,
}
impl Part {
    fn new(name: &'static str, count: usize, record_bytes: usize) -> Self {
        Self {
            name,
            count,
            record_bytes,
            bytes: count * record_bytes,
        }
    }
}

#[derive(Debug, Serialize)]
pub struct Inventory {
    pub engine: Vec<Part>,
    pub prepared: Vec<Part>,
    pub extra_air_state: Vec<Part>,
    pub engine_bytes: usize,
    pub prepared_bytes: usize,
    pub extra_air_state_bytes: usize,
    pub source_limit: usize,
    pub cell_limit: usize,
    pub runtime_ownership_proven: bool,
}

fn timeline_rows() -> [Part; 2] {
    [
        Part::new("claims", CLAIM_LIMIT, size_of::<Claim>()),
        Part::new("payroll", PAYROLL_LIMIT, size_of::<Payroll>()),
    ]
}
fn air_payload(sources: usize) -> Vec<Part> {
    vec![
        Part::new("air_sources", sources, size_of::<Source>()),
        Part::new(
            "air_f32_bits_field_and_scratch",
            128 * 128 * 2,
            size_of::<u32>(),
        ),
        Part::new("air_f64_bits_integral", 128 * 128, size_of::<u64>()),
        Part::new("air_strategy_and_input_hash", 1, STRATEGY.len() + 64),
    ]
}
fn background_rows() -> Vec<Part> {
    // State/Input headers are already inline in Option<Background>/Job in each root.
    let mut rows = air_payload(SOURCE_LIMIT);
    rows.push(Part::new(
        "pending_job_input_sources",
        SOURCE_LIMIT,
        size_of::<Source>(),
    ));
    rows.push(Part::new("pending_job_input_strategy", 1, STRATEGY.len()));
    rows
}
fn sum(parts: &[Part]) -> usize {
    parts.iter().map(|p| p.bytes).sum()
}

/// Full schema capacities, not current live lengths or the old post-allocation limits.
/// Inline Region/Economy/Boot/Exchange (including Inbox) are counted in root sizes.
/// Proposed exact-capacity rows/strings must be enforced before this becomes a grant.
pub fn inventory() -> Inventory {
    let mut engine = vec![
        Part::new(
            "engine_inline_root_including_timeline_background_headers",
            1,
            size_of::<Engine>(),
        ),
        Part::new(
            "boxed_world_inline_root_including_fixed_domains",
            1,
            size_of::<World>(),
        ),
        Part::new(
            "account_arena_slots_and_free_indices",
            1,
            Arena::<AccountDomain, Account>::fixed_payload_bytes(MAX_ACCOUNTS),
        ),
        Part::new(
            "stock_arena_slots_and_free_indices",
            1,
            Arena::<InventoryDomain, Stock>::fixed_payload_bytes(MAX_STOCKS),
        ),
        Part::new(
            "account_id_index",
            MAX_ACCOUNTS,
            size_of::<(u32, Handle<AccountDomain>)>(),
        ),
        Part::new(
            "stock_id_index",
            MAX_STOCKS,
            size_of::<(u32, Handle<InventoryDomain>)>(),
        ),
        Part::new("opening_sources", MAX_SOURCES, size_of::<OpeningSource>()),
        Part::new("resources", MAX_RESOURCES, size_of::<Resource>()),
        Part::new("leases", MAX_LEASES, size_of::<Option<Lease>>()),
        Part::new("hot_journal", MAX_RECEIPTS, size_of::<JournalRecord>()),
    ];
    engine.extend(timeline_rows());
    engine.extend(background_rows());
    let mut prepared = vec![
        Part::new(
            "prepared_inline_root_including_fixed_domain_copies",
            1,
            prepared_header_bytes(),
        ),
        Part::new(
            "dirty_accounts",
            MAX_ACCOUNTS,
            size_of::<(Handle<AccountDomain>, Account)>(),
        ),
        // All stock records, not merely the initial MAX_ACTIONS*2 Vec reservation.
        Part::new(
            "dirty_stocks",
            MAX_STOCKS,
            size_of::<(Handle<InventoryDomain>, Stock)>(),
        ),
        Part::new("resources", MAX_RESOURCES, size_of::<Resource>()),
        Part::new("leases", MAX_LEASES, size_of::<Option<Lease>>()),
    ];
    prepared.extend(timeline_rows());
    prepared.extend(background_rows());
    let mut extra_air_state = vec![Part::new("state_inline_header", 1, size_of::<State>())];
    // Shared maximum supports the full CPU/reference kernel too, not only four shipments.
    extra_air_state.extend(air_payload(20_000));
    Inventory {
        engine_bytes: sum(&engine),
        prepared_bytes: sum(&prepared),
        extra_air_state_bytes: sum(&extra_air_state),
        engine,
        prepared,
        extra_air_state,
        source_limit: 20_000,
        cell_limit: 128 * 128,
        runtime_ownership_proven: false,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn every_domain_copy_and_full_dirty_stock_table_is_included() {
        let i = inventory();
        assert_eq!(
            i.prepared
                .iter()
                .find(|p| p.name == "dirty_stocks")
                .unwrap()
                .count,
            MAX_STOCKS
        );
        assert!(MAX_STOCKS > crate::transaction::MAX_ACTIONS * 2);
        assert!(
            i.engine_bytes
                > CLAIM_LIMIT * size_of::<Claim>() + MAX_RECEIPTS * size_of::<JournalRecord>()
        );
        assert!(!i.runtime_ownership_proven);
    }
}
